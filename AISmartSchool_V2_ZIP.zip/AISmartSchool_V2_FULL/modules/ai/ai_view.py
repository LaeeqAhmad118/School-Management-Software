"""AI Analytics Module - Offline AI using local algorithms"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QThread, Signal
from ui.components.widgets import SectionHeader, shadow
from datetime import datetime
from core.color_utils import rgba


class AIAnalysisThread(QThread):
    result_ready = Signal(dict)
    def __init__(self, db):
        super().__init__()
        self.db = db
    def run(self):
        data = {}
        try:
            # Risk students (low attendance)
            risk = self.db.fetchall("""
                SELECT s.full_name, s.student_id, c.name as class_name,
                       ROUND(100.0*SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END)/
                       NULLIF(COUNT(a.id),0),1) as att_pct
                FROM students s
                LEFT JOIN attendance a ON s.id=a.student_id
                LEFT JOIN classes c ON s.class_id=c.id
                WHERE s.status='active'
                GROUP BY s.id HAVING att_pct IS NOT NULL AND att_pct < 75
                ORDER BY att_pct LIMIT 10
            """)
            data['risk_students'] = risk

            # Fee defaulters
            defaulters = self.db.fetchall("""
                SELECT s.full_name, s.student_id, COUNT(v.id) as overdue_count,
                       SUM(v.remaining_amount) as total_due
                FROM fee_vouchers v
                JOIN students s ON v.student_id=s.id
                WHERE v.status IN ('overdue','pending')
                GROUP BY s.id HAVING overdue_count >= 2
                ORDER BY total_due DESC LIMIT 10
            """)
            data['fee_defaulters'] = defaulters

            # Top performers
            top = self.db.fetchall("""
                SELECT s.full_name, s.student_id, c.name as class_name,
                       ROUND(AVG(100.0*r.obtained_marks/NULLIF(r.total_marks,0)),1) as avg_pct
                FROM results r
                JOIN students s ON r.student_id=s.id
                LEFT JOIN classes c ON s.class_id=c.id
                GROUP BY s.id HAVING avg_pct IS NOT NULL
                ORDER BY avg_pct DESC LIMIT 10
            """)
            data['top_performers'] = top

            # Fee recovery trend
            trend = self.db.fetchall("""
                SELECT month, year,
                       SUM(total_amount) as total, SUM(paid_amount) as collected,
                       ROUND(100.0*SUM(paid_amount)/NULLIF(SUM(total_amount),0),1) as recovery_pct
                FROM fee_vouchers
                GROUP BY year,month ORDER BY year DESC,id DESC LIMIT 6
            """)
            data['fee_trend'] = trend

            # Class-wise stats
            class_stats = self.db.fetchall("""
                SELECT c.name, COUNT(s.id) as total,
                       SUM(CASE WHEN s.status='active' THEN 1 ELSE 0 END) as active
                FROM classes c LEFT JOIN students s ON s.class_id=c.id
                GROUP BY c.id ORDER BY c.level
            """)
            data['class_stats'] = class_stats

        except Exception as e:
            data['error'] = str(e)
        self.result_ready.emit(data)


class AIView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db = db; self.user = user
        self._init_ui()
        self._run_analysis()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24,20,24,20); layout.setSpacing(16)
        header = SectionHeader("AI Analytics","Intelligent insights powered by local AI")
        btn_refresh = header.add_button("🔄 Refresh Analysis","btn_edit","")
        btn_refresh.clicked.connect(self._run_analysis)
        layout.addWidget(header)

        # AI Assistant search
        search_frame = QFrame()
        search_frame.setStyleSheet("background:#1c2128;border:1px solid #30363d;border-radius:12px;padding:16px;")
        sl = QVBoxLayout(search_frame)
        st = QLabel("🤖 AI EduHub Assistant")
        st.setStyleSheet("color:#e6edf3;font-size:15px;font-weight:700;")
        sl.addWidget(st)
        sh = QHBoxLayout()
        self.ai_input = QLineEdit()
        self.ai_input.setPlaceholderText('Ask anything e.g. "Show weak students" or "How to generate result cards?"')
        self.ai_input.setMinimumHeight(44)
        self.ai_input.returnPressed.connect(self._ai_query)
        ask_btn = QPushButton("Ask AI")
        ask_btn.setStyleSheet("background:#8b5cf6;color:white;border-radius:8px;padding:8px 20px;font-weight:700;min-height:44px;")
        ask_btn.clicked.connect(self._ai_query)
        sh.addWidget(self.ai_input,1); sh.addWidget(ask_btn)
        sl.addLayout(sh)
        self.ai_response = QLabel("Ready. Ask me anything about your school data.")
        self.ai_response.setWordWrap(True)
        self.ai_response.setStyleSheet("color:#8b949e;font-size:13px;padding:8px;background:#0d1117;border-radius:6px;margin-top:8px;")
        sl.addWidget(self.ai_response)
        layout.addWidget(search_frame)
        shadow(search_frame)

        # Analysis panels
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setStyleSheet("border:none;")
        content = QWidget(); self.analysis_layout = QVBoxLayout(content); self.analysis_layout.setSpacing(16)
        scroll.setWidget(content)
        layout.addWidget(scroll)

        self.loading_lbl = QLabel("🔄 Running AI analysis...")
        self.loading_lbl.setStyleSheet("color:#8b5cf6;font-size:14px;font-weight:600;")
        self.analysis_layout.addWidget(self.loading_lbl)

    def _run_analysis(self):
        self.loading_lbl.setText("🔄 Running AI analysis...")
        self.loading_lbl.show()
        # Clear previous widgets (keep loading_lbl at index 0)
        try:
            while int(self.analysis_layout.count()) > 1:
                item = self.analysis_layout.takeAt(1)
                if item and item.widget():
                    item.widget().deleteLater()
        except (TypeError, ValueError):
            pass  # layout not yet populated
        thread = AIAnalysisThread(self.db)
        thread.result_ready.connect(self._show_analysis)
        thread.start()
        self._thread = thread

    def _show_analysis(self, data):
        self.loading_lbl.setText("✅ Analysis complete")
        if 'error' in data:
            self.analysis_layout.addWidget(QLabel(f"Error: {data['error']}"))
            return

        # Risk Students
        self._add_section("⚠️ At-Risk Students (Attendance < 75%)",
            data.get('risk_students',[]),
            ["Name","Student ID","Class","Attendance %"],
            ["full_name","student_id","class_name","att_pct"],
            "#ef4444")

        # Fee Defaulters
        self._add_section("💸 Fee Defaulters (2+ Pending)",
            data.get('fee_defaulters',[]),
            ["Name","Student ID","Overdue Vouchers","Total Due"],
            ["full_name","student_id","overdue_count","total_due"],
            "#f59e0b")

        # Top Performers
        self._add_section("🏆 Top Academic Performers",
            data.get('top_performers',[]),
            ["Name","Student ID","Class","Average %"],
            ["full_name","student_id","class_name","avg_pct"],
            "#22c55e")

        # Fee Trend
        self._add_section("📈 Fee Recovery Trend",
            data.get('fee_trend',[]),
            ["Month","Year","Total","Collected","Recovery %"],
            ["month","year","total","collected","recovery_pct"],
            "#2563eb")

        # Class Stats
        self._add_section("🏫 Class-wise Student Count",
            data.get('class_stats',[]),
            ["Class","Total Students","Active"],
            ["name","total","active"],
            "#8b5cf6")

    def _add_section(self, title, rows, headers, keys, color):
        frame = QFrame()
        frame.setStyleSheet(f"background:#1c2128;border:1px solid {rgba(color, '44')};border-radius:12px;padding:16px;")
        l = QVBoxLayout(frame)
        t = QLabel(title)
        t.setStyleSheet(f"color:{color};font-size:14px;font-weight:700;margin-bottom:8px;")
        l.addWidget(t)
        if not rows:
            empty = QLabel("✓ No issues found."); empty.setStyleSheet("color:#22c55e;font-size:13px;")
            l.addWidget(empty)
        else:
            table = QTableWidget(len(rows), len(headers))
            table.setHorizontalHeaderLabels(headers)
            table.verticalHeader().setVisible(False)
            table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
            table.setAlternatingRowColors(True)
            table.setEditTriggers(QAbstractItemView.NoEditTriggers)
            table.setMaximumHeight(220)
            for ri, r in enumerate(rows):
                for ci, key in enumerate(keys):
                    val = r.get(key,'')
                    if isinstance(val, float): val = f"{val:,.1f}"
                    table.setItem(ri, ci, QTableWidgetItem(str(val) if val is not None else ''))
                table.setRowHeight(ri, 36)
            l.addWidget(table)
        shadow(frame)
        self.analysis_layout.addWidget(frame)

    def _ai_query(self):
        query = self.ai_input.text().strip().lower()
        if not query: return
        response = self._process_ai_query(query)
        self.ai_response.setText(f"🤖 {response}")

    def _process_ai_query(self, query):
        q = query.lower()
        # Smart intent matching
        if any(w in q for w in ['weak','fail','poor','below']):
            rows = self.db.fetchall("""
                SELECT s.full_name,s.student_id,
                       ROUND(AVG(100.0*r.obtained_marks/NULLIF(r.total_marks,0)),1) as avg
                FROM results r JOIN students s ON r.student_id=s.id
                GROUP BY s.id HAVING avg < 50 ORDER BY avg LIMIT 5
            """)
            if rows:
                names = ', '.join(r['full_name'] for r in rows)
                return f"Found {len(rows)} weak students: {names}"
            return "No weak students found (below 50% average)."

        elif any(w in q for w in ['absent','attendance','missing']):
            rows = self.db.fetchall("""
                SELECT COUNT(DISTINCT student_id) as c FROM attendance
                WHERE date=date('now') AND status='absent'
            """)
            c = rows[0]['c'] if rows else 0
            return f"Today, {c} students are absent."

        elif any(w in q for w in ['unpaid','overdue','fee','due']):
            r = self.db.fetchone("SELECT COUNT(*) as c, SUM(remaining_amount) as total FROM fee_vouchers WHERE status IN ('overdue','pending')")
            c = r['c'] or 0; t = r['total'] or 0
            return f"There are {c} unpaid/overdue vouchers totaling Rs.{t:,.0f}."

        elif any(w in q for w in ['top','best','merit','topper']):
            rows = self.db.fetchall("""
                SELECT s.full_name, ROUND(AVG(100.0*r.obtained_marks/NULLIF(r.total_marks,0)),1) as avg
                FROM results r JOIN students s ON r.student_id=s.id
                GROUP BY s.id ORDER BY avg DESC LIMIT 3
            """)
            if rows:
                names = ', '.join(f"{r['full_name']} ({r['avg']}%)" for r in rows)
                return f"Top performers: {names}"
            return "No result data available yet."

        elif 'result card' in q or 'generate result' in q:
            return "To generate result cards: Go to Results module → select Exam → Load Results → click Print button for each student."

        elif 'voucher' in q or 'fee voucher' in q:
            return "To generate fee vouchers: Go to Fee Management → click 'Generate Vouchers' → select month and class → click Generate."

        elif 'promote' in q:
            return "To promote students: Go to Settings → Promotions → select class → review results → click Promote."

        elif 'total student' in q or 'how many student' in q:
            r = self.db.fetchone("SELECT COUNT(*) as c FROM students WHERE status='active'")
            return f"Total active students: {r['c'] if r else 0}"

        elif 'class' in q and ('how many' in q or 'total' in q):
            r = self.db.fetchone("SELECT COUNT(*) as c FROM classes")
            return f"Total classes configured: {r['c'] if r else 0}"

        else:
            return (f"I understood your query: '{query}'. "
                    "Try asking: 'Show weak students', 'Absent students today', "
                    "'Unpaid fee vouchers', 'Top performers', 'Total students'.")
