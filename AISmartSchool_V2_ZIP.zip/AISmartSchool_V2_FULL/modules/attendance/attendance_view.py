"""Attendance V2 — QR attendance scanning support + manual marking"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QDate, QTimer
from ui.components.widgets import SectionHeader, ModernTable
from datetime import date
from core.color_utils import rgba


class AttendanceView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db   = db
        self.user = user
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20); layout.setSpacing(16)

        header = SectionHeader("Attendance", "Mark and review daily attendance")
        btn_mark = header.add_button("Mark Attendance", "btn_add", "✅")
        btn_mark.clicked.connect(self._mark_attendance)
        btn_qr = header.add_button("QR Scanner", "btn_primary", "📷")
        btn_qr.setStyleSheet("background:#8b5cf6;color:white;border-radius:8px;padding:8px 14px;font-weight:600;")
        btn_qr.clicked.connect(self._qr_attendance)
        btn_report = header.add_button("Report", "btn_primary", "📊")
        btn_report.setStyleSheet("background:#059669;color:white;border-radius:8px;padding:8px 14px;font-weight:600;")
        btn_report.clicked.connect(self._attendance_report)
        layout.addWidget(header)

        # Date + class filter
        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Date:"))
        self.date_edit = QDateEdit(); self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(QDate.currentDate()); self.date_edit.setMinimumHeight(40)
        self.date_edit.dateChanged.connect(self._load_attendance)
        ctrl.addWidget(self.date_edit)

        ctrl.addWidget(QLabel("Class:"))
        self.class_combo = QComboBox(); self.class_combo.setMinimumHeight(40)
        self.class_combo.addItem("All Classes")
        for c in self.db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_combo.addItem(c['name'], c['id'])
        self.class_combo.currentIndexChanged.connect(self._load_attendance)
        ctrl.addWidget(self.class_combo)

        ctrl.addWidget(QLabel("Section:"))
        self.section_combo = QComboBox(); self.section_combo.setMinimumHeight(40)
        self.section_combo.addItem("All Sections", 0)
        self.class_combo.currentIndexChanged.connect(self._reload_sections)
        ctrl.addWidget(self.section_combo)
        ctrl.addStretch()

        # Summary labels
        self.present_lbl = QLabel("Present: 0")
        self.absent_lbl  = QLabel("Absent: 0")
        self.late_lbl    = QLabel("Late: 0")
        for lbl, col in [(self.present_lbl,"#22c55e"),(self.absent_lbl,"#ef4444"),(self.late_lbl,"#f59e0b")]:
            lbl.setStyleSheet(f"color:{col};font-weight:700;font-size:13px;")
            ctrl.addWidget(lbl)

        layout.addLayout(ctrl)

        self.table = ModernTable(["#","Student","Roll No","Class","Section","P/A","Time In","QR","Actions"])
        self.table.set_fixed_column(0, 40)
        self.table.set_fixed_column(2, 80)
        self.table.set_fixed_column(5, 90)
        self.table.set_fixed_column(7, 60)
        self.table.set_fixed_column(8, 110)
        layout.addWidget(self.table)

        self._load_attendance()

    def _reload_sections(self):
        self.section_combo.clear()
        self.section_combo.addItem("All Sections", 0)
        cid = self.class_combo.currentData()
        if cid:
            for s in self.db.fetchall("SELECT id,name FROM sections WHERE class_id=?", (cid,)):
                self.section_combo.addItem(s['name'], s['id'])

    def _load_attendance(self):
        self.table.clear_rows()
        att_date = self.date_edit.date().toString("yyyy-MM-dd")
        cid      = self.class_combo.currentData() if self.class_combo.currentIndex() > 0 else None
        sec_id   = self.section_combo.currentData() if self.section_combo.currentIndex() > 0 else None

        q = """SELECT s.id as sid, s.full_name, s.roll_number, c.name as class_name,
                      sec.name as sec_name, s.class_id, s.section_id,
                      a.status as att_status, a.time_in, a.qr_verified
               FROM students s
               LEFT JOIN classes c ON s.class_id=c.id
               LEFT JOIN sections sec ON s.section_id=sec.id
               LEFT JOIN attendance a ON a.student_id=s.id AND a.date=?
               WHERE s.status='active'"""
        params = [att_date]
        if cid:
            q += " AND s.class_id=?"; params.append(cid)
        if sec_id:
            q += " AND s.section_id=?"; params.append(sec_id)
        q += " ORDER BY c.level, s.roll_number, s.full_name"

        rows = self.db.fetchall(q, params)
        present = absent = late = 0
        for i, r in enumerate(rows):
            status = r.get('att_status') or 'Not Marked'
            if status == 'present': present += 1
            elif status == 'absent': absent += 1
            elif status == 'late':   late += 1

            self.table.insertRow(i)
            self.table.setItem(i, 0, QTableWidgetItem(str(i+1)))
            self.table.setItem(i, 1, QTableWidgetItem(r.get('full_name','')))
            self.table.setItem(i, 2, QTableWidgetItem(r.get('roll_number','') or ''))
            self.table.setItem(i, 3, QTableWidgetItem(r.get('class_name','') or ''))
            self.table.setItem(i, 4, QTableWidgetItem(r.get('sec_name','') or ''))

            STATUS_DISPLAY = {
                "present": ("P",  "#22c55e"),
                "absent":  ("A",  "#ef4444"),
                "late":    ("L",  "#f59e0b"),
                "leave":   ("Lv", "#3b82f6"),
            }
            disp, color = STATUS_DISPLAY.get(status, ("—", "#64748b"))
            status_lbl = QLabel(disp)
            status_lbl.setToolTip(status.upper() if status != 'Not Marked' else 'Not Marked')
            status_lbl.setStyleSheet(
                f"color:{color};font-weight:800;font-size:13px;"
                f"padding:2px 8px;border:1px solid {rgba(color, '55')};"
                f"border-radius:4px;background:{rgba(color, '18')};"
            )
            status_lbl.setAlignment(Qt.AlignCenter)
            self.table.setCellWidget(i, 5, status_lbl)

            self.table.setItem(i, 6, QTableWidgetItem(r.get('time_in','') or ''))

            qr_lbl = QLabel("📷" if r.get('qr_verified') else "")
            qr_lbl.setAlignment(Qt.AlignCenter)
            self.table.setCellWidget(i, 7, qr_lbl)

            # Quick mark buttons
            aw = QWidget(); al = QHBoxLayout(aw)
            al.setContentsMargins(2,1,2,1); al.setSpacing(3)
            for lbl2, st, col in [("P","present","#22c55e"),("A","absent","#ef4444"),
                                   ("L","late","#f59e0b"),("Lv","leave","#3b82f6")]:
                b = QPushButton(lbl2); b.setFixedSize(26,26)
                b.setToolTip(st.upper())
                b.setStyleSheet(f"background:{rgba(col, '22')};color:{col};border:1px solid {rgba(col, '44')};border-radius:5px;font-size:10px;font-weight:700;")
                b.clicked.connect(lambda ch, sid=r['sid'], s=st, d=att_date: self._quick_mark(sid, s, d))
                al.addWidget(b)
            self.table.setCellWidget(i, 8, aw)

        self.present_lbl.setText(f"Present: {present}")
        self.absent_lbl.setText(f"Absent: {absent}")
        self.late_lbl.setText(f"Late: {late}")

    def _quick_mark(self, student_id, status, att_date):
        from datetime import datetime
        time_in = datetime.now().strftime("%H:%M") if status in ('present','late') else ""
        try:
            self.db.execute("""
                INSERT OR REPLACE INTO attendance (student_id, date, status, class_id, marked_by, time_in, qr_verified)
                SELECT ?, ?, ?, class_id, ?, ?, 0 FROM students WHERE id=?
            """, (student_id, att_date, status, self.user.get('id'), time_in, student_id))
        except Exception:
            self.db.execute("""
                INSERT OR REPLACE INTO attendance (student_id, date, status, marked_by, time_in, qr_verified)
                VALUES (?, ?, ?, ?, ?, 0)
            """, (student_id, att_date, status, self.user.get('id'), time_in))
        self._load_attendance()

    def _mark_attendance(self):
        dlg = BulkMarkDialog(self.db, self.user, self)
        if dlg.exec() == QDialog.Accepted:
            self._load_attendance()

    def _qr_attendance(self):
        dlg = QRAttendanceDialog(self.db, self.user, self)
        dlg.exec()
        self._load_attendance()

    def _attendance_report(self):
        dlg = AttendanceReportDialog(self.db, self)
        dlg.exec()


class QRAttendanceDialog(QDialog):
    """QR Code attendance scanner — paste/type QR data to mark present."""
    def __init__(self, db, user, parent=None):
        super().__init__(parent)
        self.db   = db
        self.user = user
        self.setWindowTitle("📷 QR Attendance Scanner")
        self.setMinimumSize(500, 400)
        layout = QVBoxLayout(self)

        info = QLabel(
            "Scan student QR code (USB QR scanner or webcam app).\n"
            "QR data format: STUDENT:<id>:<name>:<class>\n"
            "Paste or type the scanned data below and press Enter."
        )
        info.setStyleSheet("background:#1c2128;border-radius:8px;border:1px solid #30363d;"
                           "padding:10px;color:#94a3b8;font-size:12px;")
        info.setWordWrap(True)
        layout.addWidget(info)

        self.qr_input = QLineEdit()
        self.qr_input.setPlaceholderText("Paste QR data here...")
        self.qr_input.setMinimumHeight(44)
        self.qr_input.setStyleSheet("font-size:14px;padding:8px;")
        self.qr_input.returnPressed.connect(self._process_qr)
        layout.addWidget(self.qr_input)

        mark_btn = QPushButton("✅ Mark Present")
        mark_btn.setObjectName("btn_add")
        mark_btn.setMinimumHeight(42)
        mark_btn.clicked.connect(self._process_qr)
        layout.addWidget(mark_btn)

        self.log_table = QTableWidget(0, 4)
        self.log_table.setHorizontalHeaderLabels(["Time","Student","Status","QR Data"])
        self.log_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.log_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        layout.addWidget(self.log_table)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def _process_qr(self):
        raw = self.qr_input.text().strip()
        if not raw:
            return
        self.qr_input.clear()

        from datetime import datetime, date as dt_date
        today     = str(dt_date.today())
        time_now  = datetime.now().strftime("%H:%M:%S")
        student_id = None
        student_name = "Unknown"

        # Parse QR: STUDENT:<id>:<name>:<class section>
        if raw.startswith("STUDENT:"):
            parts = raw.split(":")
            if len(parts) >= 3:
                student_id   = parts[1].strip()
                student_name = parts[2].strip()

        if student_id:
            stu = self.db.fetchone("SELECT * FROM students WHERE student_id=?", (student_id,))
            if stu:
                student_name = stu.get('full_name', student_name)
                try:
                    self.db.execute("""
                        INSERT OR REPLACE INTO attendance
                        (student_id, date, status, class_id, marked_by, time_in, qr_verified)
                        VALUES (?, ?, 'present', ?, ?, ?, 1)
                    """, (stu['id'], today, stu.get('class_id'), self.user.get('id'), time_now))
                    status = "✅ Marked"
                except Exception as e:
                    status = f"Error: {e}"
            else:
                status = "❌ Student not found"
        else:
            status = "❌ Invalid QR"

        # Add to log
        row = self.log_table.rowCount()
        self.log_table.insertRow(row)
        self.log_table.setItem(row, 0, QTableWidgetItem(time_now))
        self.log_table.setItem(row, 1, QTableWidgetItem(student_name))
        self.log_table.setItem(row, 2, QTableWidgetItem(status))
        self.log_table.setItem(row, 3, QTableWidgetItem(raw[:40]))
        self.log_table.scrollToBottom()


class BulkMarkDialog(QDialog):
    def __init__(self, db, user, parent=None):
        super().__init__(parent)
        self.db = db; self.user = user
        self.setWindowTitle("Bulk Mark Attendance"); self.setMinimumSize(700,500)
        layout = QVBoxLayout(self)

        ctrl = QHBoxLayout()
        self.class_cb = QComboBox(); self.class_cb.setMinimumHeight(38)
        self.class_cb.addItem("Select Class")
        for c in db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_cb.addItem(c['name'], c['id'])
        self.date_edit = QDateEdit(); self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(QDate.currentDate()); self.date_edit.setMinimumHeight(38)
        load_btn = QPushButton("Load")
        load_btn.setStyleSheet("background:#2563eb;color:white;border-radius:8px;padding:8px 14px;")
        load_btn.clicked.connect(self._load)
        self.all_present_btn = QPushButton("✅ All Present")
        self.all_present_btn.setStyleSheet("background:#22c55e22;color:#22c55e;border:1px solid #22c55e44;border-radius:8px;padding:8px 14px;")
        self.all_present_btn.clicked.connect(self._all_present)
        ctrl.addWidget(QLabel("Class:")); ctrl.addWidget(self.class_cb)
        ctrl.addWidget(QLabel("Date:")); ctrl.addWidget(self.date_edit)
        ctrl.addWidget(load_btn); ctrl.addWidget(self.all_present_btn); ctrl.addStretch()
        layout.addLayout(ctrl)

        self.students_table = QTableWidget(0,4)
        self.students_table.setHorizontalHeaderLabels(["Name","Roll No","Status","Remarks"])
        self.students_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.students_table)

        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        btns.accepted.connect(self._save); btns.rejected.connect(self.reject)
        layout.addWidget(btns)
        self._students = []

    def _load(self):
        cid = self.class_cb.currentData()
        if not cid: return
        self._students = self.db.fetchall(
            "SELECT * FROM students WHERE class_id=? AND status='active' ORDER BY roll_number,full_name",
            (cid,))
        att_date = self.date_edit.date().toString("yyyy-MM-dd")
        self.students_table.setRowCount(len(self._students))
        for i, s in enumerate(self._students):
            existing = self.db.fetchone(
                "SELECT status FROM attendance WHERE student_id=? AND date=?",
                (s['id'], att_date))
            self.students_table.setItem(i, 0, QTableWidgetItem(s.get('full_name','')))
            self.students_table.setItem(i, 1, QTableWidgetItem(s.get('roll_number','') or ''))
            status_cb = QComboBox()
            status_cb.addItems(["present","absent","late","leave"])
            if existing:
                idx = status_cb.findText(existing.get('status','present'))
                if idx >= 0: status_cb.setCurrentIndex(idx)
            self.students_table.setCellWidget(i, 2, status_cb)
            self.students_table.setItem(i, 3, QTableWidgetItem(""))

    def _all_present(self):
        for row in range(self.students_table.rowCount()):
            cb = self.students_table.cellWidget(row, 2)
            if cb: cb.setCurrentText("present")

    def _save(self):
        att_date = self.date_edit.date().toString("yyyy-MM-dd")
        time_in = datetime.now().strftime("%H:%M")
        for i, stu in enumerate(self._students):
            cb = self.students_table.cellWidget(i, 2)
            if not cb: continue
            status = cb.currentText()
            remarks_item = self.students_table.item(i, 3)
            remarks = remarks_item.text() if remarks_item else ""
            ti = time_in if status in ('present','late') else ""
            self.db.execute("""
                INSERT OR REPLACE INTO attendance
                (student_id, date, status, class_id, marked_by, time_in, remarks, qr_verified)
                VALUES (?,?,?,?,?,?,?,0)
            """, (stu['id'], att_date, status, stu.get('class_id'), self.user.get('id'), ti, remarks))
        self.accept()


class AttendanceReportDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Attendance Report"); self.setMinimumSize(700, 480)
        layout = QVBoxLayout(self)

        ctrl = QHBoxLayout()
        self.class_cb = QComboBox(); self.class_cb.setMinimumHeight(38)
        self.class_cb.addItem("All Classes")
        for c in db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_cb.addItem(c['name'], c['id'])
        self.from_dt = QDateEdit(); self.from_dt.setCalendarPopup(True); self.from_dt.setMinimumHeight(38)
        from datetime import date, timedelta
        self.from_dt.setDate(QDate.currentDate().addDays(-30))
        self.to_dt   = QDateEdit(); self.to_dt.setCalendarPopup(True); self.to_dt.setMinimumHeight(38)
        self.to_dt.setDate(QDate.currentDate())
        load_btn = QPushButton("Generate Report")
        load_btn.setStyleSheet("background:#2563eb;color:white;border-radius:8px;padding:8px 14px;")
        load_btn.clicked.connect(self._generate)
        ctrl.addWidget(QLabel("Class:")); ctrl.addWidget(self.class_cb)
        ctrl.addWidget(QLabel("From:")); ctrl.addWidget(self.from_dt)
        ctrl.addWidget(QLabel("To:"));   ctrl.addWidget(self.to_dt)
        ctrl.addWidget(load_btn); ctrl.addStretch()
        layout.addLayout(ctrl)

        self.report_table = QTableWidget(0,6)
        self.report_table.setHorizontalHeaderLabels(["Student","Class","Present","Absent","Late","% Attendance"])
        self.report_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.report_table)
        layout.addWidget(QPushButton("Close", clicked=self.accept))

    def _generate(self):
        self.report_table.setRowCount(0)
        cid   = self.class_cb.currentData() if self.class_cb.currentIndex() > 0 else None
        from_d = self.from_dt.date().toString("yyyy-MM-dd")
        to_d   = self.to_dt.date().toString("yyyy-MM-dd")

        q = """SELECT s.id, s.full_name, c.name as class_name,
                      SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) as present_count,
                      SUM(CASE WHEN a.status='absent' THEN 1 ELSE 0 END) as absent_count,
                      SUM(CASE WHEN a.status='late' THEN 1 ELSE 0 END) as late_count,
                      COUNT(a.id) as total_days
               FROM students s
               LEFT JOIN classes c ON s.class_id=c.id
               LEFT JOIN attendance a ON a.student_id=s.id AND a.date BETWEEN ? AND ?
               WHERE s.status='active'"""
        params = [from_d, to_d]
        if cid:
            q += " AND s.class_id=?"; params.append(cid)
        q += " GROUP BY s.id ORDER BY c.level, s.full_name"

        for r in self.db.fetchall(q, params):
            row = self.report_table.rowCount()
            self.report_table.insertRow(row)
            total = r.get('total_days',0) or 0
            pct   = (r.get('present_count',0)/total*100) if total else 0
            self.report_table.setItem(row, 0, QTableWidgetItem(r.get('full_name','')))
            self.report_table.setItem(row, 1, QTableWidgetItem(r.get('class_name','')))
            self.report_table.setItem(row, 2, QTableWidgetItem(str(r.get('present_count',0))))
            self.report_table.setItem(row, 3, QTableWidgetItem(str(r.get('absent_count',0))))
            self.report_table.setItem(row, 4, QTableWidgetItem(str(r.get('late_count',0))))
            pct_item = QTableWidgetItem(f"{pct:.1f}%")
            pct_item.setForeground(Qt.green if pct >= 75 else Qt.red)
            self.report_table.setItem(row, 5, pct_item)
