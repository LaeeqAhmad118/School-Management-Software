"""Fee Management V2 — QR on vouchers, school info from SchoolContext, bulk print"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QDate
from ui.components.widgets import SectionHeader, SearchBar, ModernTable, StatusBadge, shadow
from core.school_context import SchoolContext
from datetime import date, datetime
from core.color_utils import rgba


class FeesView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db   = db
        self.user = user
        self._init_ui()
        self.refresh()

    def on_school_updated(self, info):
        pass   # voucher PDFs pull fresh info at generation time

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)

        header = SectionHeader("Fee Management", "Manage vouchers and payments")
        btn_gen   = header.add_button("Generate Vouchers", "btn_add", "➕")
        btn_gen.clicked.connect(self._gen_vouchers)
        btn_bulk  = header.add_button("Bulk Print", "btn_primary", "🖨")
        btn_bulk.setStyleSheet("background:#059669;color:white;border-radius:8px;padding:8px 14px;font-weight:600;")
        btn_bulk.clicked.connect(self._bulk_print)
        layout.addWidget(header)

        # Summary cards
        summary_row = QHBoxLayout()
        self.total_card   = self._summary_card("Total Due",       "Rs. 0", "#f59e0b")
        self.paid_card    = self._summary_card("Total Collected", "Rs. 0", "#22c55e")
        self.pending_card = self._summary_card("Pending",         "0",     "#3b82f6")
        self.overdue_card = self._summary_card("Overdue",         "0",     "#ef4444")
        for card in [self.total_card, self.paid_card, self.pending_card, self.overdue_card]:
            summary_row.addWidget(card)
        layout.addLayout(summary_row)

        tabs = QTabWidget()

        # All vouchers tab
        vt = QWidget(); vl = QVBoxLayout(vt)
        sr = QHBoxLayout()
        self.search = SearchBar("Search by voucher ID, student name...")
        self.search.textChanged.connect(self._filter)
        self.status_combo = QComboBox(); self.status_combo.setMinimumHeight(40)
        self.status_combo.addItems(["All","pending","paid","partial","overdue","cancelled"])
        self.status_combo.currentTextChanged.connect(self.refresh)
        self.class_combo = QComboBox(); self.class_combo.setMinimumHeight(40)
        self.class_combo.addItem("All Classes")
        for c in self.db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_combo.addItem(c['name'], c['id'])
        self.class_combo.currentIndexChanged.connect(self.refresh)
        sr.addWidget(self.search, 1); sr.addWidget(self.status_combo); sr.addWidget(self.class_combo)
        vl.addLayout(sr)
        self.table = ModernTable(["Voucher ID","Student","Class","Month","Total","Paid","Remaining","Status","Actions"])
        self.table.set_fixed_column(0, 110)
        self.table.set_fixed_column(7, 100)
        self.table.set_fixed_column(8, 200)
        vl.addWidget(self.table)
        tabs.addTab(vt, "📄 All Vouchers")

        # Fee Structures tab
        fs_tab = QWidget(); fs_l = QVBoxLayout(fs_tab)
        btn_add_fs = QPushButton("➕ Add Fee Structure")
        btn_add_fs.setObjectName("btn_add")
        btn_add_fs.clicked.connect(self._add_fee_structure)
        fs_l.addWidget(btn_add_fs, 0, Qt.AlignLeft)
        self.fs_table = ModernTable(["Class","Monthly Fee","Admission Fee","Exam Fee","Computer Fee","Transport Fee","Total","Actions"])
        self.fs_table.set_fixed_column(7, 140)
        fs_l.addWidget(self.fs_table)
        tabs.addTab(fs_tab, "💲 Fee Structures")
        layout.addWidget(tabs)
        self._load_fee_structures()

    def _summary_card(self, title, value, color):
        frame = QFrame()
        frame.setObjectName("summaryCard")
        frame.setStyleSheet(f"""
            QFrame#summaryCard {{
                background:#161b22; border-radius:12px;
                border:1px solid {rgba(color, '44')}; padding:4px;
            }}
            QFrame#summaryCard QLabel {{
                background: transparent;
                border: none;
            }}
        """)
        frame.setGraphicsEffect(shadow())
        fl = QVBoxLayout(frame)
        fl.setContentsMargins(16,12,16,12)
        t = QLabel(title); t.setStyleSheet(f"color:{color};font-size:11px;font-weight:700;background:transparent;")
        v = QLabel(value); v.setStyleSheet("color:#e6edf3;font-size:20px;font-weight:800;background:transparent;")
        fl.addWidget(t); fl.addWidget(v)
        frame._value_lbl = v
        return frame

    def refresh(self):
        self.table.clear_rows()
        status = self.status_combo.currentText()
        cid    = self.class_combo.currentData() if self.class_combo.currentIndex() > 0 else None

        q = """SELECT fv.*, s.full_name, s.student_id, c.name as class_name
               FROM fee_vouchers fv
               JOIN students s ON fv.student_id=s.id
               JOIN classes c ON s.class_id=c.id"""
        params = []
        wheres = []
        if status != "All":
            wheres.append("fv.status=?"); params.append(status)
        if cid:
            wheres.append("s.class_id=?"); params.append(cid)
        if wheres:
            q += " WHERE " + " AND ".join(wheres)
        q += " ORDER BY fv.id DESC"

        rows = self.db.fetchall(q, params)
        total_due = paid_total = pending_count = overdue_count = 0

        for r in rows:
            total_due    += r.get('total_amount',0) or 0
            paid_total   += r.get('paid_amount',0) or 0
            if r.get('status') == 'pending': pending_count += 1
            if r.get('status') == 'overdue': overdue_count += 1

            row_idx = self.table.rowCount()
            self.table.insertRow(row_idx)
            total_amt = r.get('total_amount') or 0
            paid_amt = r.get('paid_amount') or 0
            remaining = total_amt - paid_amt
            self.table.setItem(row_idx, 0, QTableWidgetItem(r.get('voucher_id','') or ''))
            self.table.setItem(row_idx, 1, QTableWidgetItem(r.get('full_name','') or ''))
            self.table.setItem(row_idx, 2, QTableWidgetItem(r.get('class_name','') or ''))
            self.table.setItem(row_idx, 3, QTableWidgetItem(f"{r.get('month','')} {r.get('year','')}"))
            self.table.setItem(row_idx, 4, QTableWidgetItem(f"Rs.{total_amt:,.0f}"))
            self.table.setItem(row_idx, 5, QTableWidgetItem(f"Rs.{paid_amt:,.0f}"))
            self.table.setItem(row_idx, 6, QTableWidgetItem(f"Rs.{remaining:,.0f}"))
            self.table.setCellWidget(row_idx, 7, StatusBadge(r.get('status','pending')))

            # Action buttons
            aw = QWidget(); al = QHBoxLayout(aw)
            al.setContentsMargins(4,2,4,2); al.setSpacing(4)
            for icon, tip, fn in [
                ("🖨", "Print Voucher",  lambda ch, row=r: self._print_voucher(row)),
                ("💳", "Record Payment", lambda ch, row=r: self._record_payment(row)),
                ("🗑", "Cancel",         lambda ch, row=r: self._cancel_voucher(row)),
            ]:
                b = QPushButton(icon); b.setToolTip(tip); b.setFixedSize(30,30)
                b.setStyleSheet("background:#1c2128;border:1px solid #30363d;border-radius:6px;font-size:13px;")
                b.clicked.connect(fn); al.addWidget(b)
            al.addStretch()
            self.table.setCellWidget(row_idx, 8, aw)

        self.total_card._value_lbl.setText(f"Rs.{total_due:,.0f}")
        self.paid_card._value_lbl.setText(f"Rs.{paid_total:,.0f}")
        self.pending_card._value_lbl.setText(str(pending_count))
        self.overdue_card._value_lbl.setText(str(overdue_count))

    def _filter(self, text):
        text = text.lower()
        for row in range(self.table.rowCount()):
            match = any(
                self.table.item(row, c) and text in self.table.item(row, c).text().lower()
                for c in range(7)
            )
            self.table.setRowHidden(row, not match)

    def _load_fee_structures(self):
        self.fs_table.clear_rows()
        rows = self.db.fetchall("""
            SELECT fs.*, c.name as class_name FROM fee_structures fs
            JOIN classes c ON fs.class_id=c.id ORDER BY c.level
        """)
        for r in rows:
            total = sum([r.get(k,0) or 0 for k in
                         ['monthly_fee','exam_fee','computer_fee','transport_fee','misc_charges']])
            del_btn = QPushButton("🗑 Delete")
            del_btn.setStyleSheet("background:#ef444422;color:#ef4444;border:none;border-radius:6px;padding:4px 8px;")
            del_btn.clicked.connect(lambda ch, rid=r['id']: self._del_fs(rid))
            self.fs_table.add_row([
                r.get('class_name',''),
                f"Rs.{r.get('monthly_fee',0):,.0f}",
                f"Rs.{r.get('admission_fee',0):,.0f}",
                f"Rs.{r.get('exam_fee',0):,.0f}",
                f"Rs.{r.get('computer_fee',0):,.0f}",
                f"Rs.{r.get('transport_fee',0):,.0f}",
                f"Rs.{total:,.0f}",
                ""
            ])
            last_row = self.fs_table.rowCount() - 1
            self.fs_table.setCellWidget(last_row, 7, del_btn)

    def _del_fs(self, fid):
        if QMessageBox.question(self,"Delete","Delete this fee structure?",
                                QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes:
            self.db.execute("DELETE FROM fee_structures WHERE id=?", (fid,))
            self._load_fee_structures()

    def _add_fee_structure(self):
        dlg = FeeStructureDialog(self.db, self)
        if dlg.exec() == QDialog.Accepted:
            self._load_fee_structures()

    def _gen_vouchers(self):
        dlg = GenerateVouchersDialog(self.db, self)
        if dlg.exec() == QDialog.Accepted:
            self.refresh()

    def _print_voucher(self, voucher_row):
        school_info = self.db.fetchone("SELECT * FROM school_info WHERE id=1") or {}
        # Enrich with student and class name
        stu = self.db.fetchone("""
            SELECT s.*, c.name as class_name FROM students s
            JOIN classes c ON s.class_id=c.id WHERE s.id=?
        """, (voucher_row.get('student_id'),))
        vdata = dict(voucher_row)
        if stu:
            vdata['student_name'] = stu.get('full_name','')
            vdata['class_name']   = stu.get('class_name','')
        try:
            from utils.pdf_generator import generate_fee_voucher
            generate_fee_voucher(vdata, school_info)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not generate voucher:\n{e}")

    def _bulk_print(self):
        """Print all visible (filtered) vouchers at once."""
        school_info = self.db.fetchone("SELECT * FROM school_info WHERE id=1") or {}
        vouchers = []
        for row in range(self.table.rowCount()):
            if self.table.isRowHidden(row): continue
            vid_item = self.table.item(row, 0)
            if not vid_item: continue
            vid = vid_item.text()
            r = self.db.fetchone("""
                SELECT fv.*, s.full_name as student_name, c.name as class_name
                FROM fee_vouchers fv
                JOIN students s ON fv.student_id=s.id
                JOIN classes c ON s.class_id=c.id
                WHERE fv.voucher_id=?
            """, (vid,))
            if r:
                vouchers.append(r)
        if not vouchers:
            QMessageBox.information(self, "No Vouchers", "No vouchers to print.")
            return
        reply = QMessageBox.question(self, "Bulk Print",
            f"Print {len(vouchers)} voucher(s) directly to printer?",
            QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            try:
                from utils.pdf_generator import bulk_fee_vouchers
                paths = bulk_fee_vouchers(vouchers, school_info, auto_print=True)
                QMessageBox.information(self, "Done", f"Printed {len(paths)} voucher(s).")
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def _record_payment(self, voucher_row):
        dlg = RecordPaymentDialog(voucher_row, self)
        if dlg.exec() == QDialog.Accepted:
            amount = dlg.amount
            method = dlg.method
            vid    = voucher_row.get('id')
            prev_status = voucher_row.get('status','pending')
            prev_paid = voucher_row.get('paid_amount') or 0
            total    = voucher_row.get('total_amount') or 0
            new_paid = prev_paid + amount
            new_status = 'paid' if new_paid >= total else 'partial'
            remaining = max(0, total - new_paid)
            self.db.execute("""
                UPDATE fee_vouchers SET paid_amount=?, remaining_amount=?,
                status=?, paid_date=?, payment_method=? WHERE id=?
            """, (new_paid, remaining, new_status, str(date.today()), method, vid))
            self.db.execute("""
                INSERT INTO voucher_history (voucher_id,changed_by,prev_status,new_status,prev_paid,new_paid,notes)
                VALUES (?,?,?,?,?,?,?)
            """, (vid, self.user.get('id'), prev_status, new_status, prev_paid, new_paid, f"Payment via {method}"))
            self.refresh()

    def _cancel_voucher(self, voucher_row):
        if QMessageBox.question(self, "Cancel", "Cancel this voucher?",
                                QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes:
            self.db.execute("UPDATE fee_vouchers SET status='cancelled' WHERE id=?",
                            (voucher_row.get('id'),))
            self.refresh()


class RecordPaymentDialog(QDialog):
    def __init__(self, voucher, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Record Payment")
        self.setMinimumWidth(360)
        self.amount = 0; self.method = "Cash"
        layout = QFormLayout(self)
        remaining = (voucher.get('total_amount',0) or 0) - (voucher.get('paid_amount',0) or 0)
        layout.addRow(QLabel(f"<b>Remaining: Rs. {remaining:,.0f}</b>"))
        self.amount_sb = QDoubleSpinBox()
        self.amount_sb.setRange(0, remaining)
        self.amount_sb.setValue(remaining)
        self.amount_sb.setPrefix("Rs. ")
        self.amount_sb.setMinimumHeight(38)
        self.method_cb = QComboBox()
        self.method_cb.addItems(["Cash","Bank Transfer","Cheque","Online"])
        self.method_cb.setMinimumHeight(38)
        layout.addRow("Amount:", self.amount_sb)
        layout.addRow("Method:", self.method_cb)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self._accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

    def _accept(self):
        self.amount = self.amount_sb.value()
        self.method = self.method_cb.currentText()
        self.accept()


class FeeStructureDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db; self.setWindowTitle("Add Fee Structure"); self.setMinimumWidth(420)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0); outer.setSpacing(0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        inner = QWidget()
        layout = QFormLayout(inner)
        layout.setContentsMargins(16, 16, 16, 16)
        scroll.setWidget(inner)
        outer.addWidget(scroll, 1)
        self.class_cb = QComboBox(); self.class_cb.setMinimumHeight(38)
        for c in db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_cb.addItem(c['name'], c['id'])
        def spin(v=0):
            s = QDoubleSpinBox(); s.setRange(0,999999); s.setValue(v)
            s.setPrefix("Rs. "); s.setMinimumHeight(38); return s
        self.monthly   = spin()
        self.admission = spin()
        self.exam      = spin()
        self.computer  = spin()
        self.transport = spin()
        self.misc      = spin()
        layout.addRow("Class:",          self.class_cb)
        layout.addRow("Monthly Fee:",    self.monthly)
        layout.addRow("Admission Fee:",  self.admission)
        layout.addRow("Exam Fee:",       self.exam)
        layout.addRow("Computer Fee:",   self.computer)
        layout.addRow("Transport Fee:",  self.transport)
        layout.addRow("Misc Charges:",   self.misc)
        footer = QFrame()
        footer.setObjectName("dialogFooter")
        footer.setStyleSheet(
            "QFrame#dialogFooter{background:transparent;border-top:1px solid #30363d;}"
            "QFrame#dialogFooter QLabel{background:transparent;border:none;}")
        frow = QVBoxLayout(footer); frow.setContentsMargins(16,12,16,12)
        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        btns.accepted.connect(self._save); btns.rejected.connect(self.reject)
        frow.addWidget(btns)
        outer.addWidget(footer, 0)

    def _save(self):
        cid = self.class_cb.currentData()
        if not cid: return
        self.db.execute("""
            INSERT OR REPLACE INTO fee_structures
            (class_id,monthly_fee,admission_fee,exam_fee,computer_fee,transport_fee,misc_charges)
            VALUES (?,?,?,?,?,?,?)
        """, (cid, self.monthly.value(), self.admission.value(), self.exam.value(),
              self.computer.value(), self.transport.value(), self.misc.value()))
        self.accept()


class GenerateVouchersDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db; self.setWindowTitle("Generate Fee Vouchers"); self.setMinimumWidth(440)
        layout = QFormLayout(self)
        self.class_cb = QComboBox(); self.class_cb.setMinimumHeight(38)
        self.class_cb.addItem("All Classes", None)
        for c in db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_cb.addItem(c['name'], c['id'])
        self.month_cb = QComboBox(); self.month_cb.setMinimumHeight(38)
        self.month_cb.addItems(["January","February","March","April","May","June",
                                 "July","August","September","October","November","December"])
        from datetime import datetime
        self.month_cb.setCurrentIndex(datetime.now().month - 1)
        self.year_sb = QSpinBox(); self.year_sb.setRange(2020,2040)
        self.year_sb.setValue(datetime.now().year); self.year_sb.setMinimumHeight(38)
        self.due_day = QSpinBox(); self.due_day.setRange(1,31); self.due_day.setValue(10); self.due_day.setMinimumHeight(38)
        layout.addRow("Class:", self.class_cb)
        layout.addRow("Month:", self.month_cb)
        layout.addRow("Year:",  self.year_sb)
        layout.addRow("Due Day:", self.due_day)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self._generate); btns.rejected.connect(self.reject)
        layout.addRow(btns)

    def _generate(self):
        cid   = self.class_cb.currentData()
        month = self.month_cb.currentText()
        year  = self.year_sb.value()
        due_d = self.due_day.value()
        q = "SELECT s.*, c.name as class_name FROM students s JOIN classes c ON s.class_id=c.id WHERE s.status='active'"
        params = []
        if cid:
            q += " AND s.class_id=?"; params.append(cid)
        students = self.db.fetchall(q, params)
        count = 0
        for stu in students:
            fs = self.db.fetchone(
                "SELECT * FROM fee_structures WHERE class_id=?", (stu.get('class_id'),))
            if not fs: continue
            total = sum([fs.get(k,0) or 0 for k in
                         ['monthly_fee','exam_fee','computer_fee','transport_fee','misc_charges']])
            if stu.get('transport') and fs.get('transport_fee'):
                total += fs.get('transport_fee',0)
            vid = f"V{year}{month[:3].upper()}{stu.get('student_id','')}"
            # Check if already generated
            existing = self.db.fetchone("SELECT id FROM fee_vouchers WHERE voucher_id=?", (vid,))
            if existing: continue
            due_date = f"{year}-{['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].index(month[:3])+1:02d}-{due_d:02d}"
            self.db.execute("""
                INSERT INTO fee_vouchers
                (voucher_id,student_id,month,year,monthly_fee,exam_fee,computer_fee,
                 transport_fee,misc_charges,total_amount,remaining_amount,due_date,status)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'pending')
            """, (vid, stu['id'], month, year,
                  fs.get('monthly_fee',0), fs.get('exam_fee',0), fs.get('computer_fee',0),
                  fs.get('transport_fee',0), fs.get('misc_charges',0),
                  total, total, due_date))
            count += 1
        QMessageBox.information(self, "Generated", f"Generated {count} new vouchers.")
        self.accept()
