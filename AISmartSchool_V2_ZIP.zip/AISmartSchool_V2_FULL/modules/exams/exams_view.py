"""Exam Management"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QDate
from ui.components.widgets import SectionHeader, ModernTable, StatusBadge


class ExamsView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self.role = user.get('role','')
        self._init_ui()
        self.refresh()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)
        header = SectionHeader("Examinations", "Manage exams and schedules")
        if self.role in ('admin','exam'):
            btn = header.add_button("Create Exam", "btn_add", "➕")
            btn.clicked.connect(self._create_exam)
        layout.addWidget(header)

        self.table = ModernTable(["ID","Exam Name","Type","Class","Start Date","End Date","Status","Actions"])
        self.table.set_fixed_column(0, 50)
        self.table.set_fixed_column(6, 100)
        self.table.set_fixed_column(7, 160)
        layout.addWidget(self.table)

    def refresh(self):
        self.table.clear_rows()
        rows = self.db.fetchall("""
            SELECT e.*, c.name as class_name FROM exams e
            LEFT JOIN classes c ON e.class_id=c.id
            ORDER BY e.id DESC
        """)
        for r in rows:
            ri = self.table.rowCount()
            self.table.insertRow(ri)
            self.table.setItem(ri, 0, QTableWidgetItem(str(r['id'])))
            self.table.setItem(ri, 1, QTableWidgetItem(r.get('name','') or ''))
            self.table.setItem(ri, 2, QTableWidgetItem(r.get('exam_type','') or ''))
            self.table.setItem(ri, 3, QTableWidgetItem(r.get('class_name','') or ''))
            self.table.setItem(ri, 4, QTableWidgetItem(str(r.get('start_date','') or '')))
            self.table.setItem(ri, 5, QTableWidgetItem(str(r.get('end_date','') or '')))
            badge = StatusBadge(r.get('status','scheduled'))
            self.table.setCellWidget(ri, 6, badge)
            w = QWidget(); l = QHBoxLayout(w); l.setContentsMargins(4,2,4,2)
            view_btn = QPushButton("👁 View")
            view_btn.setStyleSheet("background:#6b7280;color:white;border-radius:5px;padding:3px 8px;font-size:11px;")
            view_btn.clicked.connect(lambda ch, eid=r['id']: self._view_exam(eid))
            l.addWidget(view_btn)
            if self.role in ('admin','exam'):
                pub_btn = QPushButton("📢 Publish")
                pub_btn.setStyleSheet("background:#8b5cf6;color:white;border-radius:5px;padding:3px 8px;font-size:11px;")
                pub_btn.clicked.connect(lambda ch, eid=r['id']: self._publish(eid))
                l.addWidget(pub_btn)
            l.addStretch()
            self.table.setCellWidget(ri, 7, w)
            self.table.setRowHeight(ri, 44)

    def _create_exam(self):
        dlg = ExamDialog(self.db, self)
        if dlg.exec() == QDialog.Accepted:
            self.refresh()

    def _view_exam(self, eid):
        r = self.db.fetchone("SELECT * FROM exams WHERE id=?", (eid,))
        if r:
            QMessageBox.information(self, "Exam Details",
                f"<b>{r['name']}</b><br>Type: {r['exam_type']}<br>"
                f"Start: {r['start_date']}<br>End: {r['end_date']}<br>Status: {r['status'].upper()}")

    def _publish(self, eid):
        self.db.execute("UPDATE exams SET status='published' WHERE id=?", (eid,))
        self.refresh()


class ExamDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Create Exam")
        self.setMinimumWidth(500)
        self._init_ui()

    def _init_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0); outer.setSpacing(0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        inner = QWidget()
        layout = QVBoxLayout(inner)
        layout.setContentsMargins(16, 16, 16, 16)
        scroll.setWidget(inner)
        outer.addWidget(scroll, 1)
        g = QGridLayout()
        g.setSpacing(10)

        self.name = QLineEdit(); self.name.setPlaceholderText("Exam name"); self.name.setMinimumHeight(38)
        self.exam_type = QComboBox()
        self.exam_type.addItems(["Monthly Test","Mid Exam","Final Exam","Practical Exam"])
        self.exam_type.setMinimumHeight(38)
        self.class_combo = QComboBox(); self.class_combo.setMinimumHeight(38)
        for c in self.db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_combo.addItem(c['name'], c['id'])
        self.start_date = QDateEdit(); self.start_date.setCalendarPopup(True); self.start_date.setDate(QDate.currentDate()); self.start_date.setMinimumHeight(38)
        self.end_date = QDateEdit(); self.end_date.setCalendarPopup(True); self.end_date.setDate(QDate.currentDate()); self.end_date.setMinimumHeight(38)
        self.result_date = QDateEdit(); self.result_date.setCalendarPopup(True); self.result_date.setDate(QDate.currentDate()); self.result_date.setMinimumHeight(38)

        for i, (lbl, w) in enumerate([
            ("Exam Name *", self.name), ("Exam Type", self.exam_type),
            ("Class", self.class_combo), ("Start Date", self.start_date),
            ("End Date", self.end_date), ("Result Date", self.result_date),
        ]):
            g.addWidget(QLabel(lbl), i, 0)
            g.addWidget(w, i, 1)

        layout.addLayout(g)
        layout.addStretch()
        footer = QFrame()
        footer.setObjectName("dialogFooter")
        footer.setStyleSheet(
            "QFrame#dialogFooter{background:transparent;border-top:1px solid #30363d;}"
            "QFrame#dialogFooter QLabel{background:transparent;border:none;}")
        btn_row = QHBoxLayout(footer)
        btn_row.setContentsMargins(16, 12, 16, 12)
        btn_row.addStretch()
        cancel = QPushButton("Cancel"); cancel.setObjectName("btn_cancel"); cancel.clicked.connect(self.reject)
        save = QPushButton("Create Exam"); save.setObjectName("btn_add"); save.clicked.connect(self._save)
        btn_row.addWidget(cancel); btn_row.addWidget(save)
        outer.addWidget(footer, 0)

    def _save(self):
        if not self.name.text().strip():
            QMessageBox.warning(self, "Required", "Exam name is required.")
            return
        
        cid = self.class_combo.currentData()
        
        # Create the exam
        self.db.execute("""
            INSERT INTO exams (name,exam_type,class_id,start_date,end_date,result_date,status)
            VALUES (?,?,?,?,?,?,?)
        """, (
            self.name.text().strip(), self.exam_type.currentText(),
            cid,
            self.start_date.date().toString("yyyy-MM-dd"),
            self.end_date.date().toString("yyyy-MM-dd"),
            self.result_date.date().toString("yyyy-MM-dd"), "scheduled"
        ))
        
        # Get the exam ID that was just created
        eid = self.db.fetchone(
            "SELECT id FROM exams WHERE name=? AND class_id=? ORDER BY id DESC LIMIT 1",
            (self.name.text().strip(), cid)
        )['id']
        
        # AUTOMATICALLY assign ALL subjects of this class to the exam
        subjects = self.db.fetchall(
            "SELECT id FROM subjects WHERE class_id=?", (cid,))
        
        for s in subjects:
            self.db.execute("""
                INSERT OR IGNORE INTO exam_subjects (exam_id, subject_id, total_marks, passing_marks)
                VALUES (?,?,100,40)
            """, (eid, s['id']))
        
        subject_count = len(subjects)
        QMessageBox.information(self, "Success", 
            f"Exam '{self.name.text()}' created!\n"
            f"Automatically assigned {subject_count} subject(s) from {self.class_combo.currentText()}")
        self.accept()
