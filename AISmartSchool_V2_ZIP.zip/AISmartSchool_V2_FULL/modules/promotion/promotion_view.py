"""
Promotion Module
─────────────────────────────────────────────────────────────────────────────
Rules:
  • Regular class  → student promoted to the next class (by level).
  • Final class    → student moved to Alumni (passed students) section.
  • Failing student can be held back (not promoted) with a remark.

Alumni section:
  • Shows all ex-students who completed the final class.
  • Searchable, printable, shows their final result and passed-out year.
"""
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QDialog,
    QComboBox, QCheckBox, QTextEdit, QMessageBox, QFrame,
    QTabWidget, QScrollArea, QAbstractItemView, QLineEdit,
    QProgressBar, QSizePolicy
)
from core.color_utils import rgba
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QColor
from ui.components.widgets import SectionHeader, shadow, icon_btn, cell_widget
from datetime import datetime


# ─────────────────────────────────────────────────────────────────────────────
# Worker thread — promotion runs in background to avoid UI freeze on large sets
# ─────────────────────────────────────────────────────────────────────────────
class PromotionWorker(QThread):
    progress   = Signal(int, str)   # (percent, message)
    finished   = Signal(dict)       # result summary dict
    error      = Signal(str)

    def __init__(self, db, decisions, from_class_id, to_class_id,
                 is_final, session_id, promoted_by):
        super().__init__()
        self.db           = db
        self.decisions    = decisions   # {student_id: {'promote': bool, 'remark': str}}
        self.from_class   = from_class_id
        self.to_class     = to_class_id
        self.is_final     = is_final
        self.session_id   = session_id
        self.promoted_by  = promoted_by

    def run(self):
        promoted = held = alumni_added = 0
        total = len(self.decisions)
        try:
            for idx, (sid, dec) in enumerate(self.decisions.items()):
                pct = int((idx + 1) / total * 100)
                name = dec.get('name', f'Student {sid}')
                self.progress.emit(pct, f"Processing {name}…")

                if not dec.get('promote', True):
                    # Hold back — record but don't change class
                    self.db.execute(
                        """INSERT INTO promotions
                           (student_id, from_class_id, to_class_id,
                            from_session_id, to_session_id,
                            promoted_by, status, remarks, promoted_at)
                           VALUES (?,?,?,?,?,?,?,?,datetime('now'))""",
                        (sid, self.from_class, self.from_class,
                         self.session_id, self.session_id,
                         self.promoted_by, 'held_back', dec.get('remark', ''))
                    )
                    held += 1
                    continue

                if self.is_final:
                    # ── Final class → Alumni ──────────────────────────────
                    # Calculate final result
                    res = self.db.fetchone(
                        """SELECT
                               SUM(r.obtained_marks) as obt,
                               SUM(r.total_marks)    as tot
                           FROM results r
                           JOIN exams e ON r.exam_id = e.id
                           WHERE r.student_id = ?
                             AND e.exam_type   = 'Final Exam'""", (sid,))
                    obt = res.get('obt', 0) or 0 if res else 0
                    tot = res.get('tot', 0) or 100 if res else 100
                    pct_val = obt / tot * 100 if tot else 0
                    final_result = _grade_label(pct_val)

                    # Mark student as alumni
                    self.db.execute(
                        "UPDATE students SET status='alumni' WHERE id=?", (sid,))

                    # Insert/replace alumni record
                    year = datetime.now().year
                    self.db.execute(
                        """INSERT OR REPLACE INTO alumni
                           (student_id, passed_out_year, final_class_id, final_result)
                           VALUES (?,?,?,?)""",
                        (sid, year, self.from_class, final_result))

                    # Promotion log
                    self.db.execute(
                        """INSERT INTO promotions
                           (student_id, from_class_id, to_class_id,
                            from_session_id, to_session_id,
                            promoted_by, status, remarks, promoted_at)
                           VALUES (?,?,NULL,?,?,?,?,?,datetime('now'))""",
                        (sid, self.from_class,
                         self.session_id, self.session_id,
                         self.promoted_by, 'alumni',
                         dec.get('remark', '') or 'Completed final class'))

                    alumni_added += 1

                else:
                    # ── Regular class → next class ────────────────────────
                    self.db.execute(
                        "UPDATE students SET class_id=?, section_id=NULL WHERE id=?",
                        (self.to_class, sid))

                    # Promotion log
                    self.db.execute(
                        """INSERT INTO promotions
                           (student_id, from_class_id, to_class_id,
                            from_session_id, to_session_id,
                            promoted_by, status, remarks, promoted_at)
                           VALUES (?,?,?,?,?,?,?,?,datetime('now'))""",
                        (sid, self.from_class, self.to_class,
                         self.session_id, self.session_id,
                         self.promoted_by, 'promoted',
                         dec.get('remark', '')))

                    promoted += 1

            self.finished.emit({
                'promoted': promoted,
                'held':     held,
                'alumni':   alumni_added,
                'total':    total,
            })

        except Exception as e:
            self.error.emit(str(e))


def _grade_label(pct):
    if pct >= 90: return "A+ (Distinction)"
    if pct >= 80: return "A  (Excellent)"
    if pct >= 70: return "B+ (Very Good)"
    if pct >= 60: return "B  (Good)"
    if pct >= 50: return "C  (Satisfactory)"
    if pct >= 40: return "D  (Pass)"
    return "F  (Fail)"


# ─────────────────────────────────────────────────────────────────────────────
# Main View
# ─────────────────────────────────────────────────────────────────────────────
class PromotionView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db   = db
        self.user = user
        self._worker = None
        self._decisions = {}    # {student_id: {'promote': bool, 'remark': str, 'name': str}}
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)

        layout.addWidget(
            SectionHeader("Promotion & Alumni",
                          "Promote students to next class or move to Alumni"))

        tabs = QTabWidget()
        tabs.addTab(self._build_promotion_tab(), "🎓  Promote Students")
        tabs.addTab(self._build_alumni_tab(),    "🏆  Alumni / Passed Students")
        tabs.addTab(self._build_history_tab(),   "📋  Promotion History")
        layout.addWidget(tabs)

    # ─────────────────────────────────────────────────────────────────
    # Tab 1 — Promotion
    # ─────────────────────────────────────────────────────────────────
    def _build_promotion_tab(self):
        w  = QWidget()
        vl = QVBoxLayout(w)
        vl.setContentsMargins(16, 16, 16, 16)
        vl.setSpacing(14)

        # ── Info banner ───────────────────────────────────────────────
        banner = QFrame()
        banner.setStyleSheet(
            "background:#1e3a8a22;border:1px solid #2563eb44;"
            "border-radius:10px;padding:10px 14px;")
        bl = QHBoxLayout(banner); bl.setContentsMargins(8, 6, 8, 6)
        bl.addWidget(QLabel("ℹ️", styleSheet="font-size:18px;"))
        info_txt = QLabel(
            "Select a class and its <b>Final Exam</b> to see student results. "
            "Tick <b>Promote</b> to move each student up. "
            "Students in the <b>final class</b> will be moved to the Alumni section. "
            "Un-tick a student to hold them back.")
        info_txt.setStyleSheet("color:#93c5fd;font-size:12px;")
        info_txt.setWordWrap(True)
        bl.addWidget(info_txt, 1)
        vl.addWidget(banner)

        # ── Controls ──────────────────────────────────────────────────
        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Class:", styleSheet="color:#e6edf3;font-weight:600;"))
        self.class_combo = QComboBox()
        self.class_combo.setMinimumHeight(40)
        self.class_combo.setMinimumWidth(180)
        self._reload_classes()
        self.class_combo.currentIndexChanged.connect(self._on_class_changed)
        ctrl.addWidget(self.class_combo)

        ctrl.addWidget(QLabel("Final Exam:", styleSheet="color:#e6edf3;font-weight:600;"))
        self.exam_combo = QComboBox()
        self.exam_combo.setMinimumHeight(40)
        self.exam_combo.setMinimumWidth(200)
        ctrl.addWidget(self.exam_combo)

        load_btn = QPushButton("📥  Load Students")
        load_btn.setMinimumHeight(40)
        load_btn.setStyleSheet(
            "background:#2563eb;color:white;border-radius:8px;"
            "padding:8px 16px;font-weight:700;")
        load_btn.clicked.connect(self._load_students_for_promotion)
        ctrl.addWidget(load_btn)
        ctrl.addStretch()

        # Select all / deselect all shortcuts
        sel_all = QPushButton("✅  Select All")
        sel_all.setMinimumHeight(38)
        sel_all.setStyleSheet(
            "background:#22c55e22;color:#22c55e;border:1px solid #22c55e44;"
            "border-radius:8px;padding:6px 14px;font-size:12px;")
        sel_all.clicked.connect(lambda: self._toggle_all(True))
        desel_all = QPushButton("⬜  Deselect All")
        desel_all.setMinimumHeight(38)
        desel_all.setStyleSheet(
            "background:#ef444422;color:#ef4444;border:1px solid #ef444444;"
            "border-radius:8px;padding:6px 14px;font-size:12px;")
        desel_all.clicked.connect(lambda: self._toggle_all(False))
        ctrl.addWidget(sel_all)
        ctrl.addWidget(desel_all)
        vl.addLayout(ctrl)

        # ── Destination class label ───────────────────────────────────
        self.dest_lbl = QLabel("")
        self.dest_lbl.setStyleSheet(
            "color:#f59e0b;font-size:12px;font-weight:600;")
        vl.addWidget(self.dest_lbl)

        # ── Student table ─────────────────────────────────────────────
        self.promo_table = QTableWidget()
        self.promo_table.setColumnCount(7)
        self.promo_table.setHorizontalHeaderLabels([
            "Promote", "Roll #", "Student Name",
            "Total Marks", "Obtained", "Percentage", "Remark"])
        self.promo_table.verticalHeader().setVisible(False)
        hh = self.promo_table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        hh.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(5, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(6, QHeaderView.ResizeToContents)
        self.promo_table.setAlternatingRowColors(True)
        self.promo_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        vl.addWidget(self.promo_table)

        # ── Progress bar (hidden until promotion runs) ────────────────
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setStyleSheet(
            "QProgressBar{border-radius:6px;background:#1c2128;height:18px;}"
            "QProgressBar::chunk{background:#2563eb;border-radius:6px;}")
        self.progress_lbl = QLabel("")
        self.progress_lbl.setStyleSheet("color:#8b949e;font-size:11px;")
        vl.addWidget(self.progress_bar)
        vl.addWidget(self.progress_lbl)

        # ── Promote button ────────────────────────────────────────────
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self.promote_btn = QPushButton("🎓  Run Promotion")
        self.promote_btn.setMinimumHeight(46)
        self.promote_btn.setMinimumWidth(200)
        self.promote_btn.setStyleSheet(
            "background:#16a34a;color:white;border-radius:10px;"
            "font-size:14px;font-weight:700;padding:10px 24px;")
        self.promote_btn.clicked.connect(self._confirm_promotion)
        self.promote_btn.setEnabled(False)
        btn_row.addWidget(self.promote_btn)
        vl.addLayout(btn_row)

        return w

    def _reload_classes(self):
        self.class_combo.clear()
        self.class_combo.addItem("── Select Class ──", None)
        for c in self.db.fetchall(
                "SELECT id,name,level,is_final_class FROM classes ORDER BY level"):
            label = c['name']
            if c.get('is_final_class'):
                label += "  ⭐ (Final)"
            self.class_combo.addItem(label, c['id'])

    def _on_class_changed(self):
        self.promo_table.setRowCount(0)
        self.promote_btn.setEnabled(False)
        self.dest_lbl.setText("")
        cid = self.class_combo.currentData()
        if not cid:
            self.exam_combo.clear()
            return

        # Populate exams for this class (Final Exam type only)
        self.exam_combo.clear()
        self.exam_combo.addItem("── Select Final Exam ──", None)
        for e in self.db.fetchall(
                "SELECT id,name FROM exams WHERE class_id=? AND exam_type='Final Exam' ORDER BY id DESC",
                (cid,)):
            self.exam_combo.addItem(e['name'], e['id'])

        # Show destination
        cls_row = self.db.fetchone(
            "SELECT name,level,is_final_class FROM classes WHERE id=?", (cid,))
        if cls_row and cls_row.get('is_final_class'):
            self.dest_lbl.setText(
                "⭐ This is the FINAL class — promoted students will be moved to Alumni.")
        else:
            next_cls = self.db.fetchone(
                "SELECT name FROM classes WHERE level > ? ORDER BY level LIMIT 1",
                (cls_row.get('level', 0) if cls_row else 0,))
            if next_cls:
                self.dest_lbl.setText(
                    f"→  Promoted students will move to: {next_cls['name']}")
            else:
                self.dest_lbl.setText(
                    "⚠️  No next class found. Please add a higher-level class in Settings.")

    def _load_students_for_promotion(self):
        cid  = self.class_combo.currentData()
        eid  = self.exam_combo.currentData()
        if not cid:
            QMessageBox.warning(self, "Select Class", "Please select a class."); return
        if not eid:
            QMessageBox.warning(self, "Select Exam",
                "Please select a Final Exam.\n\n"
                "If none listed, create a 'Final Exam' type exam in Examinations module first.")
            return

        students = self.db.fetchall(
            """SELECT s.id, s.full_name, s.roll_number
               FROM students s
               WHERE s.class_id = ? AND s.status = 'active'
               ORDER BY CAST(s.roll_number AS INTEGER), s.full_name""",
            (cid,))

        if not students:
            QMessageBox.information(
                self, "No Students",
                "No active students found in this class."); return

        self.promo_table.setRowCount(0)
        self._decisions = {}

        cls_row = self.db.fetchone(
            "SELECT is_final_class FROM classes WHERE id=?", (cid,))
        is_final = bool(cls_row and cls_row.get('is_final_class'))

        for s in students:
            sid  = s['id']
            name = s.get('full_name', '') or ''
            roll = s.get('roll_number', '') or ''

            # Fetch result for this exam
            result = self.db.fetchone(
                """SELECT SUM(obtained_marks) as obt, SUM(total_marks) as tot
                   FROM results WHERE student_id=? AND exam_id=?""",
                (sid, eid))
            obt = result.get('obt', 0) or 0 if result else 0
            tot = result.get('tot', 0) or 0 if result else 0
            pct = obt / tot * 100 if tot else 0
            passed = pct >= 40

            ri = self.promo_table.rowCount()
            self.promo_table.insertRow(ri)

            # Col 0: Promote checkbox
            cb = QCheckBox()
            cb.setChecked(passed)
            cb.setStyleSheet("margin-left:8px;")
            cb.stateChanged.connect(
                lambda state, r=ri, s_id=sid: self._on_checkbox(r, s_id, state))
            self.promo_table.setCellWidget(ri, 0, cb)

            self.promo_table.setItem(ri, 1, QTableWidgetItem(roll))
            self.promo_table.setItem(ri, 2, QTableWidgetItem(name))

            tot_item = QTableWidgetItem(f"{tot:.0f}" if tot else "—")
            tot_item.setTextAlignment(Qt.AlignCenter)
            obt_item = QTableWidgetItem(f"{obt:.0f}" if tot else "—")
            obt_item.setTextAlignment(Qt.AlignCenter)

            pct_txt = f"{pct:.1f}%" if tot else "No Results"
            pct_item = QTableWidgetItem(pct_txt)
            pct_item.setTextAlignment(Qt.AlignCenter)
            if tot:
                pct_item.setForeground(
                    QColor("#22c55e") if passed else QColor("#ef4444"))

            self.promo_table.setItem(ri, 3, tot_item)
            self.promo_table.setItem(ri, 4, obt_item)
            self.promo_table.setItem(ri, 5, pct_item)

            # Col 6: editable remark
            remark_item = QTableWidgetItem(
                "" if passed else "Hold back — failed exam")
            self.promo_table.setItem(ri, 6, remark_item)
            self.promo_table.item(ri, 6).setFlags(
                Qt.ItemIsEnabled | Qt.ItemIsEditable)

            self.promo_table.setRowHeight(ri, 40)

            self._decisions[sid] = {
                'promote': passed,
                'remark':  "" if passed else "Hold back — failed exam",
                'name':    name,
            }

        self.promo_table.setEditTriggers(QAbstractItemView.DoubleClicked)
        self.promote_btn.setEnabled(True)

        # Summary row at bottom
        promote_count = sum(1 for d in self._decisions.values() if d['promote'])
        hold_count    = len(self._decisions) - promote_count
        tag = "→ Alumni" if is_final else "→ Next Class"
        QMessageBox.information(
            self, "Students Loaded",
            f"<b>{len(students)}</b> students loaded.<br><br>"
            f"✅  <b>{promote_count}</b> eligible for promotion {tag}<br>"
            f"❌  <b>{hold_count}</b> will be held back<br><br>"
            "You can change any decision by toggling the checkbox.")

    def _on_checkbox(self, row, student_id, state):
        promote = (state == Qt.Checked)
        if student_id in self._decisions:
            self._decisions[student_id]['promote'] = promote
            # Update remark default
            remark_item = self.promo_table.item(row, 6)
            if remark_item:
                if not promote and not remark_item.text():
                    remark_item.setText("Hold back — manual decision")
                elif promote and remark_item.text() == "Hold back — manual decision":
                    remark_item.setText("")

    def _toggle_all(self, state):
        for ri in range(self.promo_table.rowCount()):
            cb = self.promo_table.cellWidget(ri, 0)
            if isinstance(cb, QCheckBox):
                cb.setChecked(state)

    def _confirm_promotion(self):
        if not self._decisions:
            return

        # Sync remark text from table into decisions
        for ri in range(self.promo_table.rowCount()):
            cb = self.promo_table.cellWidget(ri, 0)
            remark_item = self.promo_table.item(ri, 6)
            # Find student_id by name match
            name_item = self.promo_table.item(ri, 2)
            if name_item:
                for sid, dec in self._decisions.items():
                    if dec.get('name') == name_item.text():
                        if isinstance(cb, QCheckBox):
                            dec['promote'] = cb.isChecked()
                        if remark_item:
                            dec['remark'] = remark_item.text()
                        break

        cid = self.class_combo.currentData()
        cls_row = self.db.fetchone(
            "SELECT name,level,is_final_class FROM classes WHERE id=?", (cid,))
        is_final = bool(cls_row and cls_row.get('is_final_class'))

        # Find destination class
        to_class_id = None
        if not is_final:
            next_cls = self.db.fetchone(
                "SELECT id,name FROM classes WHERE level > ? ORDER BY level LIMIT 1",
                (cls_row.get('level', 0),))
            if not next_cls:
                QMessageBox.critical(
                    self, "No Next Class",
                    "Cannot promote: no class with higher level found.\n"
                    "Please add the next class in Settings → Classes."); return
            to_class_id = next_cls['id']
            to_name = next_cls['name']
        else:
            to_name = "Alumni"

        promote_count = sum(1 for d in self._decisions.values() if d['promote'])
        hold_count    = len(self._decisions) - promote_count

        msg = (f"<b>Confirm Promotion for {cls_row['name']}</b><br><br>"
               f"✅  <b>{promote_count}</b> students → {to_name}<br>"
               f"❌  <b>{hold_count}</b> students held back<br><br>"
               "<b>This action cannot be undone.</b><br>"
               "Proceed?")
        reply = QMessageBox.question(self, "Confirm Promotion", msg,
                                     QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            return

        # Get active session
        session = self.db.fetchone(
            "SELECT id FROM academic_sessions WHERE is_active=1 ORDER BY id DESC LIMIT 1")
        session_id = session['id'] if session else None

        self._run_promotion(cid, to_class_id, is_final, session_id)

    def _run_promotion(self, from_class, to_class, is_final, session_id):
        self.promote_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)

        self._worker = PromotionWorker(
            db=self.db,
            decisions=self._decisions,
            from_class_id=from_class,
            to_class_id=to_class,
            is_final=is_final,
            session_id=session_id,
            promoted_by=self.user.get('id'),
        )
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_progress(self, pct, msg):
        self.progress_bar.setValue(pct)
        self.progress_lbl.setText(msg)

    def _on_finished(self, summary):
        self.progress_bar.setValue(100)
        self.progress_bar.setVisible(False)
        self.progress_lbl.setText("")
        self.promote_btn.setEnabled(True)
        self.promo_table.setRowCount(0)
        self._decisions = {}
        self._reload_classes()

        QMessageBox.information(
            self, "✅  Promotion Complete",
            f"<b>Promotion completed successfully!</b><br><br>"
            f"🎓  Promoted to next class: <b>{summary['promoted']}</b><br>"
            f"🏆  Moved to Alumni:        <b>{summary['alumni']}</b><br>"
            f"❌  Held back:              <b>{summary['held']}</b><br>"
            f"────────────────────<br>"
            f"📊  Total processed:        <b>{summary['total']}</b>")

    def _on_error(self, msg):
        self.progress_bar.setVisible(False)
        self.promote_btn.setEnabled(True)
        QMessageBox.critical(self, "Promotion Error", f"An error occurred:\n\n{msg}")

    # ─────────────────────────────────────────────────────────────────
    # Tab 2 — Alumni
    # ─────────────────────────────────────────────────────────────────
    def _build_alumni_tab(self):
        w  = QWidget()
        vl = QVBoxLayout(w)
        vl.setContentsMargins(16, 16, 16, 16)
        vl.setSpacing(12)

        # Search + filter row
        ctrl = QHBoxLayout()
        self.alumni_search = QLineEdit()
        self.alumni_search.setPlaceholderText("🔍  Search by name, ID or year…")
        self.alumni_search.setMinimumHeight(40)
        self.alumni_search.setMinimumWidth(300)
        self.alumni_search.textChanged.connect(self._filter_alumni)
        ctrl.addWidget(self.alumni_search)

        self.alumni_year_combo = QComboBox()
        self.alumni_year_combo.setMinimumHeight(40)
        self.alumni_year_combo.addItem("All Years", None)
        for y in range(datetime.now().year, datetime.now().year - 20, -1):
            self.alumni_year_combo.addItem(str(y), y)
        self.alumni_year_combo.currentIndexChanged.connect(self._filter_alumni)
        ctrl.addWidget(QLabel("Year:", styleSheet="color:#e6edf3;"))
        ctrl.addWidget(self.alumni_year_combo)
        ctrl.addStretch()

        refresh_btn = QPushButton("🔄  Refresh")
        refresh_btn.setMinimumHeight(38)
        refresh_btn.setStyleSheet(
            "background:#1c2128;color:#60a5fa;border:1px solid #30363d;"
            "border-radius:8px;padding:6px 14px;font-size:12px;")
        refresh_btn.clicked.connect(self._load_alumni)
        ctrl.addWidget(refresh_btn)

        export_btn = QPushButton("📤  Export")
        export_btn.setMinimumHeight(38)
        export_btn.setStyleSheet(
            "background:#f97316;color:white;border-radius:8px;"
            "padding:6px 14px;font-size:12px;font-weight:600;")
        export_btn.clicked.connect(self._export_alumni)
        ctrl.addWidget(export_btn)
        vl.addLayout(ctrl)

        # Summary cards
        self.alumni_summary = QHBoxLayout()
        vl.addLayout(self.alumni_summary)

        # Table
        self.alumni_table = QTableWidget()
        self.alumni_table.setColumnCount(7)
        self.alumni_table.setHorizontalHeaderLabels([
            "Student ID", "Name", "Final Class",
            "Passed Year", "Final Result", "Father Name", "Contact"])
        self.alumni_table.verticalHeader().setVisible(False)
        hh = self.alumni_table.horizontalHeader()
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        hh.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        for i in (0, 2, 3, 5, 6):
            hh.setSectionResizeMode(i, QHeaderView.ResizeToContents)
        self.alumni_table.setAlternatingRowColors(True)
        self.alumni_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        vl.addWidget(self.alumni_table)

        self._load_alumni()
        return w

    def _load_alumni(self):
        self._all_alumni = self.db.fetchall(
            """SELECT s.student_id, s.full_name, s.father_name, s.father_phone,
                      c.name as class_name,
                      a.passed_out_year, a.final_result,
                      a.id as alumni_id
               FROM alumni a
               JOIN students s ON a.student_id = s.id
               LEFT JOIN classes c ON a.final_class_id = c.id
               ORDER BY a.passed_out_year DESC, s.full_name""")

        # Summary cards
        while self.alumni_summary.count():
            item = self.alumni_summary.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        total = len(self._all_alumni)
        years = len(set(r.get('passed_out_year') for r in self._all_alumni if r.get('passed_out_year')))
        this_year = sum(1 for r in self._all_alumni
                        if r.get('passed_out_year') == datetime.now().year)

        for title, val, color in [
            ("Total Alumni",  str(total),     "#2563eb"),
            ("Passed Years",  str(years),     "#8b5cf6"),
            ("This Year",     str(this_year), "#22c55e"),
        ]:
            f = QFrame()
            f.setStyleSheet(
                f"background:#1c2128;border:1px solid {rgba(color, '44')};"
                f"border-radius:10px;padding:12px 16px;")
            fl = QVBoxLayout(f); fl.setSpacing(4)
            vl2 = QLabel(val)
            vl2.setStyleSheet(
                f"color:{color};font-size:22px;font-weight:700;")
            vl2.setAlignment(Qt.AlignCenter)
            tl = QLabel(title)
            tl.setStyleSheet("color:#8b949e;font-size:11px;")
            tl.setAlignment(Qt.AlignCenter)
            fl.addWidget(vl2); fl.addWidget(tl)
            self.alumni_summary.addWidget(f)
        self.alumni_summary.addStretch()

        self._render_alumni(self._all_alumni)

    def _filter_alumni(self):
        term = self.alumni_search.text().lower()
        year = self.alumni_year_combo.currentData()
        rows = self._all_alumni if hasattr(self, '_all_alumni') else []
        if term:
            rows = [r for r in rows if
                    term in (r.get('full_name','') or '').lower() or
                    term in (r.get('student_id','') or '').lower() or
                    term in str(r.get('passed_out_year','') or '')]
        if year:
            rows = [r for r in rows if r.get('passed_out_year') == year]
        self._render_alumni(rows)

    def _render_alumni(self, rows):
        self.alumni_table.setRowCount(0)
        for r in rows:
            ri = self.alumni_table.rowCount()
            self.alumni_table.insertRow(ri)
            for ci, val in enumerate([
                r.get('student_id',''),
                r.get('full_name',''),
                r.get('class_name',''),
                str(r.get('passed_out_year','') or ''),
                r.get('final_result',''),
                r.get('father_name',''),
                r.get('father_phone','') or '',
            ]):
                item = QTableWidgetItem(str(val) if val else '—')
                if ci == 4:  # final result
                    if 'A' in str(val).upper():
                        item.setForeground(QColor("#22c55e"))
                    elif 'F' in str(val).upper():
                        item.setForeground(QColor("#ef4444"))
                self.alumni_table.setItem(ri, ci, item)
            self.alumni_table.setRowHeight(ri, 36)

    def _export_alumni(self):
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
            from PySide6.QtWidgets import QFileDialog
            path, _ = QFileDialog.getSaveFileName(
                self, "Export Alumni", "alumni_list.xlsx",
                "Excel Files (*.xlsx)")
            if not path:
                return
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Alumni"
            headers = ["Student ID","Name","Final Class",
                       "Year","Final Result","Father","Contact"]
            for ci, h in enumerate(headers, 1):
                cell = ws.cell(1, ci, h)
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="1E3A8A")
                cell.alignment = Alignment(horizontal="center")
            rows = self._all_alumni if hasattr(self, '_all_alumni') else []
            for ri, r in enumerate(rows, 2):
                for ci, key in enumerate([
                    'student_id','full_name','class_name',
                    'passed_out_year','final_result','father_name','father_phone'
                ], 1):
                    ws.cell(ri, ci, r.get(key,'') or '')
            wb.save(path)
            QMessageBox.information(self, "Exported",
                f"✅ Alumni list exported:\n{path}")
        except ImportError:
            QMessageBox.warning(self, "Missing Library",
                "Run: pip install openpyxl")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", str(e))

    # ─────────────────────────────────────────────────────────────────
    # Tab 3 — Promotion History
    # ─────────────────────────────────────────────────────────────────
    def _build_history_tab(self):
        w  = QWidget()
        vl = QVBoxLayout(w)
        vl.setContentsMargins(16, 16, 16, 16)
        vl.setSpacing(12)

        ctrl = QHBoxLayout()
        self.hist_class = QComboBox()
        self.hist_class.setMinimumHeight(38)
        self.hist_class.addItem("All Classes", None)
        for c in self.db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.hist_class.addItem(c['name'], c['id'])
        self.hist_class.currentIndexChanged.connect(self._load_history)
        ctrl.addWidget(QLabel("Class:", styleSheet="color:#e6edf3;"))
        ctrl.addWidget(self.hist_class)

        self.hist_status = QComboBox()
        self.hist_status.setMinimumHeight(38)
        self.hist_status.addItems(["All Statuses","promoted","held_back","alumni"])
        self.hist_status.currentIndexChanged.connect(self._load_history)
        ctrl.addWidget(QLabel("Status:", styleSheet="color:#e6edf3;"))
        ctrl.addWidget(self.hist_status)
        ctrl.addStretch()

        undo_hint = QLabel("ℹ  Contact admin to reverse a promotion if needed.")
        undo_hint.setStyleSheet("color:#8b949e;font-size:11px;")
        ctrl.addWidget(undo_hint)
        vl.addLayout(ctrl)

        self.hist_table = QTableWidget()
        self.hist_table.setColumnCount(7)
        self.hist_table.setHorizontalHeaderLabels([
            "Date", "Student", "From Class",
            "To Class / Status", "Promoted By", "Status", "Remarks"])
        self.hist_table.verticalHeader().setVisible(False)
        hh = self.hist_table.horizontalHeader()
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        for i in (0, 2, 3, 4, 5, 6):
            hh.setSectionResizeMode(i, QHeaderView.ResizeToContents)
        self.hist_table.setAlternatingRowColors(True)
        self.hist_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        vl.addWidget(self.hist_table)

        self._load_history()
        return w

    def _load_history(self):
        cid    = self.hist_class.currentData()
        status = self.hist_status.currentText()

        q = """SELECT p.promoted_at, s.full_name, s.student_id,
                      fc.name as from_class, tc.name as to_class,
                      u.full_name as promoted_by,
                      p.status, p.remarks
               FROM promotions p
               JOIN students s  ON p.student_id     = s.id
               LEFT JOIN classes fc ON p.from_class_id = fc.id
               LEFT JOIN classes tc ON p.to_class_id   = tc.id
               LEFT JOIN users  u  ON p.promoted_by    = u.id
               WHERE 1=1"""
        params = []
        if cid:
            q += " AND p.from_class_id=?"; params.append(cid)
        if status not in ("All Statuses", ""):
            q += " AND p.status=?"; params.append(status)
        q += " ORDER BY p.promoted_at DESC LIMIT 500"

        self.hist_table.setRowCount(0)
        for r in self.db.fetchall(q, params):
            ri = self.hist_table.rowCount()
            self.hist_table.insertRow(ri)

            date_str = str(r.get('promoted_at','') or '')[:16]
            to_val   = r.get('to_class','') or ('Alumni' if r.get('status')=='alumni' else '—')
            status_val = r.get('status','') or ''

            for ci, val in enumerate([
                date_str,
                f"{r.get('full_name','')}  ({r.get('student_id','')})",
                r.get('from_class','') or '—',
                to_val,
                r.get('promoted_by','') or 'System',
                status_val.replace('_',' ').title(),
                r.get('remarks','') or '',
            ]):
                item = QTableWidgetItem(str(val))
                if ci == 5:
                    color_map = {
                        'Promoted':  '#22c55e',
                        'Alumni':    '#f59e0b',
                        'Held Back': '#ef4444',
                    }
                    item.setForeground(
                        QColor(color_map.get(str(val), '#8b949e')))
                self.hist_table.setItem(ri, ci, item)
            self.hist_table.setRowHeight(ri, 36)
