"""Backup & Restore — Fix 2: working backup history scan, proper restore, auto-backup"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QTimer
import os, shutil
from datetime import datetime
from ui.components.widgets import SectionHeader, shadow, icon_btn, cell_widget
from core.color_utils import rgba


class BackupView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db = db; self.user = user
        self._init_ui()
        self._load_backups()
        self._setup_auto_backup()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20); layout.setSpacing(16)
        layout.addWidget(SectionHeader("Backup & Restore", "Protect your school data"))

        # ── 3 action cards ────────────────────────────────────────────
        cards = QHBoxLayout(); cards.setSpacing(16)
        for title, desc, ico, color, fn, btn_text in [
            ("Manual Backup",
             "Create an immediate backup of all school data.",
             "💾", "#22c55e", self._manual_backup, "💾  Backup Now"),
            ("Restore Backup",
             "Restore data from a previously saved .db backup file.",
             "🔄", "#f59e0b", self._restore_backup, "🔄  Restore"),
            ("Export Database",
             "Export the raw SQLite file for external storage or migration.",
             "📤", "#2563eb", self._export_db, "📤  Export"),
        ]:
            f = QFrame()
            f.setMinimumHeight(165)
            f.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            f.setStyleSheet(
                f"QFrame{{background:#1c2128;border:1px solid {rgba(color, '44')};"
                f"border-radius:12px;}}"
                f"QFrame:hover{{border:1px solid {color};}}"
                f"QFrame QLabel{{background:transparent;border:none;}}")
            fl = QVBoxLayout(f); fl.setContentsMargins(16, 14, 16, 14); fl.setSpacing(6)

            top = QHBoxLayout()
            il = QLabel(ico); il.setStyleSheet("font-size:26px;")
            tl = QLabel(title); tl.setStyleSheet("color:white;font-size:14px;font-weight:700;")
            top.addWidget(il); top.addWidget(tl); top.addStretch()
            fl.addLayout(top)

            dl = QLabel(desc)
            dl.setStyleSheet("color:#8b949e;font-size:11px;")
            dl.setWordWrap(True)
            fl.addWidget(dl); fl.addStretch()

            btn = QPushButton(btn_text)
            btn.setMinimumHeight(36)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(
                f"background:{color};color:white;border-radius:7px;"
                f"padding:6px 14px;font-weight:700;font-size:12px;")
            btn.clicked.connect(fn)
            fl.addWidget(btn)
            shadow(f); cards.addWidget(f)
        layout.addLayout(cards)

        # ── Auto backup ───────────────────────────────────────────────
        af = QFrame()
        af.setStyleSheet("background:#1c2128;border:1px solid #30363d;border-radius:10px;padding:14px;")
        afl = QVBoxLayout(af); afl.setSpacing(8)
        afl.addWidget(QLabel("⚙  Auto Backup Settings",
                             styleSheet="color:#e6edf3;font-size:13px;font-weight:700;"))
        row = QHBoxLayout()
        self.auto_backup_cb = QCheckBox("Enable automatic daily backup")
        self.auto_backup_cb.setChecked(True)
        row.addWidget(self.auto_backup_cb); row.addStretch()
        afl.addLayout(row)
        layout.addWidget(af)

        # ── History ───────────────────────────────────────────────────
        layout.addWidget(QLabel("📋  Backup History",
                                styleSheet="color:#e6edf3;font-size:14px;font-weight:700;"))

        self.backup_table = QTableWidget()
        self.backup_table.setColumnCount(5)
        self.backup_table.setHorizontalHeaderLabels(
            ["Filename", "Size", "Created", "Created By", "Actions"])
        self.backup_table.verticalHeader().setVisible(False)
        hh = self.backup_table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.Stretch)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(4, QHeaderView.Fixed)
        self.backup_table.setColumnWidth(4, 90)
        self.backup_table.setAlternatingRowColors(True)
        self.backup_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.backup_table.setMinimumHeight(200)
        layout.addWidget(self.backup_table)

    # ── Backup dir — scoped PER SCHOOL so backups never mix between schools ─
    def _get_backup_dir(self):
        school_tag = os.path.splitext(os.path.basename(self.db.db_path))[0]
        d = os.path.join(os.path.expanduser("~"), ".ai_eduhub_erp", "backups", school_tag)
        os.makedirs(d, exist_ok=True)
        return d

    # ── Actions ───────────────────────────────────────────────────────
    def _manual_backup(self):
        bdir = self._get_backup_dir()
        ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
        fname = f"backup_{ts}.db"
        dest  = os.path.join(bdir, fname)
        try:
            shutil.copy2(self.db.db_path, dest)
            size = os.path.getsize(dest)
            self.db.execute(
                "INSERT INTO backups (filename,path,size,created_by) VALUES (?,?,?,?)",
                (fname, dest, size, self.user.get('id')))
            self._load_backups()
            QMessageBox.information(
                self, "Backup Created",
                f"✅ Backup saved:\n{dest}\nSize: {size // 1024} KB")
        except Exception as e:
            QMessageBox.critical(self, "Backup Failed", str(e))

    def _restore_backup(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Backup File", self._get_backup_dir(),
            "Database Files (*.db *.sqlite)")
        if not path:
            return
        if QMessageBox.warning(
                self, "⚠️ Confirm Restore",
                "This will REPLACE all current data for THIS school with the backup.\n"
                "Other schools are not affected. This cannot be undone. Continue?",
                QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes:
            self._do_restore(path)

    def _export_db(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Database",
            f"ai_eduhub_erp_export_{datetime.now().strftime('%Y%m%d')}.db",
            "Database Files (*.db)")
        if not path:
            return
        try:
            shutil.copy2(self.db.db_path, path)
            QMessageBox.information(self, "Exported", f"✅ Database exported:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", str(e))

    def _do_restore(self, path):
        if not os.path.exists(path):
            QMessageBox.warning(self, "File Not Found", f"Backup not found:\n{path}")
            return
        try:
            # Close the live connection first so the file can be safely
            # overwritten (and to avoid a half-written/locked DB file).
            if getattr(self.db, "_connection", None):
                try:
                    self.db._connection.close()
                except Exception:
                    pass
                self.db._connection = None
            shutil.copy2(path, self.db.db_path)
            # Reopen so the rest of this session keeps working immediately.
            self.db.get_connection()
            QMessageBox.information(
                self, "Restored",
                "✅ Backup restored successfully for this school.\n"
                "Please restart the application to ensure all screens reload the new data.")
        except Exception as e:
            QMessageBox.critical(self, "Restore Failed", str(e))

    # ── FIX 2: Load backups — scan dir + DB, no duplicate inserts ─────
    def _load_backups(self):
        # First sync filesystem → DB (add any .db files not in DB)
        bdir = self._get_backup_dir()
        try:
            for fname in sorted(os.listdir(bdir), reverse=True)[:50]:
                if not fname.endswith(".db"):
                    continue
                fpath = os.path.join(bdir, fname)
                exists = self.db.fetchone(
                    "SELECT id FROM backups WHERE filename=?", (fname,))
                if not exists:
                    size = os.path.getsize(fpath)
                    self.db.execute(
                        "INSERT INTO backups (filename,path,size) VALUES (?,?,?)",
                        (fname, fpath, size))
        except Exception:
            pass

        # Now load from DB
        self.backup_table.setRowCount(0)
        rows = self.db.fetchall(
            "SELECT b.*, u.username FROM backups b "
            "LEFT JOIN users u ON b.created_by = u.id "
            "ORDER BY b.id DESC")

        for r in rows:
            ri = self.backup_table.rowCount()
            self.backup_table.insertRow(ri)

            fname = r.get('filename', '') or ''
            fpath = r.get('path', '') or ''
            exists_on_disk = os.path.exists(fpath) if fpath else False

            # Filename (gray if file missing)
            fn_item = QTableWidgetItem(fname)
            if not exists_on_disk:
                fn_item.setForeground(
                    __import__('PySide6.QtGui', fromlist=['QColor']).QColor("#6b7280"))
                fn_item.setToolTip("File not found on disk")
            self.backup_table.setItem(ri, 0, fn_item)

            size_kb = (r.get('size', 0) or 0) // 1024
            self.backup_table.setItem(ri, 1, QTableWidgetItem(f"{size_kb} KB"))
            self.backup_table.setItem(ri, 2, QTableWidgetItem(
                str(r.get('created_at', '') or '')[:19]))
            self.backup_table.setItem(ri, 3, QTableWidgetItem(
                r.get('username', '') or 'System'))

            # Action: restore (only if file exists) + delete record
            restore_btn = icon_btn("🔄", "#f59e0b", "Restore this backup")
            restore_btn.setEnabled(exists_on_disk)
            if not exists_on_disk:
                restore_btn.setToolTip("File missing on disk")
            restore_btn.clicked.connect(
                lambda ch, p=fpath: self._confirm_restore(p))

            del_btn = icon_btn("🗑", "#ef4444", "Delete backup record")
            del_btn.clicked.connect(
                lambda ch, rid=r['id'], fp=fpath: self._delete_backup(rid, fp))

            self.backup_table.setCellWidget(ri, 4, cell_widget([restore_btn, del_btn]))
            self.backup_table.setRowHeight(ri, 40)

    def _confirm_restore(self, path):
        if QMessageBox.warning(
                self, "⚠️ Confirm Restore",
                "Restore this backup? All current data will be replaced.",
                QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes:
            self._do_restore(path)

    def _delete_backup(self, record_id, fpath):
        reply = QMessageBox.question(
            self, "Delete Backup",
            "Delete this backup record?\n(Also deletes the file from disk if it exists.)",
            QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            return
        self.db.execute("DELETE FROM backups WHERE id=?", (record_id,))
        if fpath and os.path.exists(fpath):
            try:
                os.remove(fpath)
            except Exception:
                pass
        self._load_backups()

    # ── Auto backup ───────────────────────────────────────────────────
    def _setup_auto_backup(self):
        self._auto_timer = QTimer()
        self._auto_timer.timeout.connect(self._check_auto_backup)
        self._auto_timer.start(3_600_000)  # check every hour

    def _check_auto_backup(self):
        if not self.auto_backup_cb.isChecked():
            return
        last = self.db.fetchone("SELECT MAX(created_at) as last FROM backups")
        if last and last.get('last'):
            try:
                from datetime import timedelta
                last_dt = datetime.fromisoformat(str(last['last']))
                if (datetime.now() - last_dt).total_seconds() < 86400:
                    return
            except Exception:
                pass
        self._manual_backup()
