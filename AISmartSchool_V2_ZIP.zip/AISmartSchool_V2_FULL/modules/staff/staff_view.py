"""Staff Management"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QDate
from ui.components.widgets import SectionHeader, ModernTable, StatusBadge


class StaffView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db = db; self.user = user
        self._init_ui(); self.refresh()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24,20,24,20); layout.setSpacing(16)
        header = SectionHeader("Staff & HR","Manage teachers and staff")
        btn = header.add_button("Add Staff","btn_add","➕")
        btn.clicked.connect(self._add)
        layout.addWidget(header)
        tabs = QTabWidget()
        st = QWidget(); sl = QVBoxLayout(st)
        self.table = ModernTable(["Emp ID","Name","Designation","Phone","Email","Salary","Status","Actions"])
        self.table.set_fixed_column(0, 90)
        self.table.set_fixed_column(6, 100)
        self.table.set_fixed_column(7, 140)
        sl.addWidget(self.table)
        tabs.addTab(st,"👥 All Staff")
        sal_tab = QWidget(); sal_l = QVBoxLayout(sal_tab)
        btn_sal = QPushButton("➕ Process Salary")
        btn_sal.setStyleSheet("background:#22c55e;color:white;border-radius:8px;padding:8px 16px;font-weight:600;")
        btn_sal.clicked.connect(self._process_salary)
        sal_l.addWidget(btn_sal, 0, Qt.AlignLeft)
        self.sal_table = ModernTable(["Staff","Month","Basic","Allowances","Deductions","Net","Status"])
        sal_l.addWidget(self.sal_table)
        tabs.addTab(sal_tab,"💰 Salary")
        layout.addWidget(tabs)

    def refresh(self):
        self.table.clear_rows()
        rows = self.db.fetchall("SELECT * FROM staff ORDER BY id DESC")
        for r in rows:
            ri = self.table.rowCount(); self.table.insertRow(ri)
            self.table.setItem(ri,0,QTableWidgetItem(r.get('employee_id','') or ''))
            self.table.setItem(ri,1,QTableWidgetItem(r.get('full_name','') or ''))
            self.table.setItem(ri,2,QTableWidgetItem(r.get('designation','') or ''))
            self.table.setItem(ri,3,QTableWidgetItem(r.get('phone','') or ''))
            self.table.setItem(ri,4,QTableWidgetItem(r.get('email','') or ''))
            self.table.setItem(ri,5,QTableWidgetItem(f"Rs.{r.get('salary',0) or 0:,.0f}"))
            self.table.setCellWidget(ri,6,StatusBadge(r.get('status','active')))
            from ui.components.widgets import icon_btn, cell_widget
            eb = icon_btn("✏", "#2563eb", "Edit Staff")
            eb.clicked.connect(lambda ch, rid=r['id']: self._edit(rid))
            # FIX 3: Delete staff
            db_btn = icon_btn("🗑", "#ef4444", "Delete Staff Member")
            db_btn.clicked.connect(
                lambda ch, rid=r['id'], nm=r.get('full_name',''): self._delete_staff(rid, nm))
            self.table.setCellWidget(ri, 7, cell_widget([eb, db_btn]))
            self.table.setRowHeight(ri, 40)

    def _add(self):
        from core.demo_config import DEMO_MODE, DEMO_MAX_STAFF
        if DEMO_MODE:
            count = self.db.fetchone("SELECT COUNT(*) c FROM staff") or {"c": 0}
            if count["c"] >= DEMO_MAX_STAFF:
                from ui.components.demo_dialogs import show_upgrade_dialog
                show_upgrade_dialog(self,
                    f"The Demo Edition is limited to {DEMO_MAX_STAFF} staff members.")
                return
        dlg = StaffDialog(self.db, self)
        if dlg.exec()==QDialog.Accepted: self.refresh()

    def _edit(self, sid):
        r = self.db.fetchone("SELECT * FROM staff WHERE id=?", (sid,))
        dlg = StaffDialog(self.db, self, r)
        if dlg.exec()==QDialog.Accepted: self.refresh()

    def _process_salary(self):
        dlg = SalaryDialog(self.db, self)
        if dlg.exec()==QDialog.Accepted: self._load_salaries()

    def _load_salaries(self):
        self.sal_table.clear_rows()
        rows = self.db.fetchall("""
            SELECT sr.*,s.full_name FROM salary_records sr
            JOIN staff s ON sr.staff_id=s.id ORDER BY sr.id DESC LIMIT 100
        """)
        for r in rows:
            self.sal_table.add_row([
                r.get('full_name',''),f"{r.get('month','')} {r.get('year','')}",
                f"Rs.{r.get('basic_salary',0) or 0:,.0f}",
                f"Rs.{r.get('allowances',0) or 0:,.0f}",
                f"Rs.{r.get('deductions',0) or 0:,.0f}",
                f"Rs.{r.get('net_salary',0) or 0:,.0f}",
                (r.get('status','') or '').upper()
            ])



    def _delete_staff(self, sid, name):
        """FIX 3: Admin can delete any staff member."""
        reply = QMessageBox.warning(
            self, "⚠️ Delete Staff",
            f"Permanently delete <b>{name}</b>?<br><br>"
            "Their attendance, leave, and salary records will also be deleted.",
            QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            return
        try:
            self.db.execute("DELETE FROM staff_attendance WHERE staff_id=?", (sid,))
            self.db.execute("DELETE FROM leave_requests  WHERE staff_id=?", (sid,))
            self.db.execute("DELETE FROM salary_records  WHERE staff_id=?", (sid,))
            self.db.execute("DELETE FROM staff           WHERE id=?",        (sid,))
            self.refresh()
            QMessageBox.information(self, "Deleted", f"Staff member '{name}' deleted.")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


class StaffDialog(QDialog):
    def __init__(self, db, parent=None, data=None):
        super().__init__(parent)
        self.db = db; self.data = data
        self.setWindowTitle("Add Staff" if not data else "Edit Staff")
        self.setMinimumWidth(500); self._init_ui()
        if data: self._populate(data)

    def _init_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0); outer.setSpacing(0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        inner = QWidget()
        layout = QVBoxLayout(inner)
        layout.setContentsMargins(16, 16, 16, 16)
        scroll.setWidget(inner)
        outer.addWidget(scroll, 1)
        g = QGridLayout(); g.setSpacing(10)
        def inp(ph=""): e=QLineEdit(); e.setPlaceholderText(ph); e.setMinimumHeight(38); return e
        def combo(items): c=QComboBox(); c.addItems(items); c.setMinimumHeight(38); return c
        self.full_name=inp("Full name"); self.designation=inp("e.g. Teacher, Principal")
        self.department=inp("Department"); self.phone=inp("03XXXXXXXXX")
        self.email=inp("Email"); self.cnic=inp("CNIC")
        self.qualification=inp("Qualification"); self.joining_date=QDateEdit()
        self.joining_date.setCalendarPopup(True); self.joining_date.setDate(QDate.currentDate()); self.joining_date.setMinimumHeight(38)
        self.salary=QDoubleSpinBox(); self.salary.setMaximum(9999999); self.salary.setMinimumHeight(38)
        self.status=combo(["active","inactive","terminated"])
        for i,(lbl,w) in enumerate([
            ("Full Name *",self.full_name),("Designation",self.designation),
            ("Department",self.department),("Phone",self.phone),("Email",self.email),
            ("CNIC",self.cnic),("Qualification",self.qualification),
            ("Joining Date",self.joining_date),("Salary",self.salary),("Status",self.status)
        ]):
            g.addWidget(QLabel(lbl),i,0); g.addWidget(w,i,1)
        layout.addLayout(g)
        layout.addStretch()
        footer = QFrame()
        footer.setObjectName("dialogFooter")
        footer.setStyleSheet(
            "QFrame#dialogFooter{background:transparent;border-top:1px solid #30363d;}"
            "QFrame#dialogFooter QLabel{background:transparent;border:none;}")
        br=QHBoxLayout(footer); br.setContentsMargins(16,12,16,12); br.addStretch()
        cancel=QPushButton("Cancel"); cancel.setObjectName("btn_cancel"); cancel.clicked.connect(self.reject)
        save=QPushButton("Save"); save.setObjectName("btn_add"); save.clicked.connect(self._save)
        br.addWidget(cancel); br.addWidget(save)
        outer.addWidget(footer, 0)

    def _populate(self, d):
        self.full_name.setText(d.get('full_name','') or '')
        self.designation.setText(d.get('designation','') or '')
        self.department.setText(d.get('department','') or '')
        self.phone.setText(d.get('phone','') or '')
        self.email.setText(d.get('email','') or '')
        self.cnic.setText(d.get('cnic','') or '')
        self.qualification.setText(d.get('qualification','') or '')
        self.salary.setValue(d.get('salary',0) or 0)

    def _save(self):
        if not self.full_name.text().strip():
            QMessageBox.warning(self,"Required","Name required."); return
        try:
            if self.data:
                self.db.execute("""UPDATE staff SET full_name=?,designation=?,department=?,phone=?,
                    email=?,cnic=?,qualification=?,salary=?,status=? WHERE id=?""",
                    (self.full_name.text(),self.designation.text(),self.department.text(),
                     self.phone.text(),self.email.text(),self.cnic.text(),
                     self.qualification.text(),self.salary.value(),
                     self.status.currentText(),self.data['id']))
            else:
                count=self.db.fetchone("SELECT COUNT(*) as c FROM staff")
                eid=f"EMP{(count['c']+1):04d}"
                self.db.execute("""INSERT INTO staff (employee_id,full_name,designation,department,
                    phone,email,cnic,qualification,joining_date,salary,status) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                    (eid,self.full_name.text(),self.designation.text(),self.department.text(),
                     self.phone.text(),self.email.text(),self.cnic.text(),
                     self.qualification.text(),self.joining_date.date().toString("yyyy-MM-dd"),
                     self.salary.value(),"active"))
            self.accept()
        except Exception as e: QMessageBox.critical(self,"Error",str(e))


class SalaryDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db; self.setWindowTitle("Process Salary"); self.setMinimumWidth(420)
        layout = QVBoxLayout(self)
        g = QGridLayout(); g.setSpacing(10)
        g.addWidget(QLabel("Staff Member"),0,0)
        self.staff_combo=QComboBox(); self.staff_combo.setMinimumHeight(38)
        for s in self.db.fetchall("SELECT id,full_name FROM staff WHERE status='active'"):
            self.staff_combo.addItem(s['full_name'],s['id'])
        g.addWidget(self.staff_combo,0,1)
        from datetime import datetime
        g.addWidget(QLabel("Month"),1,0)
        self.month=QComboBox()
        self.month.addItems(["January","February","March","April","May","June","July","August","September","October","November","December"])
        self.month.setCurrentIndex(datetime.now().month-1); self.month.setMinimumHeight(38)
        g.addWidget(self.month,1,1)
        g.addWidget(QLabel("Year"),2,0)
        self.year=QSpinBox(); self.year.setRange(2020,2040); self.year.setValue(datetime.now().year); self.year.setMinimumHeight(38)
        g.addWidget(self.year,2,1)
        g.addWidget(QLabel("Allowances"),3,0)
        self.allowances=QDoubleSpinBox(); self.allowances.setMaximum(999999); self.allowances.setMinimumHeight(38)
        g.addWidget(self.allowances,3,1)
        g.addWidget(QLabel("Deductions"),4,0)
        self.deductions=QDoubleSpinBox(); self.deductions.setMaximum(999999); self.deductions.setMinimumHeight(38)
        g.addWidget(self.deductions,4,1)
        layout.addLayout(g)
        br=QHBoxLayout(); br.addStretch()
        cancel=QPushButton("Cancel"); cancel.setObjectName("btn_cancel"); cancel.clicked.connect(self.reject)
        save=QPushButton("Process"); save.setObjectName("btn_add"); save.clicked.connect(self._save)
        br.addWidget(cancel); br.addWidget(save); layout.addLayout(br)

    def _save(self):
        sid=self.staff_combo.currentData()
        staff=self.db.fetchone("SELECT salary FROM staff WHERE id=?", (sid,))
        basic=staff['salary'] if staff else 0
        net=basic+self.allowances.value()-self.deductions.value()
        self.db.execute("""INSERT INTO salary_records (staff_id,month,year,basic_salary,allowances,deductions,net_salary,status)
            VALUES (?,?,?,?,?,?,?,?)""",
            (sid,self.month.currentText(),self.year.value(),basic,
             self.allowances.value(),self.deductions.value(),net,'paid'))
        QMessageBox.information(self,"Done",f"Salary processed: Rs.{net:,.0f}")
        self.accept()

