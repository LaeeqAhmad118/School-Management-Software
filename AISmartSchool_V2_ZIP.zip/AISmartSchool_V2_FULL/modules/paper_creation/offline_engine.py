"""
Offline AI Question Generation Engine
======================================
100% offline. No API key. No internet. No external NLP libraries.
Uses only: PyMuPDF (fitz) for PDF reading, Python stdlib for NLP.

Algorithm:
  1. Extract + clean text from syllabus PDFs
  2. Split into sentences and paragraphs
  3. Score sentences by TF-IDF keyword density
  4. Generate questions per section type:
    MCQ         — keyword-blank with distractor options
    Short       — what/define/explain templates on key sentences
    Long        — analytical/essay templates on key paragraphs
    Fill Blank  — mask key terms in informative sentences
    True/False  — declarative sentence + optional negation
    Definition  — detect "X is Y" patterns → "Define X"
    Essay       — topic synthesis from top paragraphs
  5. Fallback generic questions if PDF is empty or missing
"""

import os
import re
import random
from collections import Counter, defaultdict
from typing import List, Dict, Tuple


# ─────────────────────────────────────────────────────────────────────────────
# STOP WORDS
# ─────────────────────────────────────────────────────────────────────────────

_SW = set("""
a about above after again against all also am an and another any are aren't as
at be because been before being below between both but by can can't cannot could
couldn't did didn't do does doesn't doing don't down during each few for from
further get got had hadn't has hasn't have haven't having he he'd he'll he's her
here here's hers herself him himself his how how's i i'd i'll i'm i've if in
into is isn't it it's its itself just let's me more most must mustn't my myself
no nor not now of off on once only or other ought our ours ourselves out over own
same shan't she she'd she'll she's should shouldn't so some such than that that's
the their theirs them themselves then there there's therefore these they they'd
they'll they're they've this those through thus to too under until up us very was
wasn't we we'd we'll we're we've were weren't what what's when when's where
where's which while who who's whom why why's will with won't would wouldn't you
you'd you'll you're you've your yours yourself yourselves
""".split())


# ─────────────────────────────────────────────────────────────────────────────
# PDF TEXT EXTRACTION
# ─────────────────────────────────────────────────────────────────────────────

def extract_pdf_text(pdf_paths: List[str]) -> str:
    parts = []
    for path in pdf_paths:
        if not os.path.isfile(path):
            continue
        try:
            import fitz
            doc = fitz.open(path)
            for page in doc:
                parts.append(page.get_text())
            doc.close()
        except ImportError:
            parts.append(f"[Syllabus file: {os.path.basename(path)}]")
        except Exception as e:
            parts.append(f"[Could not read {os.path.basename(path)}]")
    return "\n".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# TEXT CLEANING
# ─────────────────────────────────────────────────────────────────────────────

def clean(text: str) -> str:
    text = re.sub(r'\n\s*\d+\s*\n', '\n', text)         # remove lone page numbers
    text = re.sub(r'[^\x20-\x7E\n]', ' ', text)          # printable ASCII only
    text = re.sub(r'[ \t]+', ' ', text)                   # collapse spaces
    text = re.sub(r'\n{3,}', '\n\n', text)                # max 2 newlines
    return text.strip()


def sentences(text: str) -> List[str]:
    # protect common abbreviations
    text = re.sub(r'\b(Mr|Mrs|Dr|Prof|Sr|Jr|etc|vs|Fig|No|Vol|Ch)\.',
                r'\1<DOT>', text, flags=re.IGNORECASE)
    raw = re.split(r'(?<=[.!?])\s+', text)
    raw = [s.replace('<DOT>', '.').strip() for s in raw]
    return [s for s in raw if 20 <= len(s) <= 400]


def paragraphs(text: str) -> List[str]:
    return [p.strip() for p in re.split(r'\n{2,}', text) if len(p.strip()) > 80]


# ─────────────────────────────────────────────────────────────────────────────
# KEYWORD EXTRACTION  (TF-IDF, no external libs)
# ─────────────────────────────────────────────────────────────────────────────

def tokenize(text: str) -> List[str]:
    return [t for t in re.findall(r'\b[a-zA-Z]{3,}\b', text.lower()) if t not in _SW]


def extract_keywords(sents: List[str], top: int = 60) -> List[str]:
    tf  = Counter()
    df  = defaultdict(int)
    tok_lists = []
    for s in sents:
        toks = tokenize(s)
        tok_lists.append(toks)
        tf.update(toks)
        for t in set(toks):
            df[t] += 1
    N = max(len(sents), 1)
    scores = {w: tf[w] * (N / (df[w] + 1)) for w in tf}
    return sorted(scores, key=lambda w: scores[w], reverse=True)[:top]


def noun_phrases(text: str) -> List[str]:
    caps = re.findall(r'(?:[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)', text)
    single_caps = [w for w in text.split()[1:] if w[0].isupper()
                and len(w) > 3 and w.lower() not in _SW]
    return list(dict.fromkeys(caps + single_caps))


def find_definitions(sents: List[str]) -> List[Tuple[str, str]]:
    defs = []
    pats = [
        r'^([A-Z][^.]{2,35}?)\s+(?:is|are|refers to|means|is defined as)\s+(.{20,150})',
        r'^([A-Z][^:]{2,30}):\s+(.{20,150})',
    ]
    for s in sents:
        for p in pats:
            m = re.match(p, s.strip())
            if m:
                term, defn = m.group(1).strip(), m.group(2).strip()
                if 1 <= len(term.split()) <= 6:
                    defs.append((term, defn))
                    break
    return defs


# ─────────────────────────────────────────────────────────────────────────────
# QUESTION BUILDERS
# ─────────────────────────────────────────────────────────────────────────────

def _q(text: str) -> str:
    text = text.strip().rstrip('.')
    return (text[0].upper() + text[1:] + ('?' if not text.endswith('?') else ''))


def build_mcq(sent: str, keywords: List[str]) -> Dict | None:
    toks = [t for t in tokenize(sent) if t in set(keywords)]
    if not toks:
        return None
    answer = toks[0]
    pat = re.compile(re.escape(answer), re.IGNORECASE)
    blanked = pat.sub('___________', sent, count=1)
    if blanked == sent:
        return None
    distractors = [k for k in keywords if k != answer][:6]
    random.shuffle(distractors)
    distractors = distractors[:3]
    fillers = ["None of these", "All of the above", "Cannot be determined",
            "Not given in text", "Both a and b"]
    while len(distractors) < 3:
        f = fillers.pop(0) if fillers else "Other"
        distractors.append(f)
    options = [answer.capitalize()] + [d.capitalize() for d in distractors]
    random.shuffle(options)
    return {
        "question_text": blanked.strip(),
        "question_type": "mcq",
        "options": options,
        "answer_hint": answer.capitalize(),
    }


def build_short(sent: str, keywords: List[str], subject: str, grade: str) -> Dict | None:
    if len(sent) < 30:
        return None
    nps = noun_phrases(sent)
    kws = [t for t in tokenize(sent) if t in set(keywords)]
    topic = nps[0] if nps else (kws[0].capitalize() if kws else subject)

    pools = [
        f"Define the term '{topic}' as used in {subject}.",
        f"What is meant by '{topic}'? Explain briefly.",
        f"Briefly explain: \"{sent[:90].rstrip('.')}...\"",
        f"State the importance of '{topic}' in {subject}.",
        f"Explain the following statement in your own words: \"{sent[:80].rstrip('.')}...\"",
        f"What do you understand by '{topic}'? Give one example.",
    ]
    if any(w in sent.lower() for w in ['process', 'method', 'step', 'procedure']):
        pools.insert(0, f"Describe the process or method mentioned in: \"{sent[:80]}\"")
    if any(w in sent.lower() for w in ['because', 'therefore', 'result', 'cause', 'effect']):
        pools.insert(0, f"Explain the cause-and-effect relationship in: \"{sent[:80]}\"")

    return {
        "question_text": _q(random.choice(pools)),
        "question_type": "short",
        "options": [],
        "answer_hint": sent[:120],
    }


def build_long(para: str, keywords: List[str], subject: str, grade: str) -> Dict | None:
    if len(para) < 80:
        return None
    nps = noun_phrases(para)
    topic = nps[0] if nps else (keywords[0].capitalize() if keywords else subject)
    pools = [
        f"Write a detailed note on '{topic}'. Include definition, types, and examples.",
        f"Discuss in detail the concept of '{topic}' as studied in {subject}.",
        f"Analyze and explain the key ideas in the following passage:\n\"{para[:160].rstrip('.')}...\"",
        f"Compare and contrast the main aspects of '{topic}' covered in the syllabus.",
        f"Explain '{topic}' with reference to its significance in {subject} for {grade}.",
        f"What is '{topic}'? Describe its characteristics and real-life applications.",
    ]
    return {
        "question_text": _q(random.choice(pools)),
        "question_type": "long",
        "options": [],
        "answer_hint": f"Refer to: {para[:160].rstrip('.')}...",
    }


def build_fill(sent: str, keywords: List[str]) -> Dict | None:
    toks = [t for t in tokenize(sent) if t in set(keywords)]
    if not toks:
        return None
    answer = toks[0]
    pat = re.compile(re.escape(answer), re.IGNORECASE)
    blanked = pat.sub('___________', sent, count=1)
    if blanked == sent:
        return None
    return {
        "question_text": blanked.strip(),
        "question_type": "fill_blank",
        "options": [],
        "answer_hint": answer.capitalize(),
    }


def build_tf(sent: str) -> Dict | None:
    if len(sent) < 25 or len(sent) > 200 or sent.endswith('?'):
        return None
    make_false = random.random() < 0.38
    q_text, answer = sent, "True"
    if make_false:
        for pat, repl in [
            (r'\b(is)\b', 'is not'), (r'\b(are)\b', 'are not'),
            (r'\b(was)\b', 'was not'), (r'\b(has)\b', 'has no'),
            (r'\b(can)\b', 'cannot'),
        ]:
            neg = re.sub(pat, repl, sent, count=1)
            if neg != sent:
                q_text, answer = neg, "False"
                break
    return {
        "question_text": f"State whether True or False: \"{q_text}\"",
        "question_type": "true_false",
        "options": [],
        "answer_hint": answer,
    }


def build_definition(term: str, defn: str) -> Dict:
    pools = [
        f"Define '{term}'.",
        f"What is meant by the term '{term}'?",
        f"Give the definition of '{term}' as used in this subject.",
        f"Explain the term '{term}' in your own words.",
    ]
    return {
        "question_text": random.choice(pools),
        "question_type": "definition",
        "options": [],
        "answer_hint": defn[:150],
    }


def build_essay(para: str, keywords: List[str], subject: str, grade: str) -> Dict | None:
    if len(para) < 60:
        return None
    nps = noun_phrases(para)
    topic = nps[0] if nps else (keywords[0].capitalize() if keywords else subject)
    pools = [
        f"Write a well-structured essay on '{topic}' and its importance in {subject}.",
        f"Discuss '{topic}' comprehensively. Include introduction, main points, and conclusion.",
        f"Write a paragraph on the role of '{topic}' in {subject} for {grade} level.",
    ]
    return {
        "question_text": _q(random.choice(pools)),
        "question_type": "essay",
        "options": [],
        "answer_hint": f"Essay on {topic}. Refer to: {para[:100]}...",
    }


# ─────────────────────────────────────────────────────────────────────────────
# FALLBACK CONTENT (when no PDF or empty PDF)
# ─────────────────────────────────────────────────────────────────────────────

_GENERIC = {
    "mathematics": """
Mathematics is the science of numbers, quantities, and shapes.
Algebra is the branch of mathematics dealing with symbols and the rules for manipulating those symbols.
Geometry is the branch of mathematics concerned with the properties and relations of points, lines, surfaces, and solids.
A prime number is a natural number greater than 1 that has no divisors other than 1 and itself.
The Pythagorean theorem states that in a right-angled triangle, the square of the hypotenuse equals the sum of squares of the other two sides.
Trigonometry is the study of relationships between the angles and sides of triangles.
Calculus is the mathematical study of continuous change and is divided into differential calculus and integral calculus.
A rational number can be expressed as the ratio of two integers where the denominator is not zero.
Probability is the measure of the likelihood that an event will occur, ranging from 0 to 1.
Statistics is the science of collecting, organizing, analyzing, interpreting, and presenting data.
An equation is a mathematical statement that two expressions are equal.
A fraction represents a part of a whole and consists of a numerator and a denominator.
""",
    "science": """
Science is the systematic study of the physical and natural world through observation and experiment.
Physics is the natural science that studies matter, motion, energy, and force.
Chemistry is the scientific discipline involved with elements and compounds made of atoms and molecules.
Biology is the natural science that studies life and living organisms including their structure and function.
Photosynthesis is the process used by plants to convert light energy into chemical energy stored as glucose.
Newton's First Law of Motion states that a body remains at rest unless acted on by an external force.
The cell is the basic structural and functional unit of all known living organisms.
An atom is the smallest unit of a chemical element that retains the properties of that element.
Energy is the capacity to do work and can be converted from one form to another but cannot be created or destroyed.
An ecosystem is a community of living organisms interacting with each other and their environment.
Gravity is the force of attraction between all objects that have mass.
The water cycle describes the continuous movement of water on Earth including evaporation and precipitation.
""",
    "english": """
English is a West Germanic language that has become the world's leading language of science and technology.
Grammar is the set of structural rules governing the composition of clauses, phrases, and words in a language.
A noun is a word that names a person, place, thing, or idea.
A verb is a word that expresses an action, occurrence, or state of being.
An adjective is a word that modifies or describes a noun or pronoun.
An adverb is a word that modifies a verb, adjective, or another adverb.
A sentence is a group of words that expresses a complete thought and contains a subject and a predicate.
A paragraph is a distinct section of writing dealing with a single theme and usually beginning on a new line.
Comprehension is the ability to understand and interpret written or spoken language.
Literature refers to written works considered to have artistic or intellectual value.
Poetry is a form of literature that uses rhythm and imagery to convey meaning and emotion.
Punctuation marks are symbols used in writing to separate sentences and clarify meaning.
""",
    "physics": """
Physics is the branch of science concerned with the nature and properties of matter and energy.
Force is any interaction that tends to change the motion of an object and is measured in Newtons.
Newton's Second Law states that force equals mass multiplied by acceleration: F = ma.
Energy is the ability to do work and exists in many forms including kinetic and potential energy.
Kinetic energy is the energy an object possesses due to its motion.
Potential energy is the energy stored in an object due to its position or state.
Velocity is the rate of change of displacement with respect to time and is a vector quantity.
Acceleration is the rate of change of velocity with respect to time.
Friction is the force that opposes the relative motion of two surfaces in contact.
Pressure is defined as force applied per unit area and is measured in Pascals.
Sound is a mechanical wave that travels through a medium by vibration of particles.
Light travels at approximately 3 × 10^8 metres per second in a vacuum.
""",
    "chemistry": """
Chemistry is the scientific study of the properties, composition, and transformation of matter.
An element is a pure substance consisting of one type of atom that cannot be broken down chemically.
A compound is a substance formed from two or more elements chemically combined in fixed proportions.
A mixture is a combination of two or more substances that are not chemically combined.
The periodic table is an arrangement of chemical elements ordered by atomic number.
Valency is the combining capacity of an element determined by the number of electrons it can give, receive, or share.
An acid is a substance that produces hydrogen ions when dissolved in water and has a pH less than 7.
A base is a substance that produces hydroxide ions in solution and has a pH greater than 7.
Oxidation is the loss of electrons by a substance during a chemical reaction.
Reduction is the gain of electrons by a substance during a chemical reaction.
A chemical bond is the force of attraction that holds atoms together in a compound.
The mole is the SI unit for amount of substance and contains 6.022 × 10^23 particles.
""",
    "biology": """
Biology is the study of living organisms and their vital processes.
The cell is the smallest unit of life and all living organisms are made of one or more cells.
DNA is the molecule that carries genetic information in living organisms.
Photosynthesis is the process by which green plants make food using sunlight, water, and carbon dioxide.
Respiration is the biochemical process by which cells break down glucose to release energy.
Evolution is the process of gradual change in species over generations through natural selection.
An ecosystem includes all living organisms in an area and the physical environment they interact with.
The food chain shows the transfer of energy from one organism to another through eating and being eaten.
Osmosis is the movement of water molecules from an area of high concentration to low concentration through a membrane.
Mitosis is a type of cell division resulting in two daughter cells with the same number of chromosomes as the parent.
Heredity is the passing of traits from parents to offspring through genes.
Bacteria are microscopic single-celled organisms that can be beneficial or harmful to living things.
""",
    "history": """
History is the study of past events particularly in human affairs.
Civilization refers to a complex organized society with cities, writing, laws, and specialized occupations.
The Indus Valley Civilization was one of the world's earliest urban civilizations, flourishing around 2500 BCE.
The Mughal Empire was a powerful Islamic empire that ruled over most of South Asia from 1526 to 1857.
The British East India Company established commercial and eventually political control over India.
The Pakistan Movement was a political effort led by the Muslim League to create a separate homeland for Muslims.
Pakistan gained independence on 14 August 1947 as a result of the partition of British India.
Quaid-e-Azam Muhammad Ali Jinnah was the founder of Pakistan and served as its first Governor-General.
Allama Iqbal was the philosopher and poet who gave the vision of a separate Muslim homeland.
The Constitution is the supreme law of a country that defines the structure and powers of government.
Democracy is a system of government in which power is vested in the people through elected representatives.
""",
    "islamiat": """
Islam is the religion of peace revealed to Prophet Muhammad (PBUH) and based on the Holy Quran and Sunnah.
The Holy Quran is the sacred scripture of Islam revealed to Prophet Muhammad (PBUH) over 23 years.
The Sunnah refers to the practices, sayings, and approvals of Prophet Muhammad (PBUH).
The Five Pillars of Islam are Shahadah, Salat, Zakat, Sawm, and Hajj.
Shahadah is the declaration of faith that there is no god but Allah and Muhammad is His messenger.
Salat refers to the five compulsory daily prayers performed by Muslims facing the Kaaba in Makkah.
Zakat is the obligatory annual payment of a portion of one's wealth to those in need.
Sawm is the fasting observed during the month of Ramadan from dawn to sunset.
Hajj is the annual pilgrimage to Makkah which is obligatory once in a lifetime for every able Muslim.
Prophet Muhammad (PBUH) was born in Makkah in 570 CE and received the first revelation at age 40.
Tawheed means the oneness of Allah and is the central belief of Islam.
Jihad means striving in the way of Allah and includes both the greater jihad against one's inner self and the lesser jihad.
""",
    "geography": """
Geography is the study of Earth's physical features, climate, and human populations.
A map is a representation of Earth's surface showing physical features, countries, and cities.
Latitude is the angular distance of a point on Earth's surface measured in degrees north or south of the equator.
Longitude is the angular distance measured in degrees east or west of the prime meridian.
A continent is one of the main large landmasses of the Earth such as Asia, Africa, or Europe.
Climate is the average weather conditions of a place over a long period of time.
Erosion is the process by which soil and rock are worn away and transported by wind, water, or ice.
A river is a large natural stream of fresh water flowing to the sea or a lake.
Mountains are elevated areas of land rising steeply above the surrounding landscape.
Population density is the number of people living per unit area of land.
Urbanization is the process by which people move from rural areas to cities.
Natural resources are materials found in nature that are used by humans including water, coal, and minerals.
""",
}


def _generic_content(subject: str, grade: str) -> str:
    sl = subject.lower()
    for key, content in _GENERIC.items():
        if key in sl or any(w in sl for w in key.split()):
            return content
    return f"""
{subject} is an important academic subject for {grade} students.
This subject covers fundamental concepts that form the foundation for advanced understanding.
Students are expected to master core principles and apply them to solve real-world problems.
Key topics include theoretical foundations, practical applications, and problem-solving techniques.
Critical thinking and analytical reasoning are essential skills for excelling in this subject.
Regular study, revision, and practice of exercises help in building a strong foundation.
Understanding key terms and definitions is crucial for answering examination questions accurately.
Students should be able to explain concepts clearly, give examples, and draw relevant diagrams.
"""


# ─────────────────────────────────────────────────────────────────────────────
# FALLBACK QUESTION (guaranteed output)
# ─────────────────────────────────────────────────────────────────────────────

def _fallback(q_type: str, subject: str, grade: str, num: int,
            keywords: List[str]) -> Dict:
    kw = (keywords[num % max(len(keywords), 1)].capitalize()
        if keywords else subject)
    bank = {
        "mcq": {
            "question_text": f"Which of the following best describes '{kw}' in {subject}?",
            "options": [f"A key concept in {subject}", "A mathematical formula",
                        "A historical event", "None of the above"],
            "answer_hint": f"A key concept in {subject}",
        },
        "short": {
            "question_text": f"Briefly explain the concept of '{kw}' in {subject}.",
            "options": [], "answer_hint": f"Key definition and explanation of {kw}.",
        },
        "long": {
            "question_text": f"Write a detailed note on '{kw}'. Include definition, types, and examples.",
            "options": [], "answer_hint": f"Comprehensive answer on {kw}.",
        },
        "fill_blank": {
            "question_text": f"___________ is a fundamental concept in {subject} for {grade} students.",
            "options": [], "answer_hint": kw,
        },
        "true_false": {
            "question_text": f"State whether True or False: \"{kw} is an important concept in {subject}.\"",
            "options": [], "answer_hint": "True",
        },
        "definition": {
            "question_text": f"Define '{kw}' as studied in {subject}.",
            "options": [], "answer_hint": f"Definition of {kw} from course material.",
        },
        "essay": {
            "question_text": f"Write a structured essay on the importance and applications of '{kw}' in {subject}.",
            "options": [], "answer_hint": f"Structured essay on {kw}.",
        },
    }
    q = bank.get(q_type, bank["short"])
    return {**q, "question_type": q_type}


# ─────────────────────────────────────────────────────────────────────────────
# DIFFICULTY ADJUSTMENT
# ─────────────────────────────────────────────────────────────────────────────

def _apply_difficulty(questions: List[Dict], level: str) -> List[Dict]:
    if level == "Easy":
        for q in questions:
            if q["question_type"] in ("short", "definition"):
                t = q["question_text"]
                if not any(t.lower().startswith(v) for v in
                        ["state", "name", "list", "write", "what is", "define"]):
                    q["question_text"] = "State in brief: " + t
    elif level == "Hard":
        hard = ["Critically analyze", "Evaluate with examples:",
                "Compare and contrast:", "Justify your answer:"]
        for q in questions:
            if q["question_type"] in ("long", "essay"):
                prefix = random.choice(hard)
                if not any(q["question_text"].startswith(p) for p in hard):
                    q["question_text"] = f"{prefix} {q['question_text']}"
    return questions


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def generate_questions_offline(config: Dict) -> List[Dict]:
    """
    Generate exam questions fully offline.

    config keys:
    pdf_paths, subject, class_name, paper_level,
    pattern: {sections: [{label, type, count, marks_each, type_display}]}
    """
    subject   = config.get("subject", "General") or "General"
    grade     = config.get("class_name", "") or ""
    level     = config.get("paper_level", "Medium")
    sections  = config.get("pattern", {}).get("sections", [])
    pdf_paths = config.get("pdf_paths", [])

    # ── Extract and clean text ────────────────────────────────────────────────
    raw = extract_pdf_text(pdf_paths)
    if len(raw.strip()) < 80:
        raw = _generic_content(subject, grade)
    text = clean(raw)
    sents = sentences(text)
    paras = paragraphs(text)
    if not sents:
        sents = [text[:300]] if text else [f"{subject} is an important subject."]
    if not paras:
        paras = sents[:5]

    # ── Keyword and definition extraction ────────────────────────────────────
    keywords = extract_keywords(sents, top=70)
    defs     = find_definitions(sents)

    # ── Score sentences by keyword density ───────────────────────────────────
    kw_set = set(keywords)

    def score(s: str) -> float:
        toks = tokenize(s)
        return sum(1 for t in toks if t in kw_set) + min(len(toks) / 25, 1.0)

    ranked_sents = sorted(sents, key=score, reverse=True)
    ranked_paras = sorted(paras, key=score, reverse=True)

    # ── Generate per-section ──────────────────────────────────────────────────
    all_questions: List[Dict] = []
    used: set = set()

    TITLE_MAP = {
        "mcq":        "Objective — Multiple Choice Questions",
        "short":      "Short Answer Questions",
        "long":       "Long Answer Questions",
        "fill_blank": "Fill in the Blanks",
        "true_false": "True / False",
        "definition": "Definitions / Key Terms",
        "essay":      "Essay / Paragraph Writing",
    }

    BUILDERS = {
        "mcq":        lambda s, p: build_mcq(s, keywords),
        "short":      lambda s, p: build_short(s, keywords, subject, grade),
        "long":       lambda s, p: build_long(p, keywords, subject, grade),
        "fill_blank": lambda s, p: build_fill(s, keywords),
        "true_false": lambda s, p: build_tf(s),
        "definition": lambda s, p: (build_definition(*defs[0]) if defs else
                                    build_short(s, keywords, subject, grade)),
        "essay":      lambda s, p: build_essay(p, keywords, subject, grade),
    }

    for sec in sections:
        label    = sec.get("label", "A")
        q_type   = sec.get("type", "short")
        count    = int(sec.get("count", 5))
        marks_ea = int(sec.get("marks_each", 2))
        sec_title = TITLE_MAP.get(q_type, sec.get("type_display", q_type))

        generated: List[Dict] = []
        def_pool_idx = 0
        sent_idx = 0
        para_idx = 0
        attempts = 0
        max_attempts = count * 10

        while len(generated) < count and attempts < max_attempts:
            attempts += 1

            src_sent = ranked_sents[sent_idx % len(ranked_sents)]
            src_para = ranked_paras[para_idx % len(ranked_paras)]
            sent_idx += 1
            para_idx += 1

            key = src_sent[:50]
            if key in used and attempts < count * 5:
                continue

            # Handle definition pool rotation
            if q_type == "definition" and defs:
                term, defn = defs[def_pool_idx % len(defs)]
                def_pool_idx += 1
                q = build_definition(term, defn)
            else:
                builder = BUILDERS.get(q_type, BUILDERS["short"])
                q = builder(src_sent, src_para)

            if q and len(q.get("question_text", "")) > 10:
                used.add(key)
                q.update({
                    "section":         label,
                    "section_title":   sec_title,
                    "question_number": len(generated) + 1,
                    "marks":           marks_ea,
                })
                generated.append(q)

        # Fill remaining with fallbacks
        while len(generated) < count:
            fb = _fallback(q_type, subject, grade, len(generated), keywords)
            fb.update({
                "section":         label,
                "section_title":   sec_title,
                "question_number": len(generated) + 1,
                "marks":           marks_ea,
            })
            generated.append(fb)

        all_questions.extend(generated)

    return _apply_difficulty(all_questions, level)
