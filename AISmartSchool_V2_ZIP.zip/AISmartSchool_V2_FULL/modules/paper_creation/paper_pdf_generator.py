"""
Exam Paper PDF Generator
========================
Generates professional A4 exam papers using ReportLab, styled to match a
formal printed school paper: black header text (not a colour band), a
boxed exam-title bar, a bordered info grid, a bordered student-info box,
a black INSTRUCTIONS bar, and black section bars — with MCQs laid out in
two columns (options inline A) B) C) D)) and short/long/fill-in/true-false
sections paired side by side the way a real stencilled paper is typeset.
Supports student copy and teacher's copy (with answer hints).

HARD 2-PAGE CAP
----------------
The whole layout (header, info grid, student box, instructions,
question sections) is built from a single `_scale` factor that shrinks
every font size, every spacer, and every table padding together. After
a build, the actual page count reached during rendering is measured
(via the page-numbering callback ReportLab already calls per page —
no extra dependency needed), and if the result is more than 2 pages,
the whole paper is rebuilt automatically at a smaller scale. This
repeats until it fits in 2 pages or a minimum readable scale is hit,
at which point the smallest-scale (best effort) version is kept.
"""

import os
import subprocess
import platform
from datetime import datetime


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _open_file(path: str):
    try:
        if platform.system() == "Windows":
            os.startfile(path)
        elif platform.system() == "Darwin":
            subprocess.call(["open", path])
        else:
            subprocess.call(["xdg-open", path])
    except Exception:
        pass


def _direct_print(path: str):
    try:
        if platform.system() == "Windows":
            os.startfile(path, "print")
        else:
            subprocess.call(["lpr", path])
    except Exception:
        _open_file(path)


# Scale bounds for the auto-shrink loop. 1.0 = the (already compact) base
# sizes defined below. Each failed attempt multiplies the previous scale
# by _SHRINK_STEP until _MIN_SCALE is reached; below that, fonts would
# stop being print-legible, so the smallest attempted build is kept.
_MIN_SCALE = 0.72
_SHRINK_STEP = 0.92
_MAX_ATTEMPTS = 8
_MAX_PAGES = 2


# ─────────────────────────────────────────────────────────────────────────────
# MAIN GENERATOR
# ─────────────────────────────────────────────────────────────────────────────

def generate_exam_paper(output_path: str, config: dict,
                        questions: list, teacher_copy: bool = False,
                        _allow_split: bool = False,
                        _scale: float = 1.0, _attempt: int = 0,
                        _best_so_far: dict = None):
    """
    Build and save a formatted exam paper PDF, styled after a formal
    printed school paper template, and force the result onto a maximum
    of 2 pages by auto-shrinking fonts/spacing across the whole layout.

    config keys:
        school_name, school_address, school_phone, school_email, school_website,
        school_tagline, subject, subject_code, class_name, section_name,
        teacher, exam_title, academic_session, examination_type,
        total_marks, time_allowed, exam_date, logo_path, instructions (list[str])

    questions: list of dicts with:
        section, section_title, question_number, question_text,
        marks, question_type, options, answer_hint

    _allow_split, _scale, _attempt, _best_so_far are internal — used only
    by the automatic retry/shrink loop at the bottom of this function.
    Leave them at their defaults when calling normally.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
            HRFlowable, KeepTogether, Image
        )
    except ImportError:
        raise ImportError(
            "ReportLab is not installed.\n"
            "Run:  pip install reportlab"
        )

    S = _scale  # single knob that shrinks fonts + spacing + padding together

    def F(pt):
        """Scaled font size, never below a hard legibility floor."""
        return max(pt * S, pt * 0.7, 5.6)

    def SP(v_mm):
        """Scaled spacer height in mm-units (already multiplied by mm by caller)."""
        return v_mm * S

    def PD(v):
        """Scaled integer table padding, floor 1 so cells never collapse."""
        return max(1, round(v * S))

    PAGE_W, PAGE_H = A4
    # Margins shrink slightly too at smaller scales, to reclaim page space.
    M = (10 - (1 - S) * 3) * mm
    TOP_M = (6 - (1 - S) * 2) * mm
    BOT_M = TOP_M

    # ── Colour palette — formal black-and-white paper, one accent for marks ──
    C = {
        "black":     colors.HexColor("#111111"),
        "bar_bg":    colors.HexColor("#111111"),
        "bar_text":  colors.white,
        "marks":     colors.HexColor("#111111"),
        "border":    colors.HexColor("#111111"),
        "grid_line": colors.HexColor("#9ca3af"),
        "body":      colors.HexColor("#111111"),
        "light":     colors.HexColor("#4b5563"),
        "answer":    colors.HexColor("#15803d"),
        "teacher_c": colors.HexColor("#b45309"),
        "line":      colors.HexColor("#9ca3af"),
    }

    def sty(name, **kw):
        return ParagraphStyle(name, **kw)

    # Base font sizes are already compact (tuned to fit two pages); the
    # F() wrapper shrinks them further on retry attempts.
    ST = {
        "school": sty("school", fontName="Helvetica-Bold", fontSize=F(15),
                    textColor=C["black"], alignment=TA_LEFT, leading=F(16.5)),
        "school_sub": sty("school_sub", fontName="Helvetica-Oblique", fontSize=F(7.6),
                        textColor=C["light"], alignment=TA_LEFT, spaceBefore=0.5),
        "contact": sty("contact", fontName="Helvetica", fontSize=F(6.8),
                    textColor=C["light"], alignment=TA_LEFT, spaceBefore=1),
        "teacher_stamp": sty("teacher_stamp", fontName="Helvetica-Bold", fontSize=F(7.2),
                            textColor=C["teacher_c"], alignment=TA_LEFT, spaceBefore=1),
        "exam_title": sty("exam_title", fontName="Helvetica-Bold", fontSize=F(12),
                        textColor=C["black"], alignment=TA_CENTER),
        "info_label": sty("info_label", fontName="Helvetica-Bold", fontSize=F(7.4),
                        textColor=C["body"]),
        "info_value": sty("info_value", fontName="Helvetica", fontSize=F(7.4),
                        textColor=C["body"]),
        "inst_bar": sty("inst_bar", fontName="Helvetica-Bold", fontSize=F(8.6),
                        textColor=colors.white, alignment=TA_CENTER),
        "inst": sty("inst", fontName="Helvetica", fontSize=F(7.2),
                    textColor=C["body"], alignment=TA_LEFT, spaceAfter=SP(1.6)),
        "sec_label": sty("sec_label", fontName="Helvetica-Bold", fontSize=F(9),
                        textColor=colors.white),
        "sec_marks": sty("sec_marks", fontName="Helvetica-Bold", fontSize=F(8.6),
                        textColor=colors.white, alignment=TA_RIGHT),
        "sec_hint": sty("sec_hint", fontName="Helvetica-Oblique", fontSize=F(6.6),
                        textColor=C["light"], spaceBefore=SP(0.8), spaceAfter=SP(0.8)),
        "q_text": sty("q_text", fontName="Helvetica", fontSize=F(7.8),
                    textColor=C["body"], alignment=TA_JUSTIFY,
                    spaceBefore=SP(1.2), spaceAfter=SP(0.4), leading=F(9.4)),
        "q_marks": sty("q_marks", fontName="Helvetica-Bold", fontSize=F(7.4),
                    textColor=C["marks"], alignment=TA_RIGHT),
        "opt": sty("opt", fontName="Helvetica", fontSize=F(7.8),
                textColor=C["body"], spaceBefore=SP(0.6), leading=F(9.4)),
        "answer": sty("answer", fontName="Helvetica-Oblique", fontSize=F(7.0),
                    textColor=C["answer"], spaceBefore=SP(0.6), leftIndent=10),
        "footer_lbl": sty("footer_lbl", fontName="Helvetica-Bold", fontSize=F(7.2),
                        textColor=C["body"]),
        "footer_page": sty("footer_page", fontName="Helvetica", fontSize=F(6.8),
                        textColor=C["light"], alignment=TA_CENTER),
    }

    cw = PAGE_W - 2 * M  # content width

    # Sections are wrapped in KeepTogether so a section never splits across
    # a page boundary — UNLESS this is the automatic retry after a section
    # turned out to be taller than one whole page (see the bottom of this
    # function), in which case splitting is the only way to still produce
    # a valid PDF at all.
    _kt = (lambda flowable: flowable) if _allow_split else KeepTogether

    # ── Document ──────────────────────────────────────────────────────────────
    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=M, rightMargin=M,
        topMargin=TOP_M, bottomMargin=BOT_M,
        title=f"{config.get('subject', '')} Exam Paper",
        author=config.get("school_name", "AI EduHub ERP"),
    )

    story = []

    # ─────────────────────────────────────────────────────────────────────────
    # HEADER — logo, school name, tagline, contact line (formal black text,
    # not a colour band — matches a stencilled/printed paper look)
    # ─────────────────────────────────────────────────────────────────────────
    school_name = config.get("school_name", "School") or "School"
    logo_path   = config.get("logo_path", "") or ""

    logo_col_w = max(14, 18 * S) * mm
    logo_cell = _logo_cell(logo_path, school_name, colors, mm, logo_col_w / mm)

    header_paras = [Paragraph(school_name.upper(), ST["school"])]
    tagline = config.get("school_tagline", "") or ""
    if tagline:
        header_paras.append(Paragraph(tagline, ST["school_sub"]))

    contact_bits = []
    if config.get("school_address"):
        contact_bits.append(config['school_address'])
    if config.get("school_phone"):
        contact_bits.append(f"Tel: {config['school_phone']}")
    if config.get("school_email"):
        contact_bits.append(config['school_email'])
    if config.get("school_website"):
        contact_bits.append(config['school_website'])
    if contact_bits:
        header_paras.append(Paragraph("&nbsp;&nbsp;•&nbsp;&nbsp;".join(contact_bits), ST["contact"]))

    if teacher_copy:
        header_paras.append(Paragraph("▸ TEACHER'S COPY — WITH ANSWER HINTS ◂", ST["teacher_stamp"]))

    hdr_data = [[logo_cell, header_paras]]
    hdr_tbl = Table(hdr_data, colWidths=[logo_col_w, cw - logo_col_w])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN",         (0, 0), (0,  0),  "CENTER"),
        ("LEFTPADDING",   (1, 0), (1,  0),  PD(6)),
        ("TOPPADDING",    (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(hdr_tbl)
    story.append(Spacer(1, SP(1.2) * mm))
    story.append(HRFlowable(width="100%", thickness=max(0.8, 1.4 * S), color=C["black"]))
    story.append(Spacer(1, SP(1.2) * mm))

    # ─────────────────────────────────────────────────────────────────────────
    # EXAM TITLE — boxed bar, centered, matches the reference's bordered
    # "MID TERM EXAMINATION" title box
    # ─────────────────────────────────────────────────────────────────────────
    exam_title = (config.get("exam_title", "") or
                f"{config.get('subject', 'Subject')} Examination").upper()
    title_tbl = Table([[Paragraph(exam_title, ST["exam_title"])]], colWidths=[cw])
    title_tbl.setStyle(TableStyle([
        ("BOX",           (0, 0), (-1, -1), max(0.8, 1.1 * S), C["border"]),
        ("TOPPADDING",    (0, 0), (-1, -1), PD(2.6)),
        ("BOTTOMPADDING", (0, 0), (-1, -1), PD(2.6)),
    ]))
    story.append(title_tbl)
    story.append(Spacer(1, SP(1.2) * mm))

    # ─────────────────────────────────────────────────────────────────────────
    # INFO GRID — Class/Section/Subject/Code, Teacher/Marks/Time/Date,
    # Academic Session/Examination Type — one bordered box, 3 rows
    # ─────────────────────────────────────────────────────────────────────────
    def _lbl(t):  return Paragraph(f"<b>{t}</b>", ST["info_label"])
    def _val(t):  return Paragraph(str(t) if t else "", ST["info_value"])
    def _blank_val(t, n=18): return Paragraph(str(t) if t else "_" * n, ST["info_value"])

    c4 = cw / 4
    info_rows = [
        [_lbl("Class:"),    _blank_val(config.get("class_name", "")),
        _lbl("Section:"),  _blank_val(config.get("section_name", ""))],
        [_lbl("Subject:"),  _blank_val(config.get("subject", "")),
        _lbl("Subject Code:"), _blank_val(config.get("subject_code", ""))],
        [_lbl("Teacher Name:"), _blank_val(config.get("teacher", "")),
        _lbl("Total Marks:"),  _val(str(config.get("total_marks", 100)))],
        [_lbl("Time Allowed:"), _val(config.get("time_allowed", "3 Hours")),
        _lbl("Exam Date:"),    _val(config.get("exam_date", datetime.now().strftime("%d-%m-%Y")))],
        [_lbl("Academic Session:"), _blank_val(config.get("academic_session", "")),
        _lbl("Examination Type:"), _blank_val(config.get("examination_type", exam_title.title()))],
    ]
    info_tbl = Table(info_rows, colWidths=[c4 * 0.62, c4 * 1.38, c4 * 0.62, c4 * 1.38])
    info_tbl.setStyle(TableStyle([
        ("BOX",           (0, 0), (-1, -1), max(0.7, 0.9 * S), C["border"]),
        ("INNERGRID",     (0, 0), (-1, -1), 0.35, C["grid_line"]),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING",    (0, 0), (-1, -1), PD(1.6)),
        ("BOTTOMPADDING", (0, 0), (-1, -1), PD(1.6)),
        ("LEFTPADDING",   (0, 0), (-1, -1), PD(5)),
        ("RIGHTPADDING",  (0, 0), (-1, -1), PD(5)),
    ]))
    story.append(info_tbl)
    story.append(Spacer(1, SP(1.2) * mm))

    # ─────────────────────────────────────────────────────────────────────────
    # STUDENT INFO BOX — Name/Roll Number, Class/Section/Signature
    # ─────────────────────────────────────────────────────────────────────────
    stu_rows = [
        [_lbl("Student Name:"), _blank_val("", 40), _lbl("Roll Number:"), _blank_val("", 16)],
        [_lbl("Class:"), _blank_val("", 14), _lbl("Section:"), _blank_val("", 10)],
    ]
    stu_tbl = Table(stu_rows, colWidths=[c4 * 0.62, c4 * 1.9, c4 * 0.62, c4 * 0.86])
    stu_tbl.setStyle(TableStyle([
        ("BOX",           (0, 0), (-1, -1), max(0.7, 0.9 * S), C["border"]),
        ("INNERGRID",     (0, 0), (-1, -1), 0.35, C["grid_line"]),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("SPAN",          (1, 0), (1, 0)),
        ("TOPPADDING",    (0, 0), (-1, -1), PD(2.2)),
        ("BOTTOMPADDING", (0, 0), (-1, -1), PD(2.2)),
        ("LEFTPADDING",   (0, 0), (-1, -1), PD(5)),
        ("RIGHTPADDING",  (0, 0), (-1, -1), PD(5)),
    ]))
    story.append(stu_tbl)
    story.append(Spacer(1, SP(1.2) * mm))

    # ─────────────────────────────────────────────────────────────────────────
    # INSTRUCTIONS — black bar + bordered 2-column numbered list
    # ─────────────────────────────────────────────────────────────────────────
    inst_bar = Table([[Paragraph("INSTRUCTIONS", ST["inst_bar"])]], colWidths=[cw])
    inst_bar.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), C["bar_bg"]),
        ("TOPPADDING",    (0, 0), (-1, -1), PD(2.6)),
        ("BOTTOMPADDING", (0, 0), (-1, -1), PD(2.6)),
    ]))
    story.append(inst_bar)

    default_instructions = [
        "Read all questions carefully.",
        "Attempt all questions.",
        "Use blue or black ink only.",
        "Do not use unfair means.",
        "Write neatly and clearly.",
        "Manage your time properly.",
    ]
    inst_items = config.get("instructions") or default_instructions
    half = (len(inst_items) + 1) // 2
    left_items, right_items = inst_items[:half], inst_items[half:]

    def _inst_col(items, start_n):
        paras = [Paragraph(f"{start_n + i}.&nbsp;&nbsp;{t}", ST["inst"])
                for i, t in enumerate(items)]
        return paras

    inst_grid = Table(
        [[_inst_col(left_items, 1), _inst_col(right_items, half + 1)]],
        colWidths=[cw / 2, cw / 2]
    )
    inst_grid.setStyle(TableStyle([
        ("BOX",           (0, 0), (-1, -1), max(0.7, 0.9 * S), C["border"]),
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING",    (0, 0), (-1, -1), PD(2.4)),
        ("BOTTOMPADDING", (0, 0), (-1, -1), PD(2.4)),
        ("LEFTPADDING",   (0, 0), (-1, -1), PD(7)),
        ("RIGHTPADDING",  (0, 0), (-1, -1), PD(7)),
    ]))
    story.append(inst_grid)
    story.append(Spacer(1, SP(1.6) * mm))

    # ─────────────────────────────────────────────────────────────────────────
    # QUESTIONS — grouped by section, MCQs full-width 2-column, other types
    # paired side-by-side the way a real paper typesets Section B+C, D+E
    # ─────────────────────────────────────────────────────────────────────────
    _TYPE_HINT = {
        "mcq":        "Note: Choose the correct option.",
        "short":      "",
        "long":       "",
        "fill_blank": "",
        "true_false": "Write True (T) or False (F).",
        "definition": "Give clear, concise definitions.",
        "essay":      "Write a well-structured essay / paragraph.",
    }

    seen_sections = []
    sections: dict = {}
    for q in questions:
        sl = q.get("section", "A")
        if sl not in sections:
            sections[sl] = []
            seen_sections.append(sl)
        sections[sl].append(q)

    def _section_header(sec_label, sec_title, sec_marks, width):
        return Table(
            [[Paragraph(f"&nbsp;&nbsp;SECTION {sec_label} – {sec_title.upper()}", ST["sec_label"]),
            Paragraph(f"({sec_marks} MARKS)&nbsp;&nbsp;", ST["sec_marks"])]],
            colWidths=[width * 0.68, width * 0.32],
            style=TableStyle([
                ("BACKGROUND",    (0, 0), (-1, -1), C["bar_bg"]),
                ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING",    (0, 0), (-1, -1), PD(2.4)),
                ("BOTTOMPADDING", (0, 0), (-1, -1), PD(2.4)),
                ("LEFTPADDING",   (0, 0), (0,  0),  PD(5)),
                ("RIGHTPADDING",  (1, 0), (1,  0),  PD(5)),
            ])
        )

    def _mcq_block(sec_label, sec_qs, width):
        """Two-column MCQ layout: question + inline A) B) C) D) options."""
        flow = []
        hint = _TYPE_HINT.get("mcq", "")
        if hint:
            flow.append(Paragraph(hint, ST["sec_hint"]))

        half_n = (len(sec_qs) + 1) // 2
        col_w = (width - 6*mm) / 2
        left_qs, right_qs = sec_qs[:half_n], sec_qs[half_n:]

        def render_q(q):
            q_num  = q.get("question_number", "")
            q_text = q.get("question_text", "")
            opts   = q.get("options", []) or []
            lines = [f"<b>{q_num}.</b>&nbsp;{q_text}"]
            if opts:
                labels = ["A)", "B)", "C)", "D)"]
                opt_line = "&nbsp;&nbsp;&nbsp;".join(
                    f"{labels[i]}&nbsp;{opt}" for i, opt in enumerate(opts[:4]))
                lines.append(f"<font size={F(7.6):.1f}>{opt_line}</font>")
            para = Paragraph("<br/>".join(lines), ST["q_text"])
            if teacher_copy and q.get("answer_hint"):
                return [para, Paragraph(f"✔ <i>Ans: {q['answer_hint'][:80]}</i>", ST["answer"])]
            return [para]

        left_flow, right_flow = [], []
        for q in left_qs:
            left_flow.extend(render_q(q))
        for q in right_qs:
            right_flow.extend(render_q(q))

        def _col_table(items, w):
            if not items:
                items = [Paragraph("", ST["opt"])]
            t = Table([[f] for f in items], colWidths=[w])
            t.setStyle(TableStyle([
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 0),
                ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                ("TOPPADDING", (0, 0), (-1, -1), PD(1.2)),
                ("BOTTOMPADDING", (0, 0), (-1, -1), PD(1.6)),
            ]))
            return t

        grid = Table([[_col_table(left_flow, col_w), _col_table(right_flow, col_w)]],
                    colWidths=[col_w, col_w])
        grid.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), PD(2)),
            ("RIGHTPADDING", (0, 0), (-1, -1), PD(2)),
            ("TOPPADDING", (0, 0), (-1, -1), PD(1.6)),
        ]))
        flow.append(grid)
        return flow

    def _listed_block(sec_qs, width, style="numbered"):
        """Short/fill-blank/true-false/long: one paragraph per question,
        marks shown inline. Long/essay questions get a couple of ruled
        answer lines beneath (only used in full-width mode, since paired-
        column mode keeps rows aligned between both sides)."""
        flow = []
        for q in sec_qs:
            q_num  = q.get("question_number", "")
            q_text = q.get("question_text", "")
            marks  = q.get("marks", 0)
            q_type = q.get("question_type", "short")
            hint_t = q.get("answer_hint", "") or ""

            marks_str = f"&nbsp;({marks})" if marks else ""
            text = f"{q_num}.&nbsp;&nbsp;{q_text}{marks_str}"
            flow.append(Paragraph(text, ST["q_text"]))
            if q_type in ("long", "essay"):
                # fewer / thinner ruled lines at smaller scale to save space
                n_lines = 3 if S >= 0.9 else 2
                flow.append(_answer_lines(n_lines, width, S))
            if teacher_copy and hint_t:
                flow.append(Paragraph(f"✔ <i>Ans: {hint_t[:90]}</i>", ST["answer"]))
        return flow

    # Build a render plan: MCQ sections full-width; consecutive non-MCQ
    # sections paired side by side (matches the reference's B+C, D+E look).
    plan = []
    i = 0
    while i < len(seen_sections):
        sl = seen_sections[i]
        s_qs = sections[sl]
        s_type = s_qs[0].get("question_type", "short")
        if s_type == "mcq":
            plan.append(("single", sl))
            i += 1
        else:
            nxt = seen_sections[i+1] if i+1 < len(seen_sections) else None
            nxt_type = sections[nxt][0].get("question_type", "short") if nxt else None
            if nxt and nxt_type != "mcq":
                plan.append(("pair", sl, nxt))
                i += 2
            else:
                plan.append(("single", sl))
                i += 1

    def _mcq_flat(sec_qs):
        """Fallback MCQ rendering used only when a section is too tall to
        ever fit on one page: one flowable per question, appended directly
        to the story (not nested in any table), so ReportLab can paginate
        freely between them. Loses the 2-column layout in this rare case,
        but guarantees the PDF still generates instead of failing."""
        out = []
        hint = _TYPE_HINT.get("mcq", "")
        if hint:
            out.append(Paragraph(hint, ST["sec_hint"]))
        for q in sec_qs:
            q_num  = q.get("question_number", "")
            q_text = q.get("question_text", "")
            opts   = q.get("options", []) or []
            lines = [f"<b>{q_num}.</b>&nbsp;{q_text}"]
            if opts:
                labels = ["A)", "B)", "C)", "D)"]
                opt_line = "&nbsp;&nbsp;&nbsp;".join(
                    f"{labels[i]}&nbsp;{opt}" for i, opt in enumerate(opts[:4]))
                lines.append(f"<font size={F(7.6):.1f}>{opt_line}</font>")
            out.append(Paragraph("<br/>".join(lines), ST["q_text"]))
            if teacher_copy and q.get("answer_hint"):
                out.append(Paragraph(f"✔ <i>Ans: {q['answer_hint'][:80]}</i>", ST["answer"]))
        return out

    for entry in plan:
        if entry[0] == "single":
            sl = entry[1]
            s_qs = sections[sl]
            s_title = s_qs[0].get("section_title", f"Section {sl}")
            s_marks = sum(int(q.get("marks", 0)) for q in s_qs)
            s_type  = s_qs[0].get("question_type", "short")
            header = _section_header(sl, s_title, s_marks, cw)

            if _allow_split:
                # Flat fallback: header + each question appended directly
                # to the story so pagination can happen freely between
                # them, even if the section as a whole is very long.
                body = _mcq_flat(s_qs) if s_type == "mcq" else _listed_block(s_qs, cw)
                story.append(header)
                for f in body:
                    story.append(f)
                story.append(Spacer(1, SP(2.0) * mm))
                continue

            body = (_mcq_block(sl, s_qs, cw) if s_type == "mcq"
                    else _listed_block(s_qs, cw))
            items = [header] + body

            sec_tbl = Table([[f] for f in items], colWidths=[cw])
            sec_tbl.setStyle(TableStyle([
                ("VALIGN",        (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING",   (0, 0), (-1, -1), 0),
                ("RIGHTPADDING",  (0, 0), (-1, -1), 0),
                ("TOPPADDING",    (0, 0), (-1, -1), 0),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
            ]))
            # KeepTogether: if this whole section doesn't fit in the space
            # left on the current page, ReportLab moves it entirely to the
            # next page rather than splitting it mid-question. That's what
            # keeps every new page starting on a clean section boundary.
            story.append(_kt(sec_tbl))
            story.append(Spacer(1, SP(2.0) * mm))
        else:
            sl1, sl2 = entry[1], entry[2]
            col_w = (cw - 6*mm) / 2
            s1_qs, s2_qs = sections[sl1], sections[sl2]
            s1_title = s1_qs[0].get("section_title", f"Section {sl1}")
            s2_title = s2_qs[0].get("section_title", f"Section {sl2}")
            s1_marks = sum(int(q.get("marks", 0)) for q in s1_qs)
            s2_marks = sum(int(q.get("marks", 0)) for q in s2_qs)

            if _allow_split:
                # Flat fallback: render each section full-width, one after
                # another, instead of side-by-side — guarantees pagination
                # can happen freely even if either section is very long.
                story.append(_section_header(sl1, s1_title, s1_marks, cw))
                for f in _listed_block(s1_qs, cw):
                    story.append(f)
                story.append(Spacer(1, SP(1.8) * mm))
                story.append(_section_header(sl2, s2_title, s2_marks, cw))
                for f in _listed_block(s2_qs, cw):
                    story.append(f)
                story.append(Spacer(1, SP(2.0) * mm))
                continue

            def _q_para(q):
                q_num  = q.get("question_number", "")
                q_text = q.get("question_text", "")
                marks  = q.get("marks", 0)
                marks_str = f"&nbsp;({marks})" if marks else ""
                text = f"{q_num}.&nbsp;&nbsp;{q_text}{marks_str}"
                if teacher_copy and q.get("answer_hint"):
                    text += f"<br/><font color='#15803d'><i>✔ Ans: {q['answer_hint'][:70]}</i></font>"
                return Paragraph(text, ST["q_text"])

            rows = [[_section_header(sl1, s1_title, s1_marks, col_w),
                    _section_header(sl2, s2_title, s2_marks, col_w)]]
            n = max(len(s1_qs), len(s2_qs))
            blank = Paragraph("", ST["q_text"])
            for idx in range(n):
                left  = _q_para(s1_qs[idx]) if idx < len(s1_qs) else blank
                right = _q_para(s2_qs[idx]) if idx < len(s2_qs) else blank
                rows.append([left, right])

            pair_tbl = Table(rows, colWidths=[col_w, col_w])
            pair_tbl.setStyle(TableStyle([
                ("VALIGN",        (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING",   (0, 0), (0, -1),  0),
                ("RIGHTPADDING",  (0, 0), (0, -1),  PD(3)),
                ("LEFTPADDING",   (1, 0), (1, -1),  PD(3)),
                ("RIGHTPADDING",  (1, 0), (1, -1),  0),
                ("TOPPADDING",    (0, 1), (-1, -1), PD(1.2)),
                ("BOTTOMPADDING", (0, 1), (-1, -1), PD(0.8)),
                ("TOPPADDING",    (0, 0), (-1, 0),  0),
                ("BOTTOMPADDING", (0, 0), (-1, 0),  0),
            ]))
            story.append(_kt(pair_tbl))
            story.append(Spacer(1, SP(2.0) * mm))

    # ─────────────────────────────────────────────────────────────────────────
    # FOOTER — Prepared By / Checked By / Principal Signature
    # ─────────────────────────────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.6, color=C["line"]))
    story.append(Spacer(1, SP(1.2) * mm))

    foot_tbl = Table([[
        Paragraph("Prepared By: _______________", ST["footer_lbl"]),
        Paragraph("Checked By: _______________", ST["footer_lbl"]),
        Paragraph("Principal Signature: _______________", ST["footer_lbl"]),
    ]], colWidths=[cw/3, cw/3, cw/3])
    foot_tbl.setStyle(TableStyle([
        ("TOPPADDING", (0, 0), (-1, -1), PD(1.2)),
        ("BOTTOMPADDING", (0, 0), (-1, -1), PD(1.2)),
    ]))
    story.append(foot_tbl)

    if teacher_copy:
        story.append(Spacer(1, SP(1.0) * mm))
        story.append(Paragraph(
            f"★ TEACHER'S COPY ★   Generated: {datetime.now().strftime('%d %b %Y  %I:%M %p')}",
            ST["footer_lbl"]))

    # ─────────────────────────────────────────────────────────────────────────
    # BUILD — track the real page count reached via the per-page callback,
    # then shrink and retry automatically if it went past _MAX_PAGES.
    # ─────────────────────────────────────────────────────────────────────────
    page_tracker = {"last_page": 1}

    def on_page(canv, doc):
        page_tracker["last_page"] = doc.page
        canv.saveState()
        canv.setFont("Helvetica", F(6.6))
        canv.setFillColor(C["light"])
        canv.drawCentredString(PAGE_W / 2, 5.5 * mm, f"Page {doc.page}")
        canv.restoreState()

        try:
            from core.demo_config import DEMO_MODE, WATERMARK_TEXT, FOOTER_CONTACT
        except Exception:
            DEMO_MODE = False
        if DEMO_MODE:
            canv.saveState()
            try:
                canv.setFillColor(colors.HexColor("#94a3b8"))
                canv.setFillAlpha(0.16)
            except Exception:
                canv.setFillColor(colors.HexColor("#cbd5e1"))
            canv.setFont("Helvetica-Bold", min(PAGE_W, PAGE_H) * 0.14)
            canv.translate(PAGE_W / 2, PAGE_H / 2)
            canv.rotate(38)
            canv.drawCentredString(0, 0, WATERMARK_TEXT)
            canv.restoreState()

            canv.saveState()
            canv.setFillColor(colors.HexColor("#dc2626"))
            canv.setFont("Helvetica-Bold", 6)
            canv.drawCentredString(PAGE_W / 2, 2.5 * mm, FOOTER_CONTACT)
            canv.restoreState()

    try:
        doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
    except Exception as e:
        if not _allow_split and "too large" in str(e).lower():
            # One section is genuinely taller than a full page (an
            # extreme question count in a single section) — regenerate
            # once allowing that content to flow across a page break
            # rather than failing outright. This is a rare edge case;
            # normal-sized papers never hit this path.
            return generate_exam_paper(output_path, config, questions,
                                    teacher_copy=teacher_copy, _allow_split=True,
                                    _scale=_scale, _attempt=_attempt,
                                    _best_so_far=_best_so_far)
        raise

    pages_used = page_tracker["last_page"]

    # Remember the best (fewest-pages) attempt so far in case we bottom
    # out at _MIN_SCALE without ever reaching _MAX_PAGES.
    if _best_so_far is None or pages_used < _best_so_far.get("pages", 10**9):
        try:
            with open(output_path, "rb") as f:
                pdf_bytes = f.read()
        except Exception:
            pdf_bytes = None
        _best_so_far = {"pages": pages_used, "bytes": pdf_bytes, "scale": S}
    else:
        _best_so_far = _best_so_far  # keep the earlier, better attempt

    if pages_used > _MAX_PAGES and not _allow_split and _attempt < _MAX_ATTEMPTS \
            and S * _SHRINK_STEP >= _MIN_SCALE:
        return generate_exam_paper(output_path, config, questions,
                                teacher_copy=teacher_copy,
                                _allow_split=False,
                                   _scale=S * _SHRINK_STEP,
                                _attempt=_attempt + 1,
                                _best_so_far=_best_so_far)

    if pages_used > _MAX_PAGES and _best_so_far and _best_so_far.get("bytes"):
        # Hit the minimum legible scale without getting under _MAX_PAGES
        # (paper genuinely has too much content) — write back whichever
        # attempt used the fewest pages, so the file on disk is the best
        # available result rather than the last (possibly worse) retry.
        with open(output_path, "wb") as f:
            f.write(_best_so_far["bytes"])

    return page_tracker["last_page"] if pages_used <= _MAX_PAGES else _best_so_far.get("pages", pages_used)


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _logo_cell(logo_path, school_name, colors, mm, size_mm=18):
    """A bordered circular badge with the school's logo, or its initial
    letter in black-on-white if no logo is set — matches the reference
    template's shield/crest badge in the top-left corner. size_mm shrinks
    together with the rest of the layout at smaller scales."""
    from reportlab.platypus import Image, Paragraph
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.styles import ParagraphStyle
    size_mm = max(11, size_mm)
    if logo_path and os.path.isfile(logo_path):
        try:
            img = Image(logo_path, width=size_mm * mm, height=size_mm * mm)
            img.hAlign = "CENTER"
            return img
        except Exception:
            pass
    initial = (school_name[0].upper() if school_name else "S")
    return Paragraph(
        f"<b>{initial}</b>",
        ParagraphStyle("LFb", fontName="Helvetica-Bold", fontSize=max(14, size_mm),
                    textColor=colors.HexColor("#111111"), alignment=TA_CENTER)
    )


def _answer_lines(n: int, width: float, scale: float = 1.0):
    from reportlab.platypus import Table, TableStyle
    from reportlab.lib import colors as c
    rows = [[" "] for _ in range(n)]
    t = Table(rows, colWidths=[width - 10])
    top_pad = max(1, round(4 * scale))
    bot_pad = max(1, round(1.5 * scale))
    t.setStyle(TableStyle(
        [("LINEBELOW", (0, i), (-1, i), 0.4, c.HexColor("#9ca3af"))
        for i in range(n)] +
        [("TOPPADDING",    (0, 0), (-1, -1), top_pad),
    ("BOTTOMPADDING", (0, 0), (-1, -1), bot_pad),
        ("LEFTPADDING",   (0, 0), (-1, -1), 5)]
    ))
    return t
