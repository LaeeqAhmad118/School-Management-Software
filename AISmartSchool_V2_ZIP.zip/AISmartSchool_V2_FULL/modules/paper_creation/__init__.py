"""Paper Creation Module — Fully Offline AI Exam Paper Generator"""
from modules.paper_creation.paper_creation_view import PaperCreationView
