"""
Paper Creation Module — View
============================
Standalone module. Accessible from the sidebar as "Paper Creation".
Completely offline. No API key. No internet required.

Features:
  • Upload one or many syllabus PDFs (optional)
  • Configure paper details: school, subject, class, teacher, marks, time, date
  • Build sections: type, count, marks per question
  • AI generates questions offline using NLP on the PDF text
  • Edit any question in the table before exporting
  • Export Student PDF  /  Print  /  Export Teacher's Copy (with answers)
"""
import os
import subprocess
import platform
from datetime import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QFrame, QScrollArea, QFileDialog, QComboBox, QLineEdit,
    QSpinBox, QTextEdit, QProgressBar, QMessageBox, QGroupBox,
    QListWidget, QListWidgetItem, QSplitter, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView, QSizePolicy,
)
from core.color_utils import rgba
from PySide6.QtCore import Qt, Signal, QThread

from ui.components.widgets import SectionHeader
from core.school_context import SchoolContext


# ---------------------------------------------------------------------------
# BACKGROUND WORKER THREAD
# ---------------------------------------------------------------------------

class GeneratorThread(QThread):
    progress = Signal(str)
    finished = Signal(dict)      # {"questions": [...], "error": str|None}

    def __init__(self, config: dict):
        super().__init__()
        self.config = config

    def run(self):
        try:
            self.progress.emit("📄 Reading syllabus content...")
            from modules.paper_creation.offline_engine import generate_questions_offline
            self.progress.emit("🧠 Analysing text and generating questions...")
            questions = generate_questions_offline(self.config)
            self.progress.emit(f"✅ Done — {len(questions)} questions ready.")
            self.finished.emit({"questions": questions, "error": None})
        except Exception as e:
            import traceback
            self.finished.emit({
                "questions": [],
                "error": f"{e}\n\n{traceback.format_exc()}"
            })


# ---------------------------------------------------------------------------
# SECTION ROW WIDGET
# ---------------------------------------------------------------------------

class SectionRow(QFrame):
    removed       = Signal(object)
    marks_changed = Signal()

    _TYPES = [
        ("mcq",        "Multiple Choice (MCQ)"),
        ("short",      "Short Questions"),
        ("long",       "Long Questions"),
        ("fill_blank", "Fill in the Blanks"),
        ("true_false", "True / False"),
        ("definition", "Definitions"),
        ("essay",      "Essay / Paragraph"),
    ]

    def __init__(self, label="A", type_code="short", count=5, marks=4, parent=None):
        super().__init__(parent)
        self.setStyleSheet(
            "QFrame{background:#1e293b;border:1px solid #334155;border-radius:8px;}"
            "QFrame:hover{border-color:#3b82f6;}"
            "QFrame QLabel{background:transparent;border:none;}"
        )
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 8, 10, 8)
        outer.setSpacing(6)

        INP = ("background:#0f172a;color:#f1f5f9;border:1px solid #334155;"
            "border-radius:5px;padding:4px 7px;font-size:12px;")

        def lbl(t):
            l = QLabel(t)
            l.setStyleSheet("color:#94a3b8;font-size:11px;font-weight:600;background:transparent;")
            return l

        # ── Row 1: Section label, Type, delete button ──────────────────────
        row1 = QHBoxLayout()
        row1.setSpacing(8)
        row1.addWidget(lbl("Section:"))
        self.le_label = QLineEdit(label)
        self.le_label.setFixedWidth(44)
        self.le_label.setStyleSheet(INP + "font-weight:800;")
        row1.addWidget(self.le_label)

        row1.addWidget(lbl("Type:"))
        self.cb_type = QComboBox()
        for code, name in self._TYPES:
            self.cb_type.addItem(name, code)
        idx = next((i for i, (c, _) in enumerate(self._TYPES) if c == type_code), 1)
        self.cb_type.setCurrentIndex(idx)
        self.cb_type.setStyleSheet(INP)
        self.cb_type.setMinimumWidth(150)
        row1.addWidget(self.cb_type, 1)

        btn_del = QPushButton("✕ Remove")
        btn_del.setFixedHeight(26)
        btn_del.setCursor(Qt.PointingHandCursor)
        btn_del.setStyleSheet(
            "QPushButton{background:#ef4444;color:white;border:none;"
            "border-radius:5px;font-weight:700;font-size:11px;padding:2px 10px;}"
            "QPushButton:hover{background:#dc2626;}"
        )
        btn_del.clicked.connect(lambda: self.removed.emit(self))
        row1.addWidget(btn_del)
        outer.addLayout(row1)

        # ── Row 2: No. of Questions, Marks each, Total — always visible ────
        row2 = QHBoxLayout()
        row2.setSpacing(8)

        qbox = QVBoxLayout(); qbox.setSpacing(1)
        qbox.addWidget(lbl("No. of Questions"))
        self.sp_count = QSpinBox()
        self.sp_count.setRange(1, 40)
        self.sp_count.setValue(count)
        self.sp_count.setMinimumWidth(72)
        self.sp_count.setMinimumHeight(28)
        self.sp_count.setStyleSheet(INP + "font-weight:700;")
        self.sp_count.setToolTip("Number of questions in this section")
        qbox.addWidget(self.sp_count)
        row2.addLayout(qbox)

        mbox = QVBoxLayout(); mbox.setSpacing(1)
        mbox.addWidget(lbl("Marks Each"))
        self.sp_marks = QSpinBox()
        self.sp_marks.setRange(1, 50)
        self.sp_marks.setValue(marks)
        self.sp_marks.setMinimumWidth(72)
        self.sp_marks.setMinimumHeight(28)
        self.sp_marks.setStyleSheet(INP + "font-weight:700;")
        mbox.addWidget(self.sp_marks)
        row2.addLayout(mbox)

        row2.addStretch()

        tbox = QVBoxLayout(); tbox.setSpacing(1); tbox.setAlignment(Qt.AlignRight)
        tbox.addWidget(lbl("Section Total"))
        self.lbl_total = QLabel(f"= {count * marks} marks")
        self.lbl_total.setAlignment(Qt.AlignRight)
        self.lbl_total.setStyleSheet(
            "color:#60a5fa;font-size:13px;font-weight:800;background:transparent;")
        tbox.addWidget(self.lbl_total)
        row2.addLayout(tbox)

        outer.addLayout(row2)

        self.sp_count.valueChanged.connect(self._refresh)
        self.sp_marks.valueChanged.connect(self._refresh)

    def _refresh(self):
        t = self.sp_count.value() * self.sp_marks.value()
        self.lbl_total.setText(f"= {t} marks")
        self.marks_changed.emit()

    def get_data(self) -> dict:
        return {
            "label":        self.le_label.text().strip() or "A",
            "type":         self.cb_type.currentData(),
            "type_display": self.cb_type.currentText(),
            "count":        self.sp_count.value(),
            "marks_each":   self.sp_marks.value(),
            "total":        self.sp_count.value() * self.sp_marks.value(),
        }


# ---------------------------------------------------------------------------
# QUESTION EDITOR TABLE
# ---------------------------------------------------------------------------

class QuestionEditor(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._qs: list = []
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)

        bar = QHBoxLayout()
        self.lbl_count = QLabel("0 Questions")
        self.lbl_marks = QLabel("Total: 0 Marks")
        tip = QLabel("💡 Double-click any cell to edit")
        self.lbl_count.setStyleSheet(
            "color:#ffffff;background:#2563eb;font-size:12px;font-weight:800;"
            "padding:5px 12px;border-radius:12px;")
        self.lbl_marks.setStyleSheet(
            "color:#ffffff;background:#16a34a;font-size:12px;font-weight:800;"
            "padding:5px 12px;border-radius:12px;")
        tip.setStyleSheet("color:#64748b;font-size:11px;background:transparent;")
        bar.addWidget(self.lbl_count)
        bar.addSpacing(10)
        bar.addWidget(self.lbl_marks)
        bar.addStretch()
        bar.addWidget(tip)
        lay.addLayout(bar)

        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Sec", "Q#", "Question Text", "Type", "Marks"])
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        hh.setStyleSheet(
            "QHeaderView::section{background:#1e293b;color:#64748b;"
            "font-size:11px;font-weight:700;padding:7px;border:none;"
            "border-bottom:2px solid #334155;}"
        )
        self.table.setStyleSheet(
            "QTableWidget{background:#0f172a;color:#e2e8f0;"
            "border:1px solid #334155;border-radius:8px;"
            "gridline-color:#293548;font-size:12px;"
            "selection-background-color:#1d4ed8;selection-color:#ffffff;}"
            "QTableWidget::item{padding:8px;border-bottom:1px solid #1e293b;"
            "border-right:1px solid #1e293b;}"
            "QTableWidget::item:alternate{background:#111c33;}"
            "QTableWidget::item:selected{background:#1d4ed8;color:#ffffff;}"
        )
        self.table.setShowGrid(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.setColumnWidth(0, 44)
        self.table.setColumnWidth(1, 34)
        self.table.setColumnWidth(3, 110)
        self.table.setColumnWidth(4, 56)
        lay.addWidget(self.table)

    def load(self, questions: list):
        self._qs = questions
        self.table.setRowCount(0)
        total = 0
        for q in questions:
            r = self.table.rowCount()
            self.table.insertRow(r)
            vals = [
                str(q.get("section", "")),
                str(q.get("question_number", "")),
                q.get("question_text", ""),
                q.get("question_type", ""),
                str(q.get("marks", 0)),
            ]
            for c, v in enumerate(vals):
                item = QTableWidgetItem(v)
                item.setToolTip(v)
                if c in (0, 1, 3, 4):
                    item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(r, c, item)
            total += int(q.get("marks", 0))
        self.lbl_count.setText(f"{len(questions)} Questions")
        self.lbl_marks.setText(f"Total: {total} Marks")

    def get_questions(self) -> list:
        out = []
        for r in range(self.table.rowCount()):
            q = dict(self._qs[r]) if r < len(self._qs) else {}
            def cell(c): return (self.table.item(r, c).text()
                                 if self.table.item(r, c) else "")
            q["section"]       = cell(0)
            q["question_text"] = cell(2)
            try:
                q["marks"] = int(cell(4))
            except ValueError:
                pass
            out.append(q)
        return out


# ---------------------------------------------------------------------------
# MAIN VIEW
# ---------------------------------------------------------------------------

class PaperCreationView(QWidget):

    def __init__(self, db, user):
        super().__init__()
        self.db          = db
        self.user        = user
        self._pdf_paths  : list = []
        self._questions  : list = []
        self._thread     = None
        self._ctx        = SchoolContext.instance()
        self._setup_ui()

    # -------------------------------------------------------------------------
    # UI SETUP
    # -------------------------------------------------------------------------

    _INP = ("background:#0f172a;color:#f1f5f9;border:1px solid #334155;"
            "border-radius:6px;padding:4px 8px;font-size:12px;")

    def _setup_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(16)

        hdr = SectionHeader(
            "📄 Paper Creation",
            "Generate exam papers from syllabus PDFs — 100% Offline, No Internet Required"
        )
        self._btn_generate = hdr.add_button("Generate Questions", "btn_add", "🧠")
        self._btn_generate.clicked.connect(self._on_generate)
        root.addWidget(hdr)

        splitter = QSplitter(Qt.Horizontal)

        # ── LEFT ──────────────────────────────────────────────────────────────
        lscroll = QScrollArea()
        lscroll.setWidgetResizable(True)
        lscroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        lw = QWidget(); lw.setStyleSheet("background:transparent;")
        ll = QVBoxLayout(lw); ll.setContentsMargins(0, 0, 8, 0); ll.setSpacing(14)

        # PDFs
        gpdf = self._group("📂 Syllabus PDFs")
        pbrow = QHBoxLayout()
        for txt, icon, color, slot in [
            ("Add PDF(s)", "➕", "#2563eb", self._add_pdfs),
            ("Clear",      "🗑", "#dc2626", self._clear_pdfs),
        ]:
            b = QPushButton(f"{icon}  {txt}")
            b.setStyleSheet(self._btn_css(color))
            b.clicked.connect(slot)
            pbrow.addWidget(b)
        pbrow.addStretch()
        self._pdf_list = QListWidget()
        self._pdf_list.setFixedHeight(88)
        self._pdf_list.setStyleSheet(
            "QListWidget{background:#0f172a;color:#e2e8f0;"
            "border:1px solid #334155;border-radius:6px;font-size:12px;padding:4px;}"
            "QListWidget::item{padding:2px 6px;border-radius:3px;}"
            "QListWidget::item:hover{background:#1e293b;}"
        )
        self._lbl_pdf = QLabel("No PDFs added — AI uses built-in subject content")
        self._lbl_pdf.setStyleSheet("color:#f59e0b;font-size:11px;background:transparent;")
        gpdf.layout().addLayout(pbrow)
        gpdf.layout().addWidget(self._pdf_list)
        gpdf.layout().addWidget(self._lbl_pdf)
        ll.addWidget(gpdf)

        # Paper details
        gdet = self._group("📋 Paper Details")
        self._f_school  = self._inp(self._ctx.name)
        self._f_subject = self._inp("", "e.g. Mathematics, Physics, Urdu")
        self._f_class   = self._inp("", "e.g. Class 9 - A")
        self._f_teacher = self._inp("", "Teacher's full name")
        self._f_title   = self._inp("", "e.g. Annual Examination 2025")
        self._f_date    = self._inp(datetime.now().strftime("%d-%m-%Y"))
        self._f_time    = self._inp("3 Hours")

        self._sp_marks = QSpinBox()
        self._sp_marks.setRange(10, 600)
        self._sp_marks.setValue(100)
        self._sp_marks.setStyleSheet(self._INP)

        self._cb_level = QComboBox()
        self._cb_level.addItems(["Easy", "Medium", "Hard", "Mixed"])
        self._cb_level.setCurrentIndex(1)
        self._cb_level.setStyleSheet(self._INP)

        for label, widget in [
            ("School Name:",  self._f_school),
            ("Subject:",      self._f_subject),
            ("Class:",        self._f_class),
            ("Teacher:",      self._f_teacher),
            ("Exam Title:",   self._f_title),
            ("Exam Date:",    self._f_date),
            ("Time Allowed:", self._f_time),
            ("Total Marks:",  self._sp_marks),
            ("Difficulty:",   self._cb_level),
        ]:
            row = QHBoxLayout()
            l = QLabel(label); l.setFixedWidth(104)
            l.setStyleSheet("color:#64748b;font-size:12px;background:transparent;")
            row.addWidget(l); row.addWidget(widget)
            gdet.layout().addLayout(row)
        ll.addWidget(gdet)

        # Sections
        gsec = self._group("📐 Paper Pattern / Sections")
        self._sec_lay = QVBoxLayout(); self._sec_lay.setSpacing(6)
        gsec.layout().addLayout(self._sec_lay)
        sec_btns = QHBoxLayout()
        btn_add_sec = QPushButton("➕  Add Section")
        btn_add_sec.setStyleSheet(self._btn_css("#16a34a"))
        btn_add_sec.clicked.connect(lambda: self._add_section())
        self._lbl_pat = QLabel("Configured: 0 / 100 marks")
        self._lbl_pat.setStyleSheet(
            "color:#f59e0b;font-size:12px;font-weight:700;background:transparent;")
        sec_btns.addWidget(btn_add_sec); sec_btns.addStretch()
        sec_btns.addWidget(self._lbl_pat)
        gsec.layout().addLayout(sec_btns)
        ll.addWidget(gsec)

        self._add_section("A", "mcq",   10, 1)
        self._add_section("B", "short",  5, 4)
        self._add_section("C", "long",   3, 10)

        # Extra instructions
        gext = self._group("📝 Extra Instructions for AI (Optional)")
        self._te_extra = QTextEdit()
        self._te_extra.setFixedHeight(58)
        self._te_extra.setPlaceholderText(
            "e.g. Focus on chapters 3–5, avoid repeated topics, include diagram questions...")
        self._te_extra.setStyleSheet(
            "background:#0f172a;color:#e2e8f0;border:1px solid #334155;"
            "border-radius:6px;padding:6px;font-size:12px;")
        gext.layout().addWidget(self._te_extra)
        ll.addWidget(gext)
        ll.addStretch()

        lscroll.setWidget(lw)
        splitter.addWidget(lscroll)

        # ── RIGHT ─────────────────────────────────────────────────────────────
        rw = QWidget(); rw.setStyleSheet("background:transparent;")
        rl = QVBoxLayout(rw); rl.setContentsMargins(8, 0, 0, 0); rl.setSpacing(10)

        self._prog = QProgressBar()
        self._prog.setRange(0, 0); self._prog.setFixedHeight(5)
        self._prog.setStyleSheet(
            "QProgressBar{background:#1e293b;border:none;border-radius:2px;}"
            "QProgressBar::chunk{background:#2563eb;border-radius:2px;}")
        self._prog.hide()
        rl.addWidget(self._prog)

        self._lbl_status = QLabel("")
        self._lbl_status.setStyleSheet("color:#60a5fa;font-size:12px;background:transparent;")
        rl.addWidget(self._lbl_status)

        gq = self._group("✏️  Generated Questions  (double-click any cell to edit)")
        self._editor = QuestionEditor()
        gq.layout().addWidget(self._editor)
        rl.addWidget(gq, 1)

        act_row = QGridLayout(); act_row.setSpacing(10)
        self._btn_gen2    = QPushButton("🧠  Generate Questions")
        self._btn_pdf     = QPushButton("📄  Export Student PDF")
        self._btn_print   = QPushButton("🖨️  Print Paper")
        self._btn_teacher = QPushButton("📋  Teacher's Copy + Answers")
        for btn, color, enabled in [
            (self._btn_gen2,    "#2563eb", True),
            (self._btn_pdf,     "#7c3aed", False),
            (self._btn_print,   "#16a34a", False),
            (self._btn_teacher, "#ea580c", False),
        ]:
            btn.setStyleSheet(self._btn_css(color, large=True))
            btn.setEnabled(enabled)
            btn.setMinimumHeight(42)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        act_row.addWidget(self._btn_gen2,    0, 0)
        act_row.addWidget(self._btn_pdf,     0, 1)
        act_row.addWidget(self._btn_print,   1, 0)
        act_row.addWidget(self._btn_teacher, 1, 1)
        self._btn_gen2.clicked.connect(self._on_generate)
        self._btn_pdf.clicked.connect(self._on_export_pdf)
        self._btn_print.clicked.connect(self._on_print)
        self._btn_teacher.clicked.connect(self._on_export_teacher)
        rl.addLayout(act_row)

        splitter.addWidget(rw)
        splitter.setSizes([450, 680])
        root.addWidget(splitter, 1)

    def _group(self, title: str) -> QGroupBox:
        g = QGroupBox(title)
        g.setStyleSheet(
            "QGroupBox{background:#1e293b;border:1px solid #334155;"
            "border-radius:10px;margin-top:6px;font-size:12px;"
            "font-weight:700;color:#e2e8f0;padding:10px;}"
            "QGroupBox::title{subcontrol-origin:margin;left:12px;padding:0 6px;color:#60a5fa;}"
        )
        QVBoxLayout(g).setContentsMargins(10, 18, 10, 10)
        return g

    def _inp(self, default="", placeholder="") -> QLineEdit:
        w = QLineEdit(default)
        if placeholder: w.setPlaceholderText(placeholder)
        w.setStyleSheet(self._INP)
        return w

    def _btn_css(self, color: str, large: bool = False) -> str:
        p = "10px 18px" if large else "6px 14px"
        return (f"QPushButton{{background:{color};color:#ffffff;border:2px solid transparent;"
                f"border-radius:8px;padding:{p};font-size:{'13px' if large else '12px'};font-weight:800;}}"
                f"QPushButton:hover{{background:{color};border:2px solid #ffffff55;}}"
                f"QPushButton:pressed{{background:{rgba(color, 'aa')};}}"
                f"QPushButton:disabled{{background:#293548;color:#8291a8;border:2px solid #334155;}}")

    # -------------------------------------------------------------------------
    # SECTIONS
    # -------------------------------------------------------------------------

    def _section_rows(self) -> list:
        return [self._sec_lay.itemAt(i).widget()
                for i in range(self._sec_lay.count())
                if isinstance(self._sec_lay.itemAt(i).widget(), SectionRow)]

    def _add_section(self, label=None, type_code="short", count=5, marks=4):
        lbl = label or chr(ord("A") + len(self._section_rows()))
        row = SectionRow(lbl, type_code, count, marks)
        row.removed.connect(self._remove_section)
        row.marks_changed.connect(self._refresh_pattern_total)
        self._sec_lay.addWidget(row)
        self._refresh_pattern_total()

    def _remove_section(self, row):
        self._sec_lay.removeWidget(row); row.deleteLater()
        self._refresh_pattern_total()

    def _refresh_pattern_total(self):
        total  = sum(r.get_data()["total"] for r in self._section_rows())
        target = self._sp_marks.value()
        color  = "#22c55e" if total == target else "#f59e0b"
        self._lbl_pat.setText(f"Configured: {total} / {target} marks")
        self._lbl_pat.setStyleSheet(
            f"color:{color};font-size:12px;font-weight:700;background:transparent;")

    # -------------------------------------------------------------------------
    # PDFs
    # -------------------------------------------------------------------------

    def _add_pdfs(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Select Syllabus PDFs", "", "PDF Files (*.pdf);;All Files (*)")
        for f in files:
            if f not in self._pdf_paths:
                self._pdf_paths.append(f)
                self._pdf_list.addItem(QListWidgetItem(f"📄  {os.path.basename(f)}"))
        self._refresh_pdf_label()

    def _clear_pdfs(self):
        self._pdf_paths.clear(); self._pdf_list.clear(); self._refresh_pdf_label()

    def _refresh_pdf_label(self):
        n = len(self._pdf_paths)
        if n:
            self._lbl_pdf.setText(f"✅  {n} PDF{'s' if n>1 else ''} loaded")
            self._lbl_pdf.setStyleSheet("color:#22c55e;font-size:11px;background:transparent;")
        else:
            self._lbl_pdf.setText("No PDFs added — AI uses built-in subject content")
            self._lbl_pdf.setStyleSheet("color:#f59e0b;font-size:11px;background:transparent;")

    # -------------------------------------------------------------------------
    # CONFIG
    # -------------------------------------------------------------------------

    def _build_config(self) -> dict:
        info = self._ctx.info if hasattr(self._ctx, "info") else {}
        extra_instructions = self._te_extra.toPlainText().strip()
        instructions = [line.strip() for line in extra_instructions.split("\n") if line.strip()] or None
        return {
            "pdf_paths":          self._pdf_paths,
            "school_name":        self._f_school.text().strip(),
            "school_address":     info.get("address", ""),
            "school_phone":       info.get("phone", ""),
            "school_email":       info.get("email", ""),
            "school_website":     info.get("website", ""),
            "school_tagline":     info.get("motto", ""),
            "subject":            self._f_subject.text().strip() or "General",
            "class_name":         self._f_class.text().strip(),
            "teacher":            self._f_teacher.text().strip(),
            "exam_title":         self._f_title.text().strip(),
            "total_marks":        self._sp_marks.value(),
            "time_allowed":       self._f_time.text().strip(),
            "paper_level":        self._cb_level.currentText(),
            "exam_date":          self._f_date.text().strip(),
            "extra_instructions": extra_instructions,
            "instructions":       instructions,
            "logo_path":          self._ctx.logo_path,
            "pattern":            {"sections": [r.get_data() for r in self._section_rows()]},
        }

    # -------------------------------------------------------------------------
    # GENERATE
    # -------------------------------------------------------------------------

    def _on_generate(self):
        if not self._section_rows():
            QMessageBox.warning(self, "No Sections",
                "Please add at least one paper section before generating.")
            return
        self._prog.show()
        self._lbl_status.setStyleSheet("color:#60a5fa;font-size:12px;background:transparent;")
        self._lbl_status.setText("⏳ Starting...")
        self._btn_generate.setEnabled(False)
        self._btn_gen2.setEnabled(False)
        self._thread = GeneratorThread(self._build_config())
        self._thread.progress.connect(self._on_progress)
        self._thread.finished.connect(self._on_done)
        self._thread.start()

    def _on_progress(self, msg: str):
        self._lbl_status.setText(msg)

    def _on_done(self, result: dict):
        self._prog.hide()
        self._btn_generate.setEnabled(True)
        self._btn_gen2.setEnabled(True)
        if result.get("error"):
            self._lbl_status.setStyleSheet("color:#ef4444;font-size:12px;background:transparent;")
            self._lbl_status.setText("❌ Generation failed")
            QMessageBox.critical(self, "Generation Failed",
                f"Error during question generation:\n\n{result['error']}")
            return
        self._questions = result.get("questions", [])
        self._editor.load(self._questions)
        self._lbl_status.setStyleSheet("color:#22c55e;font-size:12px;background:transparent;")
        self._lbl_status.setText(
            f"✅  {len(self._questions)} questions generated — review, edit, then export or print.")
        for btn in (self._btn_pdf, self._btn_print, self._btn_teacher):
            btn.setEnabled(True)

    # -------------------------------------------------------------------------
    # EXPORT / PRINT
    # -------------------------------------------------------------------------

    def _get_qs(self) -> list:
        qs = self._editor.get_questions()
        if not qs:
            QMessageBox.warning(self, "No Questions",
                "Generate questions first, then export.")
        return qs

    def _on_export_pdf(self):
        qs = self._get_qs()
        if not qs: return
        subj = self._f_subject.text().strip() or "Paper"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Student Exam Paper",
            f"ExamPaper_{subj}_{datetime.now().strftime('%Y%m%d')}.pdf",
            "PDF Files (*.pdf)")
        if path:
            self._save_pdf(path, qs, teacher_copy=False)

    def _on_export_teacher(self):
        qs = self._get_qs()
        if not qs: return
        subj = self._f_subject.text().strip() or "Paper"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Teacher's Copy",
            f"TeacherCopy_{subj}_{datetime.now().strftime('%Y%m%d')}.pdf",
            "PDF Files (*.pdf)")
        if path:
            self._save_pdf(path, qs, teacher_copy=True)

    def _on_print(self):
        qs = self._get_qs()
        if not qs: return
        import tempfile
        tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False)
        tmp.close()
        if self._save_pdf(tmp.name, qs, teacher_copy=False, silent=True):
            self._direct_print(tmp.name)

    def _save_pdf(self, path: str, questions: list,
                  teacher_copy: bool, silent: bool = False) -> bool:
        try:
            from modules.paper_creation.paper_pdf_generator import generate_exam_paper
            generate_exam_paper(path, self._build_config(), questions,
                                teacher_copy=teacher_copy)
            if not silent:
                label = "Teacher's Copy" if teacher_copy else "Exam Paper"
                QMessageBox.information(self, f"{label} Saved",
                    f"PDF saved successfully:\n{path}")
                self._open_file(path)
            return True
        except Exception as e:
            QMessageBox.critical(self, "PDF Export Failed",
                f"Could not generate PDF:\n\n{e}\n\n"
                "Make sure reportlab is installed:\n  pip install reportlab")
            return False

    def _open_file(self, path: str):
        import subprocess, platform
        try:
            if platform.system() == "Windows":   os.startfile(path)
            elif platform.system() == "Darwin":  subprocess.call(["open", path])
            else:                                subprocess.call(["xdg-open", path])
        except Exception: pass

    def _direct_print(self, path: str):
        try:
            system = platform.system()
            if system == "Windows":
                os.startfile(path, "print")
            elif system == "Darwin":
                subprocess.call(["lpr", path])
            else:
                subprocess.call(["lpr", path])
            self._lbl_status.setStyleSheet("color:#22c55e;font-size:12px;background:transparent;")
            self._lbl_status.setText("🖨️  Sent to printer.")
        except Exception as e:
            QMessageBox.warning(self, "Print Failed",
                f"Could not send directly to the printer:\n\n{e}\n\n"
                "The PDF has been opened instead — use Ctrl+P to print from there.")
            self._open_file(path)
