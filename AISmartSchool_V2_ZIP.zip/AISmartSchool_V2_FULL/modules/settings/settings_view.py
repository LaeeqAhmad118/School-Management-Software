"""Settings V2 — saves school info and fires SchoolContext.school_updated"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from ui.components.widgets import SectionHeader
from core.school_context import SchoolContext
import os

class SettingsView(QWidget):
    def __init__(self, db, user, theme_manager=None):
        super().__init__()
        self.db = db; self.user = user; self.tm = theme_manager
        self._logo_path = ""
        self._init_ui()

    def on_school_updated(self, info):
        """Called by MainWindow when school info refreshes — re-load form."""
        self._load_form_from_db()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20); layout.setSpacing(16)
        layout.addWidget(SectionHeader("Settings", "Configure system preferences"))
        tabs = QTabWidget()

        # ── School Info ───────────────────────────────────────────────────
        school_tab = QWidget(); sl = QVBoxLayout(school_tab)
        g = QGridLayout(); g.setSpacing(12)

        def inp(val="", ph=""):
            e = QLineEdit(); e.setText(str(val) if val else "")
            e.setPlaceholderText(ph); e.setMinimumHeight(38); return e

        info = self.db.fetchone("SELECT * FROM school_info WHERE id=1") or {}
        self.s_name      = inp(info.get('name',''),      "School Name *")
        self.s_addr      = inp(info.get('address',''),   "Address")
        self.s_phone     = inp(info.get('phone',''),     "Phone")
        self.s_email     = inp(info.get('email',''),     "Email")
        self.s_principal = inp(info.get('principal',''), "Principal Name")
        self.s_city      = inp(info.get('city',''),      "City")
        self.s_motto     = inp(info.get('motto',''),     "School Motto / Tagline")
        self.s_bank      = inp(info.get('bank_name',''), "Bank Name")
        self.s_bank_ac   = inp(info.get('bank_account',''), "Bank Account No.")
        self.s_website   = inp(info.get('website',''),   "Website")

        fields = [
            ("School Name",  self.s_name),
            ("Address",      self.s_addr),
            ("Phone",        self.s_phone),
            ("Email",        self.s_email),
            ("Principal",    self.s_principal),
            ("City",         self.s_city),
            ("Motto",        self.s_motto),
            ("Website",      self.s_website),
            ("Bank Name",    self.s_bank),
            ("Bank Account", self.s_bank_ac),
        ]
        for i, (lbl, w) in enumerate(fields):
            g.addWidget(QLabel(lbl), i, 0); g.addWidget(w, i, 1)
        sl.addLayout(g)

        # Logo row
        logo_row = QHBoxLayout(); logo_row.setSpacing(8)
        self.logo_preview_lbl = QLabel("No logo selected")
        self.logo_preview_lbl.setStyleSheet(
            "color:#8b949e;font-size:12px;background:transparent;"
            "border:1px solid #30363d;border-radius:7px;padding:6px 12px;")
        self.logo_preview_lbl.setMinimumHeight(36)
        logo_browse = QPushButton("📁  Browse Logo")
        logo_browse.setStyleSheet(
            "background:transparent;color:#60a5fa;border:1px solid #30363d;"
            "border-radius:7px;padding:6px 14px;font-size:12px;")
        logo_browse.setMinimumHeight(36)
        logo_browse.clicked.connect(self._browse_logo)
        logo_row.addWidget(QLabel("School Logo:"))
        logo_row.addWidget(self.logo_preview_lbl, 1)
        logo_row.addWidget(logo_browse)
        sl.addLayout(logo_row)

        # Load existing logo
        self._logo_path = info.get("logo_path","") or ""
        if self._logo_path:
            import os
            self.logo_preview_lbl.setText(f"✅  {os.path.basename(self._logo_path)}")
            self.logo_preview_lbl.setStyleSheet(
                "color:#22c55e;font-size:12px;background:transparent;"
                "border:1px solid #22c55e44;border-radius:7px;padding:6px 12px;")

        save_info = QPushButton("💾 Save School Info & Refresh System")
        save_info.setObjectName("btn_add")
        save_info.setMinimumHeight(42)
        save_info.clicked.connect(self._save_school_info)
        sl.addWidget(save_info, 0, Qt.AlignLeft)
        sl.addStretch()
        tabs.addTab(school_tab, "🏫 School Info")

        # ── Themes ──────────────────────────────────────────────────────
        theme_tab = QWidget(); tl = QVBoxLayout(theme_tab)
        tl.addWidget(QLabel("Select Theme:"))
        if self.tm:
            themes = (self.tm.get_all_themes()
                    if hasattr(self.tm, "get_all_themes")
                    else self.tm.get_themes())
            for tid, tname in themes.items():
                btn = QPushButton(tname)
                btn.setMinimumHeight(44); btn.setMinimumWidth(200)
                btn.setStyleSheet("background:transparent;color:white;border:1px solid #30363d;"
                                "border-radius:8px;padding:10px;font-size:14px;")
                btn.clicked.connect(lambda ch, t=tid: self.tm.apply_theme(t))
                tl.addWidget(btn)
        tl.addStretch()
        tabs.addTab(theme_tab, "🎨 Themes")

        # ── Classes ─────────────────────────────────────────────────────
        class_tab = QWidget(); cl = QVBoxLayout(class_tab)
        add_class_row = QHBoxLayout()
        self.new_class_name  = QLineEdit(); self.new_class_name.setPlaceholderText("Class name"); self.new_class_name.setMinimumHeight(40)
        self.new_class_level = QSpinBox(); self.new_class_level.setRange(1, 20); self.new_class_level.setMinimumHeight(40)
        self.is_final        = QCheckBox("Final Class (no promotion)")
        add_btn = QPushButton("➕ Add Class"); add_btn.setObjectName("btn_add"); add_btn.clicked.connect(self._add_class)
        for w in [QLabel("Name:"), self.new_class_name, QLabel("Level:"), self.new_class_level, self.is_final, add_btn]:
            add_class_row.addWidget(w)
        add_class_row.addStretch(); cl.addLayout(add_class_row)
        self.class_table = QTableWidget(); self.class_table.setColumnCount(4)
        self.class_table.setHorizontalHeaderLabels(["Name", "Level", "Final Class", "Actions"])
        self.class_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.class_table.setAlternatingRowColors(True)
        cl.addWidget(self.class_table)
        self._load_classes()
        tabs.addTab(class_tab, "🏛 Classes")

        # ── Sections ────────────────────────────────────────────────────
        sec_tab = QWidget(); secl = QVBoxLayout(sec_tab)
        sec_add_row = QHBoxLayout()
        self.sec_class = QComboBox(); self.sec_class.setMinimumHeight(40)
        self.sec_class.addItem("Select Class")
        for c2 in self.db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.sec_class.addItem(c2['name'], c2['id'])
        self.sec_name = QLineEdit(); self.sec_name.setPlaceholderText("Section (e.g. A)"); self.sec_name.setMinimumHeight(40)
        self.sec_cap  = QSpinBox(); self.sec_cap.setRange(1,100); self.sec_cap.setValue(40); self.sec_cap.setMinimumHeight(40)
        add_sec = QPushButton("➕ Add Section"); add_sec.setObjectName("btn_add"); add_sec.clicked.connect(self._add_section)
        for w in [QLabel("Class:"), self.sec_class, QLabel("Section:"), self.sec_name, QLabel("Cap:"), self.sec_cap, add_sec]:
            sec_add_row.addWidget(w)
        sec_add_row.addStretch(); secl.addLayout(sec_add_row)
        self.sec_table = QTableWidget(); self.sec_table.setColumnCount(3)
        self.sec_table.setHorizontalHeaderLabels(["Class","Section","Capacity"])
        self.sec_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        secl.addWidget(self.sec_table)
        self._load_sections()
        tabs.addTab(sec_tab, "📐 Sections")

        # ── Subjects ────────────────────────────────────────────────────
        subj_tab = QWidget(); subjl = QVBoxLayout(subj_tab)
        subj_row = QHBoxLayout()
        self.subj_class = QComboBox(); self.subj_class.setMinimumHeight(40)
        self.subj_class.addItem("Select Class")
        for c2 in self.db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.subj_class.addItem(c2['name'], c2['id'])
        self.subj_name = QLineEdit(); self.subj_name.setPlaceholderText("Subject Name"); self.subj_name.setMinimumHeight(40)
        self.subj_code = QLineEdit(); self.subj_code.setPlaceholderText("Code"); self.subj_code.setMinimumHeight(40)
        add_subj = QPushButton("➕ Add Subject"); add_subj.setObjectName("btn_add"); add_subj.clicked.connect(self._add_subject)
        for w in [QLabel("Class:"),self.subj_class,QLabel("Name:"),self.subj_name,QLabel("Code:"),self.subj_code,add_subj]:
            subj_row.addWidget(w)
        subj_row.addStretch(); subjl.addLayout(subj_row)
        self.subj_table = QTableWidget(); self.subj_table.setColumnCount(3)
        self.subj_table.setHorizontalHeaderLabels(["Subject","Code","Class"])
        self.subj_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        subjl.addWidget(self.subj_table)
        self._load_subjects()
        tabs.addTab(subj_tab, "📚 Subjects")

        # ── Users ────────────────────────────────────────────────────────
        user_tab = QWidget(); ul = QVBoxLayout(user_tab)
        add_user_row = QHBoxLayout()
        self.u_uname = QLineEdit(); self.u_uname.setPlaceholderText("Username"); self.u_uname.setMinimumHeight(40)
        self.u_pass  = QLineEdit(); self.u_pass.setPlaceholderText("Password"); self.u_pass.setEchoMode(QLineEdit.Password); self.u_pass.setMinimumHeight(40)
        self.u_name  = QLineEdit(); self.u_name.setPlaceholderText("Full Name"); self.u_name.setMinimumHeight(40)
        self.u_role  = QComboBox(); self.u_role.setMinimumHeight(40)
        self.u_role.addItems(["teacher","accounts","admission","exam","staff"])
        add_u = QPushButton("➕ Add User"); add_u.setObjectName("btn_add"); add_u.clicked.connect(self._add_user)
        for w in [self.u_uname, self.u_pass, self.u_name, QLabel("Role:"), self.u_role, add_u]:
            add_user_row.addWidget(w)
        add_user_row.addStretch(); ul.addLayout(add_user_row)
        self.user_table = QTableWidget(); self.user_table.setColumnCount(5)
        self.user_table.setHorizontalHeaderLabels(["Username","Full Name","Role","Active","Actions"])
        self.user_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        ul.addWidget(self.user_table)
        self._load_users()
        tabs.addTab(user_tab, "👤 Users")

        # ── Sessions ────────────────────────────────────────────────────
        sess_tab = QWidget(); sessl = QVBoxLayout(sess_tab)
        sess_row = QHBoxLayout()
        self.sess_name  = QLineEdit(); self.sess_name.setPlaceholderText("Session Name e.g. 2025-26"); self.sess_name.setMinimumHeight(40)
        self.sess_start = QDateEdit(); self.sess_start.setCalendarPopup(True); self.sess_start.setMinimumHeight(40)
        self.sess_end   = QDateEdit(); self.sess_end.setCalendarPopup(True); self.sess_end.setMinimumHeight(40)
        add_sess = QPushButton("➕ Add Session"); add_sess.setObjectName("btn_add"); add_sess.clicked.connect(self._add_session)
        for w in [QLabel("Name:"),self.sess_name,QLabel("From:"),self.sess_start,QLabel("To:"),self.sess_end,add_sess]:
            sess_row.addWidget(w)
        sess_row.addStretch(); sessl.addLayout(sess_row)
        self.sess_table = QTableWidget(); self.sess_table.setColumnCount(4)
        self.sess_table.setHorizontalHeaderLabels(["Name","Start","End","Actions"])
        self.sess_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        sessl.addWidget(self.sess_table)
        self._load_sessions()
        tabs.addTab(sess_tab, "📅 Sessions")

        layout.addWidget(tabs)

    # ── School Info ───────────────────────────────────────────────────────
    def _browse_logo(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Logo", "",
                                               "Images (*.png *.jpg *.jpeg *.bmp *.svg)")
        if path:
            self._logo_path = path
            self.logo_preview_lbl.setText(f"✅  {os.path.basename(path)}")
            self.logo_preview_lbl.setStyleSheet(
                "color:#22c55e;font-size:12px;background:transparent;"
                "border:1px solid #22c55e44;border-radius:7px;padding:6px 12px;")

    def _save_school_info(self):
        name = self.s_name.text().strip()
        if not name:
            QMessageBox.warning(self, "Missing", "School Name is required."); return

        existing = self.db.fetchone("SELECT id FROM school_info WHERE id=1")
        data = (name, self.s_addr.text(), self.s_phone.text(), self.s_email.text(),
                self.s_website.text(), self._logo_path, self.s_bank.text(),
                self.s_bank_ac.text(), self.s_principal.text(),
                self.s_city.text(), self.s_motto.text())
        if existing:
            self.db.execute("""
                UPDATE school_info SET name=?,address=?,phone=?,email=?,website=?,
                logo_path=?,bank_name=?,bank_account=?,principal=?,city=?,motto=?,
                updated_at=CURRENT_TIMESTAMP WHERE id=1""", data)
        else:
            self.db.execute("""
                INSERT INTO school_info
                (name,address,phone,email,website,logo_path,bank_name,bank_account,
                principal,city,motto) VALUES (?,?,?,?,?,?,?,?,?,?,?)""", data)

        # ✅ Notify entire system
        SchoolContext.instance().refresh_and_notify(self.db)
        QMessageBox.information(self, "Saved",
            "School info saved!\nAll modules (sidebar, vouchers, ID cards, reports) updated.")

    def _load_form_from_db(self):
        info = self.db.fetchone("SELECT * FROM school_info WHERE id=1") or {}
        self.s_name.setText(info.get('name',''))
        self.s_addr.setText(info.get('address',''))
        self.s_phone.setText(info.get('phone',''))
        self.s_email.setText(info.get('email',''))
        self.s_principal.setText(info.get('principal',''))
        self.s_city.setText(info.get('city',''))
        self.s_motto.setText(info.get('motto',''))
        self.s_bank.setText(info.get('bank_name',''))
        self.s_bank_ac.setText(info.get('bank_account',''))
        self.s_website.setText(info.get('website',''))
        self._logo_path = info.get('logo_path','') or ''

    # ── Classes ──────────────────────────────────────────────────────────
    def _add_class(self):
        name = self.new_class_name.text().strip()
        if not name: return
        level = self.new_class_level.value()
        final = 1 if self.is_final.isChecked() else 0
        self.db.execute("INSERT OR IGNORE INTO classes (name,level,is_final_class) VALUES (?,?,?)",
                        (name, level, final))
        self.new_class_name.clear()
        self._load_classes()

    def _load_classes(self):
        rows = self.db.fetchall("SELECT * FROM classes ORDER BY level")
        self.class_table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            self.class_table.setItem(i, 0, QTableWidgetItem(r.get('name','')))
            self.class_table.setItem(i, 1, QTableWidgetItem(str(r.get('level',''))))
            self.class_table.setItem(i, 2, QTableWidgetItem("Yes" if r.get('is_final_class') else "No"))
            del_btn = QPushButton("🗑 Delete")
            del_btn.clicked.connect(lambda ch, rid=r['id']: self._del_class(rid))
            del_btn.setStyleSheet("background:#ef444422;color:#ef4444;border:none;border-radius:6px;padding:4px 8px;")
            self.class_table.setCellWidget(i, 3, del_btn)
        # Refresh any class-related comboboxes so new classes appear immediately
        try:
            classes = self.db.fetchall("SELECT id,name FROM classes ORDER BY level")
            if hasattr(self, 'sec_class'):
                self.sec_class.blockSignals(True)
                self.sec_class.clear()
                self.sec_class.addItem("Select Class")
                for c in classes:
                    self.sec_class.addItem(c['name'], c['id'])
                self.sec_class.blockSignals(False)
            if hasattr(self, 'subj_class'):
                self.subj_class.blockSignals(True)
                self.subj_class.clear()
                self.subj_class.addItem("Select Class")
                for c in classes:
                    self.subj_class.addItem(c['name'], c['id'])
                self.subj_class.blockSignals(False)
        except Exception:
            pass

    def _del_class(self, cid):
        if QMessageBox.question(self, "Delete", "Delete this class?",
                                QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes:
            self.db.execute("DELETE FROM classes WHERE id=?", (cid,))
            self._load_classes()

    # ── Sections ─────────────────────────────────────────────────────────
    def _add_section(self):
        cid = self.sec_class.currentData()
        name = self.sec_name.text().strip()
        if not cid or not name: return
        self.db.execute("INSERT OR IGNORE INTO sections (class_id,name,capacity) VALUES (?,?,?)",
                        (cid, name, self.sec_cap.value()))
        self.sec_name.clear()
        self._load_sections()

    def _load_sections(self):
        rows = self.db.fetchall("""SELECT s.*,c.name as cname FROM sections s
                                JOIN classes c ON s.class_id=c.id ORDER BY c.level""")
        self.sec_table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            self.sec_table.setItem(i, 0, QTableWidgetItem(r.get('cname','')))
            self.sec_table.setItem(i, 1, QTableWidgetItem(r.get('name','')))
            self.sec_table.setItem(i, 2, QTableWidgetItem(str(r.get('capacity',''))))

    # ── Subjects ─────────────────────────────────────────────────────────
    def _add_subject(self):
        cid  = self.subj_class.currentData()
        name = self.subj_name.text().strip()
        code = self.subj_code.text().strip()
        if not cid or not name: return
        self.db.execute("INSERT OR IGNORE INTO subjects (name,code,class_id) VALUES (?,?,?)",
                        (name, code, cid))
        self.subj_name.clear(); self.subj_code.clear()
        self._load_subjects()

    def _load_subjects(self):
        rows = self.db.fetchall("""SELECT s.*,c.name as cname FROM subjects s
                                JOIN classes c ON s.class_id=c.id ORDER BY c.level""")
        self.subj_table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            self.subj_table.setItem(i, 0, QTableWidgetItem(r.get('name','')))
            self.subj_table.setItem(i, 1, QTableWidgetItem(r.get('code','')))
            self.subj_table.setItem(i, 2, QTableWidgetItem(r.get('cname','')))

    # ── Users ─────────────────────────────────────────────────────────────
    def _add_user(self):
        uname = self.u_uname.text().strip()
        pwd   = self.u_pass.text().strip()
        fname = self.u_name.text().strip()
        role  = self.u_role.currentText()
        if not uname or not pwd:
            QMessageBox.warning(self, "Missing", "Username and password required.")
            return
        import hashlib
        ph = hashlib.sha256(pwd.encode()).hexdigest()
        try:
            self.db.execute("INSERT INTO users (username,password_hash,full_name,role) VALUES (?,?,?,?)",
                            (uname, ph, fname, role))
            self.u_uname.clear(); self.u_pass.clear(); self.u_name.clear()
            self._load_users()
            QMessageBox.information(self, "Done", f"User '{uname}' created.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not create user:\n{e}")

    def _load_users(self):
        rows = self.db.fetchall("SELECT * FROM users ORDER BY role,full_name")
        self.user_table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            self.user_table.setItem(i, 0, QTableWidgetItem(r.get('username','')))
            self.user_table.setItem(i, 1, QTableWidgetItem(r.get('full_name','')))
            self.user_table.setItem(i, 2, QTableWidgetItem(r.get('role','')))
            self.user_table.setItem(i, 3, QTableWidgetItem("✅" if r.get('is_active') else "❌"))
            del_btn = QPushButton("🗑")
            del_btn.setToolTip("Delete user")
            del_btn.clicked.connect(lambda ch, uid=r['id']: self._del_user(uid))
            del_btn.setStyleSheet("background:#ef444422;color:#ef4444;border:none;border-radius:6px;padding:4px;")
            self.user_table.setCellWidget(i, 4, del_btn)

    def _del_user(self, uid):
        if uid == self.user.get("id"):
            QMessageBox.warning(self, "Error", "You cannot delete your own account."); return
        if QMessageBox.question(self, "Delete", "Delete this user?",
                                QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes:
            self.db.execute("DELETE FROM users WHERE id=?", (uid,))
            self._load_users()

    # ── Sessions ─────────────────────────────────────────────────────────
    def _add_session(self):
        name = self.sess_name.text().strip()
        if not name: return
        sd = self.sess_start.date().toString("yyyy-MM-dd")
        ed = self.sess_end.date().toString("yyyy-MM-dd")
        self.db.execute("INSERT INTO academic_sessions (name,start_date,end_date) VALUES (?,?,?)",
                        (name, sd, ed))
        self.sess_name.clear()
        self._load_sessions()

    def _load_sessions(self):
        rows = self.db.fetchall("SELECT * FROM academic_sessions ORDER BY id DESC")
        self.sess_table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            self.sess_table.setItem(i, 0, QTableWidgetItem(r.get('name','')))
            self.sess_table.setItem(i, 1, QTableWidgetItem(r.get('start_date','')))
            self.sess_table.setItem(i, 2, QTableWidgetItem(r.get('end_date','')))
            act_btn = QPushButton("✅ Set Active")
            act_btn.clicked.connect(lambda ch, sid=r['id']: self._activate_session(sid))
            act_btn.setStyleSheet("background:#22c55e22;color:#22c55e;border:none;border-radius:6px;padding:4px 8px;")
            self.sess_table.setCellWidget(i, 3, act_btn)

    def _activate_session(self, sid):
        self.db.execute("UPDATE academic_sessions SET is_active=0")
        self.db.execute("UPDATE academic_sessions SET is_active=1 WHERE id=?", (sid,))
        self._load_sessions()
        QMessageBox.information(self, "Done", "Session activated.")
