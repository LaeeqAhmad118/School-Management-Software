"""Reports Module"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from ui.components.widgets import SectionHeader
from core.color_utils import rgba


class ReportsView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db = db; self.user = user
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20); layout.setSpacing(16)
        header = SectionHeader("Reports & Analytics", "Generate comprehensive reports")
        layout.addWidget(header)

        # FIX 2: Wrap grid in scroll area + set equal column stretch to prevent overlapping
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("border:none; background:transparent;")

        scroll_content = QWidget()
        scroll_content.setStyleSheet("background:transparent;")
        content_layout = QVBoxLayout(scroll_content)
        content_layout.setSpacing(16)
        content_layout.setContentsMargins(0, 0, 0, 0)

        grid = QGridLayout()
        grid.setSpacing(16)
        reports = [
            ("📊 Student Report", "Generate full student list with details", "#2563eb", self._student_report),
            ("💰 Fee Collection Report", "Monthly/yearly fee collection summary", "#22c55e", self._fee_report),
            ("✅ Attendance Report", "Class-wise attendance statistics", "#8b5cf6", self._attendance_report),
            ("🏆 Result Report", "Exam results and grade analysis", "#f59e0b", self._result_report),
            ("👥 Staff Report", "Employee details and salary summary", "#ef4444", self._staff_report),
            ("📈 Financial Summary", "Income, dues, and collection trends", "#10b981", self._financial_report),
        ]
        for i, (title, desc, color, fn) in enumerate(reports):
            card = self._report_card(title, desc, color, fn)
            grid.addWidget(card, i // 3, i % 3)

        for col in range(3):
            grid.setColumnStretch(col, 1)

        content_layout.addLayout(grid)
        content_layout.addStretch()
        scroll.setWidget(scroll_content)
        layout.addWidget(scroll, 1)

    def _report_card(self, title, desc, color, fn):
        f = QFrame()
        f.setMinimumHeight(160)
        f.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        f.setStyleSheet(f"""
            QFrame {{background:#1c2128;border:1px solid {rgba(color, '44')};border-radius:12px;padding:20px;}}
            QFrame:hover {{border:1px solid {color};}}
            QFrame QLabel {{background:transparent;border:none;}}
        """)
        l = QVBoxLayout(f)
        l.setContentsMargins(16, 16, 16, 16)
        l.setSpacing(8)
        t = QLabel(title); t.setStyleSheet("color:white;font-size:15px;font-weight:700;")
        t.setWordWrap(True)
        d = QLabel(desc); d.setStyleSheet("color:#8b949e;font-size:12px;"); d.setWordWrap(True)
        btn = QPushButton("Generate Report")
        btn.setStyleSheet(f"background:{color};color:white;border-radius:8px;padding:8px 16px;font-weight:600;margin-top:10px;")
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(fn)
        l.addWidget(t); l.addWidget(d); l.addStretch(); l.addWidget(btn)
        from ui.components.widgets import shadow
        shadow(f)
        return f

    def _student_report(self):
        rows = self.db.fetchall("""
            SELECT s.student_id,s.full_name,s.gender,c.name as class_name,
                   s.father_name,s.father_phone,s.status
            FROM students s LEFT JOIN classes c ON s.class_id=c.id
            ORDER BY c.name,s.roll_number
        """)
        self._show_report("Student Report", ["Std ID","Name","Gender","Class","Father","Phone","Status"], rows,
                          ["student_id","full_name","gender","class_name","father_name","father_phone","status"])

    def _fee_report(self):
        rows = self.db.fetchall("""
            SELECT v.voucher_id,s.full_name,c.name as class_name,
                   v.month,v.year,v.total_amount,v.paid_amount,
                   COALESCE(v.remaining_amount,v.total_amount-v.paid_amount) as remaining,
                   v.status
            FROM fee_vouchers v
            JOIN students s ON v.student_id=s.id
            LEFT JOIN classes c ON s.class_id=c.id
            ORDER BY v.id DESC LIMIT 500
        """)
        self._show_report("Fee Collection Report",
                          ["Voucher","Student","Class","Month","Year","Total","Paid","Remaining","Status"],
                          rows, ["voucher_id","full_name","class_name","month","year",
                                 "total_amount","paid_amount","remaining","status"])

    def _attendance_report(self):
        rows = self.db.fetchall("""
            SELECT s.full_name, c.name as class_name,
                   SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) as present,
                   SUM(CASE WHEN a.status='absent' THEN 1 ELSE 0 END) as absent,
                   COUNT(a.id) as total
            FROM students s
            LEFT JOIN attendance a ON s.id=a.student_id
            LEFT JOIN classes c ON s.class_id=c.id
            GROUP BY s.id ORDER BY c.name,s.full_name
        """)
        self._show_report("Attendance Report",
                          ["Student","Class","Present","Absent","Total Days"],
                          rows, ["full_name","class_name","present","absent","total"])

    def _result_report(self):
        rows = self.db.fetchall("""
            SELECT s.full_name,c.name as class_name,e.name as exam_name,
                   sub.name as subject,r.obtained_marks,r.total_marks
            FROM results r
            JOIN students s ON r.student_id=s.id
            JOIN exams e ON r.exam_id=e.id
            JOIN subjects sub ON r.subject_id=sub.id
            LEFT JOIN classes c ON s.class_id=c.id
            ORDER BY e.name,s.full_name
        """)
        self._show_report("Result Report",
                          ["Student","Class","Exam","Subject","Obtained","Total"],
                          rows, ["full_name","class_name","exam_name","subject","obtained_marks","total_marks"])

    def _staff_report(self):
        rows = self.db.fetchall("SELECT employee_id,full_name,designation,department,phone,salary,status FROM staff ORDER BY full_name")
        self._show_report("Staff Report",
                          ["Emp ID","Name","Designation","Department","Phone","Salary","Status"],
                          rows, ["employee_id","full_name","designation","department","phone","salary","status"])

    def _financial_report(self):
        summary = self.db.fetchone("""
            SELECT
                SUM(total_amount) as total_due,
                SUM(paid_amount) as total_collected,
                SUM(CASE WHEN status='paid' THEN total_amount ELSE 0 END) as fully_paid,
                SUM(CASE WHEN status='overdue' THEN remaining_amount ELSE 0 END) as overdue_amount,
                COUNT(CASE WHEN status='pending' THEN 1 END) as pending_count,
                COUNT(CASE WHEN status='paid' THEN 1 END) as paid_count
            FROM fee_vouchers
        """)
        msg = f"""
<b>Financial Summary</b><br><br>
<b>Total Fee Due:</b> Rs.{summary.get('total_due',0) or 0:,.0f}<br>
<b>Total Collected:</b> Rs.{summary.get('total_collected',0) or 0:,.0f}<br>
<b>Fully Paid Vouchers:</b> {summary.get('paid_count',0) or 0}<br>
<b>Pending Vouchers:</b> {summary.get('pending_count',0) or 0}<br>
<b>Overdue Amount:</b> Rs.{summary.get('overdue_amount',0) or 0:,.0f}<br>
"""
        QMessageBox.information(self, "Financial Summary", msg)

    def _show_report(self, title, headers, rows, keys):
        dlg = QDialog(self)
        dlg.setWindowTitle(title)
        dlg.setMinimumSize(900, 600)
        layout = QVBoxLayout(dlg)

        export_btn = QPushButton("📤 Export to Excel")
        export_btn.setStyleSheet("background:#f97316;color:white;border-radius:8px;padding:8px 16px;font-weight:600;")
        export_btn.clicked.connect(lambda: self._export_excel(title, headers, rows, keys))
        layout.addWidget(export_btn, 0, Qt.AlignRight)

        table = QTableWidget(len(rows), len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        table.setAlternatingRowColors(True)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for ri, r in enumerate(rows):
            for ci, key in enumerate(keys):
                val = r.get(key, '')
                if isinstance(val, float):
                    val = f"{val:,.0f}"
                table.setItem(ri, ci, QTableWidgetItem(str(val) if val is not None else ''))
            table.setRowHeight(ri, 36)
        layout.addWidget(table)
        close = QPushButton("Close"); close.setObjectName("btn_cancel"); close.clicked.connect(dlg.accept)
        layout.addWidget(close, 0, Qt.AlignRight)
        dlg.exec()

    def _export_excel(self, title, headers, rows, keys):
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
            path, _ = QFileDialog.getSaveFileName(self, "Save Excel", f"{title}.xlsx", "Excel Files (*.xlsx)")
            if not path: return
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = title[:31]
            for ci, h in enumerate(headers, 1):
                cell = ws.cell(1, ci, h)
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="2563EB")
                cell.alignment = Alignment(horizontal="center")
            for ri, r in enumerate(rows, 2):
                for ci, key in enumerate(keys, 1):
                    ws.cell(ri, ci, r.get(key, ''))
            wb.save(path)
            QMessageBox.information(self, "Exported", f"Report saved to:\n{path}")
        except ImportError:
            QMessageBox.warning(self, "Missing Library", "openpyxl not installed. Run: pip install openpyxl")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
