"""Results V2 — Bulk result cards & ID cards with school info, QR, direct print"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from ui.components.widgets import SectionHeader, ModernTable
from core.school_context import SchoolContext


class ResultsView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db = db; self.user = user
        self._init_ui()

    def on_school_updated(self, info):
        pass  # PDF generator picks up fresh info at print time

    def refresh(self):
        """Repopulate Exam/Class dropdowns — called every time this screen
        is navigated to, so an exam created after this view was first
        built (it's cached, not recreated) still shows up here without
        needing an app restart."""
        prev_exam = self.exam_combo.currentData()
        prev_class = self.class_combo.currentData() if self.class_combo.currentIndex() > 0 else None

        self.exam_combo.blockSignals(True)
        self.exam_combo.clear()
        self.exam_combo.addItem("Select Exam", None)
        for e in self.db.fetchall("SELECT id,name FROM exams ORDER BY id DESC"):
            self.exam_combo.addItem(e['name'], e['id'])
        if prev_exam:
            idx = self.exam_combo.findData(prev_exam)
            if idx >= 0:
                self.exam_combo.setCurrentIndex(idx)
        self.exam_combo.blockSignals(False)

        self.class_combo.blockSignals(True)
        self.class_combo.clear()
        self.class_combo.addItem("All Classes", None)
        for c in self.db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_combo.addItem(c['name'], c['id'])
        if prev_class:
            idx = self.class_combo.findData(prev_class)
            if idx >= 0:
                self.class_combo.setCurrentIndex(idx)
        self.class_combo.blockSignals(False)

        if self.exam_combo.currentData():
            self._load_results()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20); layout.setSpacing(16)
        header = SectionHeader("Results", "Enter and manage exam results")

        btn_enter  = header.add_button("Enter Marks", "btn_add", "✏️")
        btn_enter.clicked.connect(self._enter_marks)

        btn_result = header.add_button("Bulk Result Cards", "btn_primary", "🖨")
        btn_result.setStyleSheet("background:#8b5cf6;color:white;border-radius:8px;padding:8px 14px;font-weight:600;")
        btn_result.clicked.connect(self._bulk_result_cards)

        btn_id = header.add_button("Bulk ID Cards", "btn_primary", "🪪")
        btn_id.setStyleSheet("background:#f97316;color:white;border-radius:8px;padding:8px 14px;font-weight:600;")
        btn_id.clicked.connect(self._bulk_id_cards)
        layout.addWidget(header)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Exam:"))
        self.exam_combo = QComboBox(); self.exam_combo.setMinimumHeight(40)
        self.exam_combo.addItem("Select Exam")
        for e in self.db.fetchall("SELECT id,name FROM exams ORDER BY id DESC"):
            self.exam_combo.addItem(e['name'], e['id'])
        ctrl.addWidget(self.exam_combo)

        ctrl.addWidget(QLabel("Class:"))
        self.class_combo = QComboBox(); self.class_combo.setMinimumHeight(40)
        self.class_combo.addItem("All Classes")
        for c in self.db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_combo.addItem(c['name'], c['id'])
        ctrl.addWidget(self.class_combo)

        load = QPushButton("Load Results")
        load.setStyleSheet("background:#2563eb;color:white;border-radius:8px;padding:8px 16px;font-weight:600;")
        load.clicked.connect(self._load_results)
        ctrl.addWidget(load); ctrl.addStretch()
        layout.addLayout(ctrl)

        self.table = ModernTable(["Student","Roll No","Subject","Obtained","Total","Grade","%","Remarks"])
        self.table.set_fixed_column(1, 90)
        self.table.set_fixed_column(3, 90)
        self.table.set_fixed_column(4, 80)
        self.table.set_fixed_column(5, 70)
        self.table.set_fixed_column(6, 80)
        layout.addWidget(self.table)

    def _load_results(self):
        self.table.clear_rows()
        eid = self.exam_combo.currentData()
        cid = self.class_combo.currentData() if self.class_combo.currentIndex() > 0 else None
        if not eid: return
        q = """SELECT r.*, s.full_name, s.roll_number, sub.name as subject_name
               FROM results r
               JOIN students s ON r.student_id=s.id
               JOIN subjects sub ON r.subject_id=sub.id
               WHERE r.exam_id=?"""
        params = [eid]
        if cid:
            q += " AND s.class_id=?"; params.append(cid)
        q += " ORDER BY s.full_name, sub.name"
        for r in self.db.fetchall(q, params):
            pct   = (r.get('obtained_marks',0) / r.get('total_marks',1) * 100) if r.get('total_marks') else 0
            grade = self._grade(pct)
            self.table.add_row([
                r.get('full_name',''),
                r.get('roll_number',''),
                r.get('subject_name',''),
                r.get('obtained_marks',''),
                r.get('total_marks',''),
                grade,
                f"{pct:.1f}%",
                r.get('remarks','')
            ])

    def _grade(self, pct):
        if pct >= 90: return "A+"
        if pct >= 80: return "A"
        if pct >= 70: return "B"
        if pct >= 60: return "C"
        if pct >= 50: return "D"
        return "F"

    def _enter_marks(self):
        dlg = EnterMarksDialog(self.db, self)
        if dlg.exec() == QDialog.Accepted:
            self._load_results()

    def _bulk_result_cards(self):
        eid = self.exam_combo.currentData()
        if not eid:
            QMessageBox.warning(self, "Select Exam", "Please select an exam first.")
            return
        cid = self.class_combo.currentData() if self.class_combo.currentIndex() > 0 else None

        reply = QMessageBox.question(self, "Bulk Result Cards",
            "Generate result cards for all students in selection?\n"
            "You can choose to send directly to printer.",
            QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            return

        print_direct = QMessageBox.question(self, "Print?",
            "Send directly to printer? (No = save PDF only)",
            QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes

        school_info = self.db.fetchone("SELECT * FROM school_info WHERE id=1") or {}
        exam_info   = self.db.fetchone("SELECT * FROM exams WHERE id=?", (eid,)) or {}

        q = "SELECT DISTINCT r.student_id FROM results r JOIN students s ON r.student_id=s.id WHERE r.exam_id=?"
        params = [eid]
        if cid:
            q += " AND s.class_id=?"; params.append(cid)
        student_ids = [row['student_id'] for row in self.db.fetchall(q, params)]

        if not student_ids:
            QMessageBox.information(self, "No Results", "No results found for selection.")
            return

        progress = QProgressDialog(f"Generating {len(student_ids)} result cards...", "Cancel", 0, len(student_ids), self)
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        data = []
        for i, sid in enumerate(student_ids):
            if progress.wasCanceled(): break
            progress.setValue(i)
            stu = self.db.fetchone("""
                SELECT s.*, c.name as class_name, sec.name as section_name
                FROM students s
                LEFT JOIN classes c ON s.class_id=c.id
                LEFT JOIN sections sec ON s.section_id=sec.id
                WHERE s.id=?
            """, (sid,))
            results = self.db.fetchall("""
                SELECT r.*, sub.name as subject_name
                FROM results r JOIN subjects sub ON r.subject_id=sub.id
                WHERE r.student_id=? AND r.exam_id=?
            """, (sid, eid))
            if stu and results:
                data.append((stu, results, exam_info))

        progress.close()

        try:
            from utils.pdf_generator import bulk_result_cards
            paths = bulk_result_cards(data, school_info, auto_print=print_direct)
            QMessageBox.information(self, "Done",
                f"Generated {len(paths)} result card(s).\n"
                f"{'Sent to printer.' if print_direct else 'Saved to exports folder.'}")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def _bulk_id_cards(self):
        cid = self.class_combo.currentData() if self.class_combo.currentIndex() > 0 else None
        reply = QMessageBox.question(self, "Bulk ID Cards",
            "Generate ID cards (4 per page, double-sided) for selected class?\n"
            "You can choose to send directly to printer.",
            QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            return

        print_direct = QMessageBox.question(self, "Print?",
            "Send directly to printer?",
            QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes

        school_info = self.db.fetchone("SELECT * FROM school_info WHERE id=1") or {}

        q = """SELECT s.*, c.name as class_name, sec.name as section_name,
                    sess.name as session_name
            FROM students s
            LEFT JOIN classes c ON s.class_id=c.id
            LEFT JOIN sections sec ON s.section_id=sec.id
            LEFT JOIN academic_sessions sess ON s.session_id=sess.id
            WHERE s.status='active'"""
        params = []
        if cid:
            q += " AND s.class_id=?"; params.append(cid)
        q += " ORDER BY c.level, s.full_name"

        students = self.db.fetchall(q, params)
        if not students:
            QMessageBox.information(self, "No Students", "No active students found.")
            return

        try:
            from utils.pdf_generator import generate_id_cards
            path = generate_id_cards(students, school_info, auto_print=print_direct)
            QMessageBox.information(self, "Done",
                f"Generated ID cards for {len(students)} student(s).\n"
                f"{'Sent to printer.' if print_direct else f'Saved: {path}'}")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


class EnterMarksDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Enter Marks")
        self.setMinimumSize(600, 480)
        layout = QVBoxLayout(self)

        ctrl = QHBoxLayout()
        self.exam_cb = QComboBox(); self.exam_cb.setMinimumHeight(38)
        self.exam_cb.addItem("Select Exam")
        for e in db.fetchall("SELECT id,name FROM exams ORDER BY id DESC"):
            self.exam_cb.addItem(e['name'], e['id'])
        
        self.class_cb = QComboBox(); self.class_cb.setMinimumHeight(38)
        self.class_cb.addItem("Select Class")
        for c in db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_cb.addItem(c['name'], c['id'])
        
        self.subj_cb = QComboBox(); self.subj_cb.setMinimumHeight(38)
        self.subj_cb.addItem("Select Subject")
        
        # Connect signals AFTER populating to avoid triggering during init
        self.exam_cb.currentIndexChanged.connect(self._reload_subjects)
        self.class_cb.currentIndexChanged.connect(self._reload_subjects)
        
        load_btn = QPushButton("Load Students")
        load_btn.setStyleSheet("background:#2563eb;color:white;border-radius:8px;padding:8px 14px;")
        load_btn.clicked.connect(self._load_students)
        ctrl.addWidget(QLabel("Exam:")); ctrl.addWidget(self.exam_cb)
        ctrl.addWidget(QLabel("Class:")); ctrl.addWidget(self.class_cb)
        ctrl.addWidget(QLabel("Subject:")); ctrl.addWidget(self.subj_cb)
        ctrl.addWidget(load_btn)
        layout.addLayout(ctrl)

        self.marks_table = QTableWidget()
        self.marks_table.setColumnCount(4)
        self.marks_table.setHorizontalHeaderLabels(["Student","Roll No","Total Marks","Obtained Marks"])
        self.marks_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.marks_table.setSelectionBehavior(QTableWidget.SelectRows)
        
        # Style the header - Obtained Marks stands out
        header = self.marks_table.horizontalHeader()
        header.setStyleSheet("""
            QHeaderView::section {
                background-color: #1f2937;
                color: white;
                padding: 5px;
                font-weight: bold;
            }
            QHeaderView::section:nth-child(4) {
                background-color: #dc2626;
                color: white;
                font-weight: bold;
                font-size: 12px;
            }
        """)
        layout.addWidget(self.marks_table)

        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        btns.accepted.connect(self._save)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _reload_subjects(self):
        self.subj_cb.blockSignals(True)
        self.subj_cb.clear()
        self.subj_cb.addItem("Select Subject")

        cid = self.class_cb.currentData()
        
        # If no class selected, can't load subjects
        if not cid:
            self.subj_cb.blockSignals(False)
            return
        
        # Load ALL subjects for this class (don't filter by exam yet)
        # Validation of exam linkage happens when saving
        query = "SELECT s.id, s.name FROM subjects s WHERE s.class_id=? ORDER BY s.name"
        
        subjects = self.db.fetchall(query, (cid,))
        
        for s in subjects:
            self.subj_cb.addItem(s['name'], s['id'])

        self.subj_cb.blockSignals(False)

    def _load_students(self):
        cid  = self.class_cb.currentData()
        eid  = self.exam_cb.currentData()
        sid  = self.subj_cb.currentData()

        self._student_ids = []
        self.marks_table.setRowCount(0)

        if not cid or not eid or not sid:
            missing = []
            if not eid: missing.append("Exam")
            if not cid: missing.append("Class")
            if not sid: missing.append("Subject")
            QMessageBox.warning(self, "Missing Selection", f"Please select: {', '.join(missing)}")
            return

        valid_subject = self.db.fetchone(
            "SELECT id FROM subjects WHERE id=? AND class_id=?",
            (sid, cid)
        )
        if not valid_subject:
            QMessageBox.warning(self, "Invalid Subject",
                                "The selected subject does not belong to the chosen class.")
            return

        valid_exam_subject = self.db.fetchone(
            "SELECT 1 FROM exam_subjects WHERE exam_id=? AND subject_id=?",
            (eid, sid)
        )
        if not valid_exam_subject:
            QMessageBox.warning(self, "Invalid Subject",
                                "The selected subject is not assigned to this exam.")
            return

        students = self.db.fetchall(
            "SELECT * FROM students WHERE class_id=? AND status='active' ORDER BY roll_number,full_name",
            (cid,))
        
        if not students:
            QMessageBox.information(self, "No Students", 
                f"No active students found in the selected class.\n\n"
                f"Class ID: {cid}\n"
                f"Make sure students are enrolled and marked as 'active'.")
            return
            
        self.marks_table.setRowCount(len(students))
        for i, s in enumerate(students):
            self._student_ids.append(s['id'])
            self.marks_table.setItem(i, 0, QTableWidgetItem(s.get('full_name','')))
            self.marks_table.setItem(i, 1, QTableWidgetItem(s.get('roll_number','') or ''))
            total_item = QTableWidgetItem("100")
            obt_item   = QTableWidgetItem("")
            
            # Style the Obtained Marks field for MAXIMUM visibility
            # White background with black text - crystal clear
            obt_item.setBackground(QColor("#ffffff"))  # Bright white background
            obt_item.setForeground(QColor("#000000"))  # Black text
            font = obt_item.font()
            font.setBold(True)
            font.setPointSize(11)
            obt_item.setFont(font)
            
            # Style Total Marks for consistency
            total_item.setBackground(QColor("#f3f4f6"))  # Light gray
            total_item.setForeground(QColor("#1f2937"))  # Dark gray text
            
            self.marks_table.setItem(i, 2, total_item)
            self.marks_table.setItem(i, 3, obt_item)
            self.marks_table.setRowHeight(i, 40)

    def _save(self):
        eid  = self.exam_cb.currentData()
        subj = self.subj_cb.currentData()
        if not eid or not subj:
            QMessageBox.warning(self,"Missing","Select exam and subject."); return
        saved = 0
        for row in range(self.marks_table.rowCount()):
            sid_idx = row
            if sid_idx >= len(self._student_ids): continue
            sid   = self._student_ids[sid_idx]
            total_item = self.marks_table.item(row, 2)
            obt_item   = self.marks_table.item(row, 3)
            if not obt_item or not obt_item.text().strip(): continue
            try:
                total = float(total_item.text() or "100")
                obt   = float(obt_item.text())
                pct   = obt/total*100 if total else 0
                grade_map = [(90,"A+"),(80,"A"),(70,"B"),(60,"C"),(50,"D")]
                grade = next((g for t,g in grade_map if pct>=t), "F")
                self.db.execute("""
                    INSERT OR REPLACE INTO results
                    (student_id,exam_id,subject_id,obtained_marks,total_marks,grade)
                    VALUES (?,?,?,?,?,?)
                """, (sid, eid, subj, obt, total, grade))
                saved += 1
            except ValueError:
                pass
        QMessageBox.information(self,"Saved", f"Marks saved for {saved} students.")
        self.accept()
