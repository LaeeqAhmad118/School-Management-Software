"""Timetable V2 — shows Subject + Teacher, printable with school/class info.
Includes: configurable Recess period (inserted between two teaching periods)
and a Friday Half-Day mode where Friday ends early with NO recess.
"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from ui.components.widgets import SectionHeader
from core.school_context import SchoolContext

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]


class TimetableView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db = db; self.user = user
        self._load_recess_config()
        self._init_ui()

    def on_school_updated(self, info):
        pass   # nothing to reload in view; PDF generator picks up fresh info

    def refresh(self):
        """Repopulate the Class dropdown so classes added elsewhere show up
        without needing an app restart."""
        prev = self.class_combo.currentData()
        self.class_combo.blockSignals(True)
        self.class_combo.clear()
        self.class_combo.addItem("Select Class", None)
        for c in self.db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_combo.addItem(c['name'], c['id'])
        if prev:
            idx = self.class_combo.findData(prev)
            if idx >= 0:
                self.class_combo.setCurrentIndex(idx)
        self.class_combo.blockSignals(False)

    # ── Recess / Friday half-day configuration (stored in app_config) ──────
    def _load_recess_config(self):
        self.recess_after   = int(self.db.get_config("tt_recess_after_period", "4") or 4)
        self.recess_start   = self.db.get_config("tt_recess_start", "11:00 AM") or "11:00 AM"
        self.recess_end     = self.db.get_config("tt_recess_end", "11:20 AM") or "11:20 AM"
        self.friday_periods = int(self.db.get_config("tt_friday_last_period", "4") or 4)

    def _save_recess_config(self):
        self.db.set_config("tt_recess_after_period", str(self.recess_after))
        self.db.set_config("tt_recess_start", self.recess_start)
        self.db.set_config("tt_recess_end", self.recess_end)
        self.db.set_config("tt_friday_last_period", str(self.friday_periods))

    def _open_recess_settings(self):
        dlg = RecessSettingsDialog(self, self.recess_after, self.recess_start,
                                    self.recess_end, self.friday_periods)
        if dlg.exec() == QDialog.Accepted:
            self.recess_after, self.recess_start, self.recess_end, self.friday_periods = dlg.values()
            self._save_recess_config()
            self._rebuild_grid()
            self._load_timetable()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20); layout.setSpacing(16)
        header = SectionHeader("Timetable", "Manage class and teacher schedules")
        btn_add = header.add_button("Add Entry", "btn_add", "➕")
        btn_add.clicked.connect(self._add_entry)
        btn_ai = header.add_button("AI Generate", "btn_primary", "🤖")
        btn_ai.setStyleSheet("background:#8b5cf6;color:white;border-radius:8px;padding:8px 14px;font-weight:600;")
        btn_ai.clicked.connect(self._ai_generate_timetable)
        btn_recess = header.add_button("Recess / Friday Settings", "btn_primary", "🍽️")
        btn_recess.setStyleSheet("background:#d97706;color:white;border-radius:8px;padding:8px 14px;font-weight:600;")
        btn_recess.clicked.connect(self._open_recess_settings)
        btn_print = header.add_button("Print Timetable", "btn_primary", "🖨")
        btn_print.setStyleSheet("background:#059669;color:white;border-radius:8px;padding:8px 14px;font-weight:600;")
        btn_print.clicked.connect(self._print_timetable)
        layout.addWidget(header)

        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("Class:"))
        self.class_combo = QComboBox(); self.class_combo.setMinimumHeight(40)
        self.class_combo.addItem("Select Class")
        for c in self.db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_combo.addItem(c['name'], c['id'])
        self.class_combo.currentIndexChanged.connect(self._load_timetable)
        ctrl.addWidget(self.class_combo)

        ctrl.addWidget(QLabel("Section:"))
        self.section_combo = QComboBox(); self.section_combo.setMinimumHeight(40)
        self.section_combo.addItem("All Sections", 0)
        ctrl.addWidget(self.section_combo)
        self.class_combo.currentIndexChanged.connect(self._reload_sections)

        ctrl.addStretch()

        self.lbl_recess_info = QLabel()
        self.lbl_recess_info.setStyleSheet(
            "color:#d97706;font-size:11px;font-weight:700;background:#d9770622;"
            "padding:6px 12px;border-radius:8px;border:1px solid #d9770655;")
        ctrl.addWidget(self.lbl_recess_info)
        self._refresh_recess_label()

        clear_btn = QPushButton("🗑 Clear Class Timetable")
        clear_btn.setStyleSheet("background:#ef444422;color:#ef4444;border:1px solid #ef444444;border-radius:8px;padding:8px 14px;")
        clear_btn.clicked.connect(self._clear_timetable)
        ctrl.addWidget(clear_btn)
        layout.addLayout(ctrl)

        self.grid = QTableWidget()
        self.grid.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.grid.setAlternatingRowColors(True)
        self.grid.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.grid.setMinimumHeight(420)
        self.grid.setStyleSheet("""
            QTableWidget { gridline-color: #30363d; border:1px solid #30363d; border-radius:8px; }
            QHeaderView::section { background:#161b22; color:#e6edf3;
                font-weight:700; padding:6px; border:1px solid #30363d; }
        """)
        layout.addWidget(self.grid)
        self._rebuild_grid()

    def _refresh_recess_label(self):
        self.lbl_recess_info.setText(
            f"🍽️ Recess after Period {self.recess_after}  ({self.recess_start}–{self.recess_end})   "
            f"•   📅 Friday is a Half Day — ends after Period {self.friday_periods}, no recess")

    # ── Grid / row-mapping helpers ──────────────────────────────────────────
    def _n_periods(self) -> int:
        return 8

    def _row_for_period(self, period: int) -> int:
        """Map a real teaching period number (1..8) to its visual grid row,
        accounting for the inserted recess row."""
        row = period - 1
        if period > self.recess_after:
            row += 1
        return row

    def _rebuild_grid(self):
        """Build the visual grid: teaching-period rows + one inserted Recess row."""
        n_periods = self._n_periods()
        total_rows = n_periods + 1  # +1 for the recess row
        self.grid.clear()
        self.grid.setRowCount(total_rows)
        self.grid.setColumnCount(len(DAYS))
        self.grid.setHorizontalHeaderLabels(DAYS)

        row_labels = []
        for p in range(1, n_periods + 1):
            row_labels.append(f"Period {p}")
            if p == self.recess_after:
                row_labels.append("RECESS")
        self.grid.setVerticalHeaderLabels(row_labels)
        self.grid.verticalHeader().setDefaultSectionSize(60)

        recess_row = self.recess_after  # row index of the inserted recess row (0-based)
        for r in range(total_rows):
            for c in range(len(DAYS)):
                day = DAYS[c]
                item = QTableWidgetItem("")
                item.setTextAlignment(Qt.AlignCenter)
                if r == recess_row:
                    if day == "Friday":
                        item.setText("— Half Day —\nNo Recess")
                        item.setBackground(QColor("#374151"))
                        item.setForeground(QColor("#9ca3af"))
                    else:
                        item.setText(f"🍽️ RECESS\n{self.recess_start} – {self.recess_end}")
                        item.setBackground(QColor("#d97706"))
                        item.setForeground(QColor("#111827"))
                    font = item.font(); font.setBold(True); item.setFont(font)
                self.grid.setItem(r, c, item)

        # Grey-out Friday periods beyond the half-day cut-off
        for p in range(self.friday_periods + 1, n_periods + 1):
            row = self._row_for_period(p)
            col = DAYS.index("Friday")
            it = self.grid.item(row, col)
            if it is None:
                it = QTableWidgetItem(""); self.grid.setItem(row, col, it)
            it.setText("— School Off —\n(Half Day)")
            it.setTextAlignment(Qt.AlignCenter)
            it.setBackground(QColor("#1f2937"))
            it.setForeground(QColor("#6b7280"))

        self.grid.resizeRowsToContents()

    def _reload_sections(self):
        self.section_combo.clear()
        self.section_combo.addItem("All Sections", 0)
        cid = self.class_combo.currentData()
        if cid:
            for s in self.db.fetchall("SELECT id,name FROM sections WHERE class_id=?", (cid,)):
                self.section_combo.addItem(s['name'], s['id'])

    def _load_timetable(self):
        cid = self.class_combo.currentData()
        self._rebuild_grid()   # resets grid incl. recess row + Friday half-day styling
        if not cid:
            return

        rows = self.db.fetchall("""
            SELECT t.*, sub.name as subject_name,
                   COALESCE(st.full_name, '') as teacher_name,
                   t.start_time, t.end_time, t.room
            FROM timetable t
            JOIN subjects sub ON t.subject_id=sub.id
            LEFT JOIN staff st ON t.teacher_id=st.id
            WHERE t.class_id=?
        """, (cid,))

        COLORS = ["#1e3a8a","#065f46","#7c2d12","#5b21b6","#92400e","#1e40af"]
        subj_colors = {}
        color_idx   = 0

        for r in rows:
            day_idx    = DAYS.index(r['day']) if r['day'] in DAYS else -1
            period     = r['period'] or 1
            # Skip Friday periods beyond the configured half-day cut-off —
            # that cell is already styled "School Off" by _rebuild_grid.
            if r['day'] == "Friday" and period > self.friday_periods:
                continue
            row_idx = self._row_for_period(period)
            if 0 <= day_idx < len(DAYS) and 0 <= row_idx < self.grid.rowCount():
                subj = r.get('subject_name','')
                teacher = r.get('teacher_name','')
                time_s  = r.get('start_time','')
                time_e  = r.get('end_time','')
                room    = r.get('room','')
                time_str = f"{time_s}–{time_e}" if time_s and time_e else ""
                text = subj
                if teacher: text += f"\n👤 {teacher}"
                if time_str: text += f"\n🕐 {time_str}"
                if room: text += f"  📍{room}"

                item = QTableWidgetItem(text)
                item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)

                if subj not in subj_colors:
                    subj_colors[subj] = COLORS[color_idx % len(COLORS)]
                    color_idx += 1
                bg = QColor(subj_colors[subj])
                bg.setAlpha(60)
                item.setBackground(bg)
                self.grid.setItem(row_idx, day_idx, item)

    def _print_timetable(self):
        cid = self.class_combo.currentData()
        if not cid:
            QMessageBox.warning(self, "Select Class", "Please select a class first.")
            return
        class_row = self.db.fetchone("SELECT * FROM classes WHERE id=?", (cid,))
        if not class_row:
            return

        # Fetch timetable with teacher names
        rows = self.db.fetchall("""
            SELECT t.*, sub.name as subject_name,
                   COALESCE(st.full_name,'') as teacher_name,
                   t.start_time, t.end_time, t.room, t.day, t.period
            FROM timetable t
            JOIN subjects sub ON t.subject_id=sub.id
            LEFT JOIN staff st ON t.teacher_id=st.id
            WHERE t.class_id=?
        """, (cid,))

        # Get active session
        sess = self.db.fetchone("SELECT name FROM academic_sessions WHERE is_active=1")
        sec_id = self.section_combo.currentData()
        sec_name = ""
        if sec_id:
            s = self.db.fetchone("SELECT name FROM sections WHERE id=?", (sec_id,))
            if s: sec_name = s.get('name','')

        class_info = dict(class_row)
        class_info['section_name'] = sec_name
        class_info['session_name'] = sess.get('name','') if sess else ''

        school_info = self.db.fetchone("SELECT * FROM school_info WHERE id=1") or {}

        try:
            from utils.pdf_generator import generate_timetable
            recess_info = {
                "recess_after": self.recess_after,
                "recess_start": self.recess_start,
                "recess_end": self.recess_end,
                "friday_periods": self.friday_periods,
            }
            generate_timetable(class_info, rows, school_info, recess_info=recess_info)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not generate timetable:\n{e}")

    def _add_entry(self):
        dlg = TimetableEntryDialog(self.db, self, friday_periods=self.friday_periods)
        if dlg.exec() == QDialog.Accepted:
            self._load_timetable()

    def _clear_timetable(self):
        cid = self.class_combo.currentData()
        if not cid:
            QMessageBox.warning(self, "Select Class", "Please select a class first.")
            return
        if QMessageBox.question(self, "Confirm", "Clear entire timetable for this class?",
                                QMessageBox.Yes|QMessageBox.No) == QMessageBox.Yes:
            self.db.execute("DELETE FROM timetable WHERE class_id=?", (cid,))
            self._load_timetable()

    def _ai_generate_timetable(self):
        cid = self.class_combo.currentData()
        if not cid:
            QMessageBox.warning(self, "Select Class", "Select a class first."); return
        subjects = self.db.fetchall("SELECT * FROM subjects WHERE class_id=?", (cid,))
        if not subjects:
            QMessageBox.information(self, "No Subjects", "Add subjects for this class in Settings first.")
            return
        self.db.execute("DELETE FROM timetable WHERE class_id=?", (cid,))
        sub_cycle = subjects * 10
        idx = 0
        for day in DAYS:
            last_period = self.friday_periods if day == "Friday" else self._n_periods()
            for period in range(1, last_period + 1):
                sub = sub_cycle[idx % len(sub_cycle)]; idx += 1
                self.db.execute("""INSERT OR IGNORE INTO timetable
                    (class_id,section_id,subject_id,day,period)
                    VALUES (?,0,?,?,?)""", (cid, sub['id'], day, period))
        self._load_timetable()
        QMessageBox.information(self, "Generated",
            f"AI Timetable generated successfully!\n\n"
            f"🍽️ Recess after Period {self.recess_after} ({self.recess_start}–{self.recess_end})\n"
            f"📅 Friday is a half day — ends after Period {self.friday_periods}, with no recess.")


class TimetableEntryDialog(QDialog):
    def __init__(self, db, parent=None, friday_periods=4):
        super().__init__(parent)
        self.db = db
        self.friday_periods = friday_periods
        self.setWindowTitle("Add Timetable Entry")
        self.setMinimumWidth(460)
        outer = QVBoxLayout(self)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        inner = QWidget()
        layout = QFormLayout(inner)
        scroll.setWidget(inner)
        outer.addWidget(scroll)

        self.class_cb = QComboBox(); self.class_cb.setMinimumHeight(38)
        for c in db.fetchall("SELECT id,name FROM classes ORDER BY level"):
            self.class_cb.addItem(c['name'], c['id'])
        self.class_cb.currentIndexChanged.connect(self._reload_subjects)

        self.section_cb = QComboBox(); self.section_cb.setMinimumHeight(38)
        self.class_cb.currentIndexChanged.connect(self._reload_sections)

        self.subject_cb = QComboBox(); self.subject_cb.setMinimumHeight(38)

        self.teacher_cb = QComboBox(); self.teacher_cb.setMinimumHeight(38)
        self.teacher_cb.addItem("(No Teacher)", None)
        for s in db.fetchall("SELECT id,full_name FROM staff WHERE status='active' ORDER BY full_name"):
            self.teacher_cb.addItem(s['full_name'], s['id'])

        self.day_cb = QComboBox(); self.day_cb.setMinimumHeight(38)
        self.day_cb.addItems(["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"])

        self.period_sb = QSpinBox(); self.period_sb.setRange(1,8); self.period_sb.setMinimumHeight(38)

        self.start_le = QLineEdit(); self.start_le.setPlaceholderText("e.g. 08:00"); self.start_le.setMinimumHeight(38)
        self.end_le   = QLineEdit(); self.end_le.setPlaceholderText("e.g. 08:45"); self.end_le.setMinimumHeight(38)
        self.room_le  = QLineEdit(); self.room_le.setPlaceholderText("Room No."); self.room_le.setMinimumHeight(38)

        layout.addRow("Class:",   self.class_cb)
        layout.addRow("Section:", self.section_cb)
        layout.addRow("Subject:", self.subject_cb)
        layout.addRow("Teacher:", self.teacher_cb)
        layout.addRow("Day:",     self.day_cb)
        layout.addRow("Period:",  self.period_sb)
        layout.addRow("Start:",   self.start_le)
        layout.addRow("End:",     self.end_le)
        layout.addRow("Room:",    self.room_le)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self._save)
        btns.rejected.connect(self.reject)
        outer.addWidget(btns)

        self._reload_subjects(); self._reload_sections()

    def _reload_subjects(self):
        self.subject_cb.clear()
        cid = self.class_cb.currentData()
        if cid:
            for s in self.db.fetchall("SELECT id,name FROM subjects WHERE class_id=?", (cid,)):
                self.subject_cb.addItem(s['name'], s['id'])

    def _reload_sections(self):
        self.section_cb.clear()
        self.section_cb.addItem("None", 0)
        cid = self.class_cb.currentData()
        if cid:
            for s in self.db.fetchall("SELECT id,name FROM sections WHERE class_id=?", (cid,)):
                self.section_cb.addItem(s['name'], s['id'])

    def _save(self):
        cid  = self.class_cb.currentData()
        sid  = self.section_cb.currentData() or 0
        subj = self.subject_cb.currentData()
        tid  = self.teacher_cb.currentData()
        day  = self.day_cb.currentText()
        per  = self.period_sb.value()
        if not cid or not subj:
            QMessageBox.warning(self, "Missing", "Class and Subject required."); return
        if day == "Friday" and per > self.friday_periods:
            reply = QMessageBox.question(self, "Friday is a Half Day",
                f"Friday is configured as a half day ending after Period "
                f"{self.friday_periods}, with no recess.\n\n"
                f"Period {per} falls outside school hours on Friday. Add anyway?",
                QMessageBox.Yes | QMessageBox.No)
            if reply != QMessageBox.Yes:
                return
        try:
            self.db.execute("""INSERT OR REPLACE INTO timetable
                (class_id,section_id,subject_id,teacher_id,day,period,start_time,end_time,room)
                VALUES (?,?,?,?,?,?,?,?,?)""",
                (cid, sid, subj, tid, day, per,
                 self.start_le.text(), self.end_le.text(), self.room_le.text()))
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


class RecessSettingsDialog(QDialog):
    """Configure recess period + Friday half-day cut-off."""
    def __init__(self, parent, recess_after, recess_start, recess_end, friday_periods):
        super().__init__(parent)
        self.setWindowTitle("Recess & Friday Half-Day Settings")
        self.setMinimumWidth(420)
        layout = QFormLayout(self)

        note = QLabel(
            "Configure the daily recess break, and Friday's half-day cut-off.\n"
            "Friday will automatically end early with NO recess period.")
        note.setWordWrap(True)
        note.setStyleSheet("color:#94a3b8;font-size:11px;")
        layout.addRow(note)

        self.sp_after = QSpinBox(); self.sp_after.setRange(1, 7)
        self.sp_after.setValue(recess_after)
        self.sp_after.setMinimumHeight(36)
        layout.addRow("Recess After Period:", self.sp_after)

        self.le_start = QLineEdit(recess_start); self.le_start.setMinimumHeight(36)
        self.le_start.setPlaceholderText("e.g. 11:00 AM")
        layout.addRow("Recess Start Time:", self.le_start)

        self.le_end = QLineEdit(recess_end); self.le_end.setMinimumHeight(36)
        self.le_end.setPlaceholderText("e.g. 11:20 AM")
        layout.addRow("Recess End Time:", self.le_end)

        self.sp_friday = QSpinBox(); self.sp_friday.setRange(1, 8)
        self.sp_friday.setValue(friday_periods)
        self.sp_friday.setMinimumHeight(36)
        layout.addRow("Friday Ends After Period:", self.sp_friday)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

    def values(self):
        return (self.sp_after.value(), self.le_start.text().strip() or "11:00 AM",
                self.le_end.text().strip() or "11:20 AM", self.sp_friday.value())
