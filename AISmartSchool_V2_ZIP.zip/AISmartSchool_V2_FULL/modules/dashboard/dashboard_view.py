"""
Dashboard V4 — Fixed layout clipping, grid overlapping, and viewport overflow.
"""
import importlib
from datetime import datetime

try:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout,
        QFrame, QPushButton, QSizePolicy, QScrollArea
    )
    from PySide6.QtCore import Qt, QTimer
    from PySide6.QtGui import QPainter, QColor, QFont
except ImportError:
    QtWidgets = importlib.import_module("PySide2.QtWidgets")
    QtCore = importlib.import_module("PySide2.QtCore")
    QtGui = importlib.import_module("PySide2.QtGui")

    QWidget = QtWidgets.QWidget
    QVBoxLayout = QtWidgets.QVBoxLayout
    QHBoxLayout = QtWidgets.QHBoxLayout
    QLabel = QtWidgets.QLabel
    QGridLayout = QtWidgets.QGridLayout
    QFrame = QtWidgets.QFrame
    QPushButton = QtWidgets.QPushButton
    QSizePolicy = QtWidgets.QSizePolicy
    QScrollArea = QtWidgets.QScrollArea

    Qt = QtCore.Qt
    QTimer = QtCore.QTimer

    QPainter = QtGui.QPainter
    QColor = QtGui.QColor
    QFont = QtGui.QFont

from core.color_utils import rgba
from ui.components.widgets import StatCard, DonutChart


class DashboardView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db   = db
        self.user = user
        self.role = user.get("role", "staff")
        self._init_ui()
        # Deferred data load
        QTimer.singleShot(100, self._load_data)

    def _init_ui(self):
        # Base Main Layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # Wrap dashboard inside a Scroll Area to prevent window boundary clipping
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")

        container = QWidget()
        container.setStyleSheet("background: transparent;")
        root = QVBoxLayout(container)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(16)

        # 1. Top Greeting + Profile
        top = QHBoxLayout()
        top.setSpacing(12)
        top.addWidget(self._build_greeting(), 1)
        top.addWidget(self._build_profile_card(), 0)
        root.addLayout(top)

        # Demo Banner (if active)
        from core.demo_config import DEMO_MODE
        if DEMO_MODE:
            from ui.components.demo_dialogs import whatsapp_purchase_banner
            root.addWidget(whatsapp_purchase_banner(self))

        # 2. Stat Cards Grid Layout (Clean Grid)
        self.cards_grid = QGridLayout()
        self.cards_grid.setSpacing(12)
        self.cards_grid.setContentsMargins(0, 0, 0, 0)
        root.addLayout(self.cards_grid)

        # 3. Quick Actions
        root.addWidget(self._build_quick_actions())

        # 4. Middle Charts & Insights
        bottom = QHBoxLayout()
        bottom.setSpacing(12)
        self.chart_left = self._build_chart_panel(
            "📊 Attendance This Week",
            ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], [85, 90, 78, 92, 88, 95], "#2563eb")
        self.chart_right = self._build_chart_panel(
            "💰 Fee Collection (6 months)",
            ["Jan", "Feb", "Mar", "Apr", "May", "Jun"], [45, 52, 38, 61, 55, 70], "#22c55e")
        self.insights_panel = self._build_insights_panel()

        bottom.addWidget(self.chart_left, 3)
        bottom.addWidget(self.chart_right, 3)
        bottom.addWidget(self.insights_panel, 2)
        root.addLayout(bottom)

        # 5. Donut Charts Bottom Panel
        donuts = QHBoxLayout()
        donuts.setSpacing(12)
        self.fee_donut_panel = self._build_donut_panel(
            "💳 Fee Voucher Status", [("Paid", 0, "#22c55e"), ("Pending", 0, "#f59e0b"),
                                    ("Overdue", 0, "#ef4444")])
        self.attendance_donut_panel = self._build_donut_panel(
            "🧑‍🎓 Today's Attendance", [("Present", 0, "#22c55e"), ("Absent", 0, "#ef4444"),
                                        ("Leave", 0, "#f59e0b")])
        self.gender_donut_panel = self._build_donut_panel(
            "⚧ Student Gender Split", [("Male", 0, "#3b82f6"), ("Female", 0, "#ec4899")])

        donuts.addWidget(self.fee_donut_panel, 1)
        donuts.addWidget(self.attendance_donut_panel, 1)
        donuts.addWidget(self.gender_donut_panel, 1)
        root.addLayout(donuts)

        root.addStretch()
        scroll.setWidget(container)
        main_layout.addWidget(scroll)

    def _build_greeting(self):
        w = QWidget()
        w.setStyleSheet("background:transparent;")
        l = QVBoxLayout(w)
        l.setContentsMargins(0, 0, 0, 0)
        l.setSpacing(2)
        h = datetime.now().hour
        greet = ("Good Morning ☀️" if h < 12 else
                "Good Afternoon 🌤" if h < 17 else "Good Evening 🌙")
        name = self.user.get("full_name", "User")

        g = QLabel(f"{greet}, {name}!")
        g.setStyleSheet("font-size:20px;font-weight:800;color:#f8fafc;background:transparent;")
        d = QLabel(datetime.now().strftime("%A, %d %B %Y"))
        d.setStyleSheet("font-size:12px;color:#8b949e;background:transparent;")

        l.addWidget(g)
        l.addWidget(d)
        l.addStretch()
        return w

    def _build_profile_card(self):
        card = QFrame()
        card.setFixedWidth(240)
        card.setFixedHeight(72)
        card.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1e3a8a, stop:1 #2563eb);
                border-radius: 12px;
            }
            QLabel {
                background: transparent;
                border: none;
            }
        """)
        l = QHBoxLayout(card)
        l.setContentsMargins(12, 8, 12, 8)
        l.setSpacing(10)

        av = QLabel((self.user.get("full_name") or "U")[0].upper())
        av.setFixedSize(42, 42)
        av.setAlignment(Qt.AlignCenter)
        av.setStyleSheet(
            "background:rgba(255,255,255,0.2);border-radius:21px;"
            "color:white;font-size:17px;font-weight:800;"
        )

        info = QVBoxLayout()
        info.setSpacing(1)
        nm = QLabel(self.user.get("full_name", "User"))
        nm.setStyleSheet("color:white;font-size:12px;font-weight:700;background:transparent;")
        rl = QLabel(self.role.upper())
        rl.setStyleSheet(
            "color:rgba(255,255,255,0.7);font-size:10px;font-weight:600;"
            "border:1px solid rgba(255,255,255,0.3);border-radius:4px;"
            "padding:0 4px;background:transparent;"
        )
        info.addWidget(nm)
        info.addWidget(rl)
        info.addStretch()

        l.addWidget(av)
        l.addLayout(info, 1)
        return card

    def _build_quick_actions(self):
        w = QFrame()
        w.setStyleSheet("background:transparent;border:none;")
        l = QHBoxLayout(w)
        l.setContentsMargins(0, 0, 0, 0)
        l.setSpacing(8)
        actions = [
            ("➕ New Admission",   "#2563eb"),
            ("✅ Mark Attendance", "#22c55e"),
            ("💳 Fee Voucher",     "#f59e0b"),
            ("📝 Enter Marks",     "#8b5cf6"),
            ("🪪 ID Cards",        "#f97316"),
        ]
        for label, color in actions:
            btn = QPushButton(label)
            btn.setFixedHeight(36)
            btn.setStyleSheet(
                f"QPushButton{{background:{rgba(color, '22')};color:{color};"
                f"border:1px solid {rgba(color, '44')};border-radius:8px;"
                f"font-size:12px;font-weight:600;padding:0 14px;}}"
                f"QPushButton:hover{{background:{rgba(color, '44')};}}"
            )
            l.addWidget(btn)
        l.addStretch()
        return w

    def _build_chart_panel(self, title, labels, values, color):
        frame = QFrame()
        frame.setObjectName("card")
        frame.setFixedHeight(210)
        frame.setStyleSheet("QFrame#card { background: #1e293b; border-radius: 12px; }")

        fl = QVBoxLayout(frame)
        fl.setContentsMargins(14, 12, 14, 12)
        fl.setSpacing(6)

        t = QLabel(title)
        t.setStyleSheet("font-size:13px;font-weight:700;color:#f8fafc;background:transparent;")
        fl.addWidget(t)

        chart = MiniBarChart(labels, values, color)
        fl.addWidget(chart, 1)
        return frame

    def _build_donut_panel(self, title, initial_segments):
        frame = QFrame()
        frame.setObjectName("card")
        frame.setFixedHeight(210)
        frame.setStyleSheet("QFrame#card { background: #1e293b; border-radius: 12px; }")

        fl = QVBoxLayout(frame)
        fl.setContentsMargins(14, 10, 14, 10)
        fl.setSpacing(4)

        t = QLabel(title)
        t.setStyleSheet("font-size:13px;font-weight:700;color:#f8fafc;background:transparent;")
        fl.addWidget(t)

        donut = DonutChart(initial_segments)
        donut.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        fl.addWidget(donut, 1)

        frame._donut = donut
        return frame

    def _build_insights_panel(self):
        frame = QFrame()
        frame.setObjectName("card")
        frame.setFixedHeight(210)
        frame.setStyleSheet("QFrame#card { background: #1e293b; border-radius: 12px; }")

        fl = QVBoxLayout(frame)
        fl.setContentsMargins(14, 12, 14, 12)
        fl.setSpacing(6)

        t = QLabel("🤖 Smart Insights")
        t.setStyleSheet("font-size:13px;font-weight:700;color:#f8fafc;background:transparent;")
        fl.addWidget(t)

        self._insights_layout = QVBoxLayout()
        self._insights_layout.setSpacing(6)
        fl.addLayout(self._insights_layout)
        fl.addStretch()
        return frame

    def _load_data(self):
        try:
            stu  = (self.db.fetchone("SELECT COUNT(*) as c FROM students WHERE status='active'") or {}).get("c", 0)
            cls  = (self.db.fetchone("SELECT COUNT(*) as c FROM classes") or {}).get("c", 0)
            fees = (self.db.fetchone(
                "SELECT COALESCE(SUM(remaining_amount),0) as c FROM fee_vouchers "
                "WHERE status IN('pending','overdue','partial')") or {}).get("c", 0)
            ab   = (self.db.fetchone(
                "SELECT COUNT(*) as c FROM attendance WHERE date=date('now', 'localtime') AND status='absent'") or {}).get("c", 0)

            cards = [
                ("Total Students", stu,  "👨‍🎓", "#2563eb"),
                ("Total Classes",  cls,  "🏫",  "#8b5cf6"),
                ("Pending Fees",   f"Rs.{fees:,.0f}", "💰", "#f59e0b"),
                ("Absent Today",   ab,   "📋",  "#ef4444"),
            ]
            if self.role == "admin":
                stf = (self.db.fetchone("SELECT COUNT(*) as c FROM staff WHERE status='active'") or {}).get("c", 0)
                pv  = (self.db.fetchone("SELECT COUNT(*) as c FROM fee_vouchers WHERE status='paid'") or {}).get("c", 0)
                cards += [
                    ("Active Staff",  stf, "👥", "#22c55e"),
                    ("Paid Vouchers", pv,  "✅", "#10b981"),
                ]

            # Clear existing items
            while self.cards_grid.count():
                item = self.cards_grid.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()

            # Responsive Column Layout Calculation:
            # If 6 items, arrange 3x2 or 6x1 depending on room. Here we set 3 items per row for clean alignment.
            cols = 3 if len(cards) == 6 else 4
            for i, (title, val, icon, color) in enumerate(cards):
                card = StatCard(title, val, icon, color)
                card.setFixedHeight(85)
                self.cards_grid.addWidget(card, i // cols, i % cols)

            self._load_donuts()
            self._load_insights()
        except Exception as e:
            err = QLabel(f"⚠️ Dashboard load error: {e}")
            err.setStyleSheet("color:#ef4444;background:transparent;font-size:12px;")
            self.cards_grid.addWidget(err, 0, 0, 1, 4)

    def _load_donuts(self):
        try:
            paid    = (self.db.fetchone("SELECT COUNT(*) c FROM fee_vouchers WHERE status='paid'") or {}).get("c", 0)
            pending = (self.db.fetchone("SELECT COUNT(*) c FROM fee_vouchers WHERE status IN ('pending','partial')") or {}).get("c", 0)
            overdue = (self.db.fetchone("SELECT COUNT(*) c FROM fee_vouchers WHERE status='overdue'") or {}).get("c", 0)
            self.fee_donut_panel._donut.set_segments([
                ("Paid", paid, "#22c55e"), ("Pending", pending, "#f59e0b"), ("Overdue", overdue, "#ef4444")])

            present = (self.db.fetchone("SELECT COUNT(*) c FROM attendance WHERE date=date('now', 'localtime') AND status='present'") or {}).get("c", 0)
            absent  = (self.db.fetchone("SELECT COUNT(*) c FROM attendance WHERE date=date('now', 'localtime') AND status='absent'") or {}).get("c", 0)
            leave   = (self.db.fetchone("SELECT COUNT(*) c FROM attendance WHERE date=date('now', 'localtime') AND status='leave'") or {}).get("c", 0)
            self.attendance_donut_panel._donut.set_segments([
                ("Present", present, "#22c55e"), ("Absent", absent, "#ef4444"), ("Leave", leave, "#f59e0b")])

            male   = (self.db.fetchone("SELECT COUNT(*) c FROM students WHERE status='active' AND gender='Male'") or {}).get("c", 0)
            female = (self.db.fetchone("SELECT COUNT(*) c FROM students WHERE status='active' AND gender='Female'") or {}).get("c", 0)
            self.gender_donut_panel._donut.set_segments([
                ("Male", male, "#3b82f6"), ("Female", female, "#ec4899")])
        except Exception:
            pass

    def _load_insights(self):
        while self._insights_layout.count():
            item = self._insights_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        items = []
        try:
            ab = (self.db.fetchone(
                "SELECT COUNT(DISTINCT student_id) as c FROM attendance "
                "WHERE date>=date('now', 'localtime', '-7 days') AND status='absent'") or {}).get("c", 0)
            if ab > 0:
                items.append(("⚠️", f"{ab} absences in last 7 days", "#f59e0b"))
            ov = (self.db.fetchone(
                "SELECT COUNT(*) as c FROM fee_vouchers WHERE status='overdue'") or {}).get("c", 0)
            if ov > 0:
                items.append(("💸", f"{ov} fee vouchers overdue", "#ef4444"))
            pa = (self.db.fetchone(
                "SELECT COUNT(*) as c FROM admissions WHERE status='pending'") or {}).get("c", 0)
            if pa > 0:
                items.append(("📋", f"{pa} admissions pending", "#3b82f6"))
        except Exception:
            pass

        if not items:
            items.append(("✅", "All systems normal", "#22c55e"))

        for icon, text, color in items:
            row = QFrame()
            row.setStyleSheet(
                f"background:{rgba(color, '12')};border:1px solid {rgba(color, '30')};"
                f"border-radius:7px;padding:4px 8px;"
            )
            rl = QHBoxLayout(row)
            rl.setContentsMargins(0, 0, 0, 0)
            rl.setSpacing(6)
            il = QLabel(icon)
            il.setStyleSheet("font-size:14px;background:transparent;")
            tl = QLabel(text)
            tl.setStyleSheet(f"color:{color};font-size:11px;font-weight:600;background:transparent;")
            tl.setWordWrap(True)
            rl.addWidget(il)
            rl.addWidget(tl, 1)
            self._insights_layout.addWidget(row)


# ── Pure-Qt bar chart ──────────────────────────────────────────────────────────
class MiniBarChart(QWidget):
    def __init__(self, labels, values, color="#2563eb", parent=None):
        super().__init__(parent)
        self._labels  = labels
        self._values  = values
        self._color   = QColor(color)
        self._ratios  = [0.0] * len(values)
        self.setMinimumHeight(110)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._step)
        QTimer.singleShot(150, self._timer.start)
        self._timer.setInterval(16)

    def _step(self):
        done = True
        for i in range(len(self._ratios)):
            if self._ratios[i] < 1.0:
                self._ratios[i] = min(self._ratios[i] + 0.07, 1.0)
                done = False
        self.update()
        if done:
            self._timer.stop()

    def paintEvent(self, event):
        if not self._values:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        W, H   = self.width(), self.height()
        pad_b  = 20
        pad_t  = 24
        pad_lr = 4
        n      = len(self._values)
        ch     = max(10, H - pad_b - pad_t)
        cw     = W - pad_lr * 2
        gap    = cw / n
        bw     = max(4, int(gap * 0.55))
        max_v  = max(self._values) or 1

        for i, val in enumerate(self._values):
            ratio = (val / max_v) * self._ratios[i]
            bh    = max(2, int(ch * ratio))
            x     = int(pad_lr + i * gap + (gap - bw) / 2)
            y     = H - pad_b - bh

            c = QColor(self._color)
            c.setAlphaF(0.65 + 0.35 * self._ratios[i])
            p.setBrush(c)
            p.setPen(Qt.NoPen)
            p.drawRoundedRect(x, y, bw, bh, 3, 3)

            if self._ratios[i] > 0.7:
                p.setPen(QColor(self._color))
                p.setFont(QFont("Segoe UI", 8, QFont.Bold))
                p.drawText(x - 10, y - 16, bw + 20, 14,
                        Qt.AlignCenter | Qt.TextDontClip, str(val))

            p.setPen(QColor("#8b949e"))
            p.setFont(QFont("Segoe UI", 8))
            lbl = str(self._labels[i]) if i < len(self._labels) else ""
            p.drawText(x - 10, H - 16, bw + 20, 16,
                    Qt.AlignCenter | Qt.TextDontClip, lbl)

        p.end()