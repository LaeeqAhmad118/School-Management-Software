"""
Parent Portal — Fix 5
Accessible via unique student ID + access code. Shows attendance, results, fees, timetable.
Printable summary included.
"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont
from ui.components.widgets import SectionHeader, shadow
import random, string
from core.color_utils import rgba


class ParentPortalView(QWidget):
    """Admin-side management of parent portal access codes."""
    def __init__(self, db, user):
        super().__init__()
        self.db = db; self.user = user
        self._init_ui()
        self._load_access_list()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20); layout.setSpacing(16)
        header = SectionHeader("Parent Portal", "Manage parent access to student information")
        btn = header.add_button("Generate Codes", "btn_add", "🔑")
        btn.clicked.connect(self._generate_codes)
        layout.addWidget(header)

        # Info banner
        info = QFrame()
        info.setStyleSheet("background:#1e3a8a22;border:1px solid #2563eb44;border-radius:10px;padding:14px;")
        il = QHBoxLayout(info)
        icon = QLabel("ℹ️"); icon.setStyleSheet("font-size:20px;")
        txt = QLabel("Parents can log in using the <b>Student ID</b> and the generated <b>Access Code</b>. "
                     "Use the 'Open Parent View' button to preview what parents see.")
        txt.setStyleSheet("color:#93c5fd;font-size:12px;")
        txt.setWordWrap(True)
        il.addWidget(icon); il.addWidget(txt, 1)
        layout.addWidget(info)

        # Search bar
        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍  Search by student name or ID...")
        self.search_input.setMinimumHeight(40)
        self.search_input.textChanged.connect(self._filter_list)
        search_row.addWidget(self.search_input)

        open_portal_btn = QPushButton("🌐 Open Parent Login")
        open_portal_btn.setStyleSheet("background:#2563eb;color:white;border-radius:8px;padding:8px 16px;font-weight:600;")
        open_portal_btn.clicked.connect(self._open_parent_login)
        search_row.addWidget(open_portal_btn)
        layout.addLayout(search_row)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Student ID", "Student Name", "Class", "Access Code", "Actions"])
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        layout.addWidget(self.table)

    def _generate_code(self):
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

    def _generate_codes(self):
        """Generate access codes for all students that don't have one."""
        students = self.db.fetchall("""
            SELECT s.id, s.student_id FROM students s
            LEFT JOIN parent_access pa ON pa.student_id = s.id
            WHERE pa.id IS NULL AND s.status='active'
        """)
        if not students:
            QMessageBox.information(self, "Up to Date", "All active students already have access codes.")
            return
        for s in students:
            code = self._generate_code()
            self.db.execute(
                "INSERT OR IGNORE INTO parent_access (student_id, access_code) VALUES (?,?)",
                (s['id'], code)
            )
        QMessageBox.information(self, "Done", f"Generated codes for {len(students)} student(s).")
        self._load_access_list()

    def _load_access_list(self):
        self._all_rows = self.db.fetchall("""
            SELECT s.student_id, s.full_name, c.name as class_name,
                   pa.access_code, pa.is_active, s.id as sid
            FROM students s
            LEFT JOIN parent_access pa ON pa.student_id = s.id
            LEFT JOIN classes c ON s.class_id = c.id
            WHERE s.status = 'active'
            ORDER BY c.name, s.full_name
        """)
        self._render_table(self._all_rows)

    def _filter_list(self):
        term = self.search_input.text().lower()
        filtered = [r for r in self._all_rows
                    if term in (r.get('full_name','') or '').lower()
                    or term in (r.get('student_id','') or '').lower()]
        self._render_table(filtered)

    def _render_table(self, rows):
        self.table.setRowCount(0)
        for r in rows:
            ri = self.table.rowCount(); self.table.insertRow(ri)
            self.table.setItem(ri, 0, QTableWidgetItem(r.get('student_id','') or ''))
            self.table.setItem(ri, 1, QTableWidgetItem(r.get('full_name','') or ''))
            self.table.setItem(ri, 2, QTableWidgetItem(r.get('class_name','') or ''))
            code = r.get('access_code','')
            code_item = QTableWidgetItem(code or '—  (not generated)')
            if not code:
                code_item.setForeground(Qt.gray)
            self.table.setItem(ri, 3, code_item)

            w = QWidget(); bl = QHBoxLayout(w); bl.setContentsMargins(4,2,4,2); bl.setSpacing(6)
            view_btn = QPushButton("👁 View Portal")
            view_btn.setStyleSheet("background:#2563eb;color:white;border-radius:5px;padding:4px 10px;font-size:11px;")
            sid = r.get('sid')
            view_btn.clicked.connect(lambda ch, s=sid: self._view_student_portal(s))

            regen_btn = QPushButton("🔄 Reset Code")
            regen_btn.setStyleSheet("background:#f59e0b;color:white;border-radius:5px;padding:4px 10px;font-size:11px;")
            regen_btn.clicked.connect(lambda ch, s=sid: self._reset_code(s))

            bl.addWidget(view_btn); bl.addWidget(regen_btn); bl.addStretch()
            self.table.setCellWidget(ri, 4, w)
            self.table.setRowHeight(ri, 44)

    def _reset_code(self, student_id):
        code = self._generate_code()
        existing = self.db.fetchone("SELECT id FROM parent_access WHERE student_id=?", (student_id,))
        if existing:
            self.db.execute("UPDATE parent_access SET access_code=? WHERE student_id=?", (code, student_id))
        else:
            self.db.execute("INSERT INTO parent_access (student_id, access_code) VALUES (?,?)", (student_id, code))
        self._load_access_list()
        QMessageBox.information(self, "Code Reset", f"New access code: {code}")

    def _view_student_portal(self, student_id):
        dlg = ParentPortalDialog(self.db, student_id, self)
        dlg.exec()

    def _open_parent_login(self):
        dlg = ParentLoginDialog(self.db, self)
        dlg.exec()


class ParentLoginDialog(QDialog):
    """Login dialog for parents to access their child's info."""
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Parent Portal — Login")
        self.setMinimumWidth(420)
        self.setMinimumHeight(300)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 32, 32, 32); layout.setSpacing(16)

        title = QLabel("🏫  Parent Portal")
        title.setStyleSheet("font-size:22px;font-weight:700;color:#e6edf3;")
        title.setAlignment(Qt.AlignCenter)
        sub = QLabel("Enter your child's Student ID and access code")
        sub.setStyleSheet("color:#8b949e;font-size:12px;")
        sub.setAlignment(Qt.AlignCenter)
        layout.addWidget(title); layout.addWidget(sub)

        self.student_id_input = QLineEdit()
        self.student_id_input.setPlaceholderText("Student ID (e.g. STU-2024-001)")
        self.student_id_input.setMinimumHeight(42)
        self.student_id_input.setStyleSheet("border:1px solid #30363d;border-radius:8px;padding:8px 12px;font-size:13px;")

        self.code_input = QLineEdit()
        self.code_input.setPlaceholderText("Access Code (e.g. AB12CD34)")
        self.code_input.setMinimumHeight(42)
        self.code_input.setEchoMode(QLineEdit.Password)
        self.code_input.setStyleSheet("border:1px solid #30363d;border-radius:8px;padding:8px 12px;font-size:13px;")

        show_pw = QCheckBox("Show access code")
        show_pw.toggled.connect(lambda v: self.code_input.setEchoMode(QLineEdit.Normal if v else QLineEdit.Password))

        layout.addWidget(QLabel("Student ID:")); layout.addWidget(self.student_id_input)
        layout.addWidget(QLabel("Access Code:")); layout.addWidget(self.code_input)
        layout.addWidget(show_pw)

        self.error_lbl = QLabel("")
        self.error_lbl.setStyleSheet("color:#ef4444;font-size:12px;")
        self.error_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.error_lbl)

        login_btn = QPushButton("Login →")
        login_btn.setMinimumHeight(44)
        login_btn.setStyleSheet("background:#2563eb;color:white;border-radius:10px;font-size:14px;font-weight:700;")
        login_btn.clicked.connect(self._do_login)
        self.code_input.returnPressed.connect(self._do_login)
        layout.addWidget(login_btn)

    def _do_login(self):
        sid = self.student_id_input.text().strip()
        code = self.code_input.text().strip().upper()
        if not sid or not code:
            self.error_lbl.setText("Please enter both Student ID and Access Code.")
            return
        result = self.db.fetchone("""
            SELECT s.id FROM students s
            JOIN parent_access pa ON pa.student_id = s.id
            WHERE s.student_id = ? AND pa.access_code = ? AND pa.is_active = 1
        """, (sid, code))
        if result:
            self.accept()
            dlg = ParentPortalDialog(self.db, result['id'], self.parent())
            dlg.exec()
        else:
            self.error_lbl.setText("❌ Invalid Student ID or Access Code.")


class ParentPortalDialog(QDialog):
    """Full parent-facing portal: info, attendance, fees, results, timetable. Printable."""
    def __init__(self, db, student_db_id, parent=None):
        super().__init__(parent)
        self.db = db
        self.student_id = student_db_id
        self.setWindowTitle("Parent Portal — Student Dashboard")
        self.setMinimumSize(900, 700)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        # Top bar
        topbar = QFrame()
        topbar.setStyleSheet("background:#0d1117;border-bottom:1px solid #30363d;")
        topbar.setFixedHeight(60)
        tbl = QHBoxLayout(topbar); tbl.setContentsMargins(20, 0, 20, 0)
        title = QLabel("🏫  Parent Portal")
        title.setStyleSheet("color:white;font-size:18px;font-weight:700;")
        print_btn = QPushButton("🖨️ Print / Save PDF")
        print_btn.setStyleSheet("background:#22c55e;color:white;border-radius:8px;padding:8px 16px;font-weight:600;")
        print_btn.clicked.connect(self._print_report)
        close_btn = QPushButton("✕ Close")
        close_btn.setStyleSheet("background:#ef444422;color:#ef4444;border:1px solid #ef444444;border-radius:8px;padding:8px 14px;")
        close_btn.clicked.connect(self.accept)
        tbl.addWidget(title); tbl.addStretch(); tbl.addWidget(print_btn); tbl.addSpacing(8); tbl.addWidget(close_btn)
        layout.addWidget(topbar)

        # Tabs
        tabs = QTabWidget()
        tabs.setStyleSheet("QTabWidget::pane {border:none;} QTabBar::tab {padding:10px 20px;font-weight:600;}")

        tabs.addTab(self._build_info_tab(), "👤 Student Info")
        tabs.addTab(self._build_attendance_tab(), "✅ Attendance")
        tabs.addTab(self._build_fees_tab(), "💰 Fee Status")
        tabs.addTab(self._build_results_tab(), "🏆 Results")
        tabs.addTab(self._build_timetable_tab(), "🗓 Timetable")

        layout.addWidget(tabs)

    def _get_student(self):
        return self.db.fetchone("""
            SELECT s.*, c.name as class_name FROM students s
            LEFT JOIN classes c ON s.class_id = c.id
            WHERE s.id = ?
        """, (self.student_id,))

    def _build_info_tab(self):
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(24, 20, 24, 20); l.setSpacing(12)
        s = self._get_student()
        if not s:
            l.addWidget(QLabel("Student not found.")); return w

        # Student card
        card = QFrame()
        card.setStyleSheet("background:#1c2128;border:1px solid #30363d;border-radius:12px;padding:20px;")
        cl = QHBoxLayout(card)

        avatar = QLabel("👨‍🎓")
        avatar.setFixedSize(80, 80)
        avatar.setAlignment(Qt.AlignCenter)
        avatar.setStyleSheet("background:#1e3a8a;border-radius:40px;font-size:36px;")

        info_layout = QVBoxLayout()
        name_lbl = QLabel(s.get('full_name',''))
        name_lbl.setStyleSheet("color:white;font-size:20px;font-weight:700;")
        id_lbl = QLabel(f"Student ID: {s.get('student_id','')}  •  Class: {s.get('class_name','')}")
        id_lbl.setStyleSheet("color:#8b949e;font-size:13px;")
        info_layout.addWidget(name_lbl); info_layout.addWidget(id_lbl)

        cl.addWidget(avatar); cl.addLayout(info_layout, 1)
        l.addWidget(card)
        shadow(card)

        # Details grid
        details = [
            ("Gender", s.get('gender','')), ("Date of Birth", str(s.get('dob',''))),
            ("Blood Group", s.get('blood_group','')), ("Religion", s.get('religion','')),
            ("Father's Name", s.get('father_name','')), ("Father's Phone", s.get('father_phone','')),
            ("Mother's Name", s.get('mother_name','')), ("Mother's Phone", s.get('mother_phone','')),
            ("Address", s.get('address','')), ("Status", s.get('status','').upper()),
        ]
        grid = QGridLayout(); grid.setSpacing(12)
        for i, (k, v) in enumerate(details):
            lbl = QLabel(k + ":"); lbl.setStyleSheet("color:#8b949e;font-size:12px;font-weight:600;")
            val = QLabel(str(v) if v else "—"); val.setStyleSheet("color:#e6edf3;font-size:13px;")
            grid.addWidget(lbl, i // 2, (i % 2) * 2)
            grid.addWidget(val, i // 2, (i % 2) * 2 + 1)
        l.addLayout(grid)
        l.addStretch()
        return w

    def _build_attendance_tab(self):
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(24, 20, 24, 20); l.setSpacing(12)

        rows = self.db.fetchall("""
            SELECT date, status FROM attendance
            WHERE student_id = ? ORDER BY date DESC LIMIT 60
        """, (self.student_id,))

        total = len(rows)
        present = sum(1 for r in rows if r.get('status') == 'present')
        absent = total - present
        pct = (present / total * 100) if total else 0

        # Summary cards
        summary = QHBoxLayout()
        for title, val, color in [
            ("Total Days", str(total), "#2563eb"),
            ("Present", str(present), "#22c55e"),
            ("Absent", str(absent), "#ef4444"),
            ("Attendance %", f"{pct:.1f}%", "#f59e0b" if pct < 75 else "#22c55e"),
        ]:
            f = QFrame()
            f.setStyleSheet(f"background:#1c2128;border:1px solid {rgba(color, '44')};border-radius:10px;padding:14px;")
            fl = QVBoxLayout(f)
            v = QLabel(val); v.setStyleSheet(f"color:{color};font-size:22px;font-weight:700;"); v.setAlignment(Qt.AlignCenter)
            t = QLabel(title); t.setStyleSheet("color:#8b949e;font-size:11px;"); t.setAlignment(Qt.AlignCenter)
            fl.addWidget(v); fl.addWidget(t)
            summary.addWidget(f)
        l.addLayout(summary)

        # Attendance table
        table = QTableWidget(len(rows), 2)
        table.setHorizontalHeaderLabels(["Date", "Status"])
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.setAlternatingRowColors(True)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for ri, r in enumerate(rows):
            table.setItem(ri, 0, QTableWidgetItem(str(r.get('date',''))))
            status = r.get('status','').capitalize()
            item = QTableWidgetItem(status)
            item.setForeground(Qt.green if status.lower() == 'present' else Qt.red)
            table.setItem(ri, 1, item)
            table.setRowHeight(ri, 34)
        l.addWidget(table)
        return w

    def _build_fees_tab(self):
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(24, 20, 24, 20); l.setSpacing(12)

        rows = self.db.fetchall("""
            SELECT voucher_id, month, year, total_amount, paid_amount,
                   COALESCE(remaining_amount, total_amount-paid_amount) as remaining,
                   status, due_date
            FROM fee_vouchers WHERE student_id = ? ORDER BY id DESC
        """, (self.student_id,))

        total_due = sum(r.get('total_amount',0) or 0 for r in rows)
        total_paid = sum(r.get('paid_amount',0) or 0 for r in rows)
        total_remaining = sum(r.get('remaining',0) or 0 for r in rows)

        summary = QHBoxLayout()
        for title, val, color in [
            ("Total Due", f"Rs.{total_due:,.0f}", "#2563eb"),
            ("Paid", f"Rs.{total_paid:,.0f}", "#22c55e"),
            ("Remaining", f"Rs.{total_remaining:,.0f}", "#ef4444"),
        ]:
            f = QFrame()
            f.setStyleSheet(f"background:#1c2128;border:1px solid {rgba(color, '44')};border-radius:10px;padding:14px;")
            fl = QVBoxLayout(f)
            v = QLabel(val); v.setStyleSheet(f"color:{color};font-size:18px;font-weight:700;"); v.setAlignment(Qt.AlignCenter)
            t = QLabel(title); t.setStyleSheet("color:#8b949e;font-size:11px;"); t.setAlignment(Qt.AlignCenter)
            fl.addWidget(v); fl.addWidget(t)
            summary.addWidget(f)
        l.addLayout(summary)

        table = QTableWidget(len(rows), 6)
        table.setHorizontalHeaderLabels(["Voucher", "Month", "Year", "Total", "Paid", "Status"])
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.setAlternatingRowColors(True)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for ri, r in enumerate(rows):
            for ci, (key, fmt) in enumerate([
                ('voucher_id', '{}'), ('month', '{}'), ('year', '{}'),
                ('total_amount', 'Rs.{:,.0f}'), ('paid_amount', 'Rs.{:,.0f}'), ('status', '{}')
            ]):
                val = r.get(key, '')
                try:
                    text = fmt.format(val) if val else '—'
                except Exception:
                    text = str(val)
                item = QTableWidgetItem(text)
                if key == 'status':
                    item.setForeground(Qt.green if str(val).lower() == 'paid' else Qt.red)
                table.setItem(ri, ci, item)
            table.setRowHeight(ri, 34)
        l.addWidget(table)
        return w

    def _build_results_tab(self):
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(24, 20, 24, 20); l.setSpacing(12)

        rows = self.db.fetchall("""
            SELECT e.name as exam_name, sub.name as subject,
                   r.obtained_marks, r.total_marks
            FROM results r
            JOIN exams e ON r.exam_id = e.id
            JOIN subjects sub ON r.subject_id = sub.id
            WHERE r.student_id = ?
            ORDER BY e.id DESC, sub.name
        """, (self.student_id,))

        table = QTableWidget(len(rows), 5)
        table.setHorizontalHeaderLabels(["Exam", "Subject", "Obtained", "Total", "Grade"])
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.setAlternatingRowColors(True)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for ri, r in enumerate(rows):
            pct = (r.get('obtained_marks',0) / r.get('total_marks',1) * 100) if r.get('total_marks') else 0
            grade = self._grade(pct)
            for ci, val in [
                (0, r.get('exam_name','')), (1, r.get('subject','')),
                (2, str(r.get('obtained_marks',''))), (3, str(r.get('total_marks',''))),
                (4, grade)
            ]:
                item = QTableWidgetItem(val)
                item.setTextAlignment(Qt.AlignCenter)
                if ci == 4:
                    color = "#22c55e" if grade in ('A+','A') else "#f59e0b" if grade in ('B','C') else "#ef4444"
                    item.setForeground(Qt.green if grade in ('A+','A') else Qt.yellow if grade in ('B','C') else Qt.red)
                table.setItem(ri, ci, item)
            table.setRowHeight(ri, 34)
        l.addWidget(table)
        return w

    def _build_timetable_tab(self):
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(24, 20, 24, 20); l.setSpacing(12)
        s = self._get_student()
        DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
        PERIODS = [f"Period {i}" for i in range(1, 9)]
        grid = QTableWidget(len(PERIODS), len(DAYS))
        grid.setHorizontalHeaderLabels(DAYS)
        grid.setVerticalHeaderLabels(PERIODS)
        grid.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        grid.setAlternatingRowColors(True)
        grid.setEditTriggers(QAbstractItemView.NoEditTriggers)
        if s:
            rows = self.db.fetchall("""
                SELECT t.day, t.period, sub.name as subject_name
                FROM timetable t
                JOIN subjects sub ON t.subject_id = sub.id
                WHERE t.class_id = ?
            """, (s.get('class_id'),))
            for r in rows:
                day_idx = DAYS.index(r['day']) if r['day'] in DAYS else -1
                period_idx = (r['period'] or 1) - 1
                if 0 <= day_idx < 6 and 0 <= period_idx < 8:
                    item = QTableWidgetItem(r.get('subject_name','') or '')
                    item.setTextAlignment(Qt.AlignCenter)
                    grid.setItem(period_idx, day_idx, item)
        l.addWidget(grid)
        return w

    def _grade(self, pct):
        if pct >= 90: return "A+"
        if pct >= 80: return "A"
        if pct >= 70: return "B"
        if pct >= 60: return "C"
        if pct >= 50: return "D"
        return "F"

    def _print_report(self):
        """Generate a printable PDF report for parents."""
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib import colors
            from reportlab.lib.units import mm
            from reportlab.pdfgen import canvas as rlcanvas
            import os
            from datetime import datetime

            s = self._get_student()
            if not s: return

            OUTPUT_DIR = os.path.join(os.path.expanduser("~"), ".ai_eduhub_erp", "exports")
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            fname = f"parent_report_{s.get('student_id','std')}.pdf"
            path = os.path.join(OUTPUT_DIR, fname)

            c = rlcanvas.Canvas(path, pagesize=A4)
            w_pt, h_pt = A4

            school_info = self.db.fetchone("SELECT name, address, phone FROM school_info WHERE id=1")
            school_name = school_info['name'] if school_info else "AI EduHub ERP"

            # Header
            c.setFillColor(colors.HexColor("#1e3a8a"))
            c.rect(0, h_pt - 35*mm, w_pt, 35*mm, fill=1, stroke=0)
            c.setFillColor(colors.white)
            c.setFont("Helvetica-Bold", 18)
            c.drawCentredString(w_pt/2, h_pt - 18*mm, school_name.upper())
            c.setFont("Helvetica", 10)
            c.drawCentredString(w_pt/2, h_pt - 26*mm, "Student Progress Report — Parent Copy")

            y = h_pt - 45*mm
            c.setFillColor(colors.black)
            c.setFont("Helvetica-Bold", 13)
            c.drawString(15*mm, y, f"Student: {s.get('full_name','')}"); y -= 7*mm
            c.setFont("Helvetica", 11)
            c.drawString(15*mm, y, f"ID: {s.get('student_id','')}   Class: {s.get('class_name','')}   "
                                   f"Printed: {datetime.now().strftime('%d %b %Y')}"); y -= 10*mm

            # Attendance summary
            att = self.db.fetchone("""
                SELECT COUNT(*) as total,
                       SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) as present
                FROM attendance WHERE student_id=?
            """, (self.student_id,))
            total = att['total'] or 0; present = att['present'] or 0
            pct = (present/total*100) if total else 0
            c.setFont("Helvetica-Bold", 12); c.drawString(15*mm, y, "Attendance Summary"); y -= 6*mm
            c.setFont("Helvetica", 10)
            c.drawString(15*mm, y, f"Total Days: {total}   Present: {present}   Absent: {total-present}   "
                                   f"Attendance: {pct:.1f}%"); y -= 10*mm

            # Fee summary
            fee = self.db.fetchone("""
                SELECT SUM(total_amount) as due, SUM(paid_amount) as paid,
                       SUM(COALESCE(remaining_amount,total_amount-paid_amount)) as remaining
                FROM fee_vouchers WHERE student_id=?
            """, (self.student_id,))
            c.setFont("Helvetica-Bold", 12); c.drawString(15*mm, y, "Fee Summary"); y -= 6*mm
            c.setFont("Helvetica", 10)
            c.drawString(15*mm, y,
                f"Total Due: Rs.{fee.get('due',0) or 0:,.0f}   "
                f"Paid: Rs.{fee.get('paid',0) or 0:,.0f}   "
                f"Remaining: Rs.{fee.get('remaining',0) or 0:,.0f}"); y -= 10*mm

            # Results
            results = self.db.fetchall("""
                SELECT e.name as exam, sub.name as subject, r.obtained_marks, r.total_marks
                FROM results r JOIN exams e ON r.exam_id=e.id JOIN subjects sub ON r.subject_id=sub.id
                WHERE r.student_id=? ORDER BY e.id DESC
            """, (self.student_id,))
            if results:
                c.setFont("Helvetica-Bold", 12); c.drawString(15*mm, y, "Recent Results"); y -= 7*mm
                c.setFont("Helvetica-Bold", 9)
                for head, x in [("Exam",15*mm),("Subject",70*mm),("Obtained",130*mm),("Total",160*mm)]:
                    c.drawString(x, y, head)
                y -= 5*mm
                c.line(15*mm, y, w_pt-15*mm, y); y -= 5*mm
                c.setFont("Helvetica", 9)
                for r in results[:15]:
                    if y < 30*mm: c.showPage(); y = h_pt - 20*mm
                    c.drawString(15*mm, y, str(r.get('exam',''))[:25])
                    c.drawString(70*mm, y, str(r.get('subject',''))[:25])
                    c.drawString(130*mm, y, str(r.get('obtained_marks','')))
                    c.drawString(160*mm, y, str(r.get('total_marks','')))
                    y -= 6*mm

            c.setFont("Helvetica", 8)
            c.setFillColor(colors.gray)
            c.drawCentredString(w_pt/2, 10*mm, f"Generated by AI EduHub ERP on {datetime.now().strftime('%d %b %Y %I:%M %p')}")
            c.save()

            # Open file
            import subprocess, platform
            if platform.system() == "Windows":
                os.startfile(path)
            elif platform.system() == "Darwin":
                subprocess.call(["open", path])
            else:
                subprocess.call(["xdg-open", path])

            QMessageBox.information(self, "Report Saved", f"PDF saved to:\n{path}")
        except ImportError:
            QMessageBox.warning(self, "Missing Library",
                "ReportLab not installed.\nRun: pip install reportlab")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
