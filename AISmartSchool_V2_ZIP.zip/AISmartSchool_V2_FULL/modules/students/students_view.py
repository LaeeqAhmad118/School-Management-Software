"""Students Management"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt
from ui.components.widgets import SectionHeader, SearchBar, ModernTable, StatusBadge, shadow


class StudentsView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self._init_ui()
        self.refresh()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)

        header = SectionHeader("Students", "Manage all enrolled students")
        btn_add = header.add_button("Add Student", "btn_add", "➕")
        btn_add.clicked.connect(self.new_record)
        layout.addWidget(header)

        search_row = QHBoxLayout()
        self.search = SearchBar("Search students...")
        self.search.textChanged.connect(self._filter)
        self.class_filter = QComboBox()
        self.class_filter.setMinimumHeight(40)
        self.class_filter.addItem("All Classes")
        classes = self.db.fetchall("SELECT id,name FROM classes ORDER BY level,name")
        for c in classes:
            self.class_filter.addItem(c['name'], c['id'])
        self.class_filter.currentIndexChanged.connect(self.refresh)
        search_row.addWidget(self.search, 1)
        search_row.addWidget(self.class_filter)
        layout.addLayout(search_row)

        self.table = ModernTable(["Std ID","Name","Class","Section","Roll#","Father","Phone","Status","Actions"])
        self.table.set_fixed_column(0, 90)
        self.table.set_fixed_column(4, 70)
        self.table.set_fixed_column(7, 90)
        self.table.set_fixed_column(8, 150)
        layout.addWidget(self.table)

    def new_record(self):
        from core.demo_config import DEMO_MODE, DEMO_MAX_STUDENTS
        if DEMO_MODE:
            count = self.db.fetchone("SELECT COUNT(*) c FROM students") or {"c": 0}
            if count["c"] >= DEMO_MAX_STUDENTS:
                from ui.components.demo_dialogs import show_upgrade_dialog
                show_upgrade_dialog(self,
                    f"The Demo Edition is limited to {DEMO_MAX_STUDENTS} students.")
                return
        dlg = StudentDialog(self.db, self)
        if dlg.exec() == QDialog.Accepted:
            self.refresh()

    def refresh(self):
        self.table.clear_rows()
        class_id = self.class_filter.currentData() if self.class_filter.currentIndex() > 0 else None
        q = """SELECT s.*,c.name as class_name,sec.name as sec_name
               FROM students s
               LEFT JOIN classes c ON s.class_id=c.id
               LEFT JOIN sections sec ON s.section_id=sec.id
               WHERE 1=1"""
        params = []
        if class_id:
            q += " AND s.class_id=?"
            params.append(class_id)
        q += " ORDER BY s.id DESC"
        rows = self.db.fetchall(q, params)
        for r in rows:
            ri = self.table.rowCount()
            self.table.insertRow(ri)
            self.table.setItem(ri, 0, QTableWidgetItem(r.get('student_id','') or ''))
            self.table.setItem(ri, 1, QTableWidgetItem(r.get('full_name','') or ''))
            self.table.setItem(ri, 2, QTableWidgetItem(r.get('class_name','') or ''))
            self.table.setItem(ri, 3, QTableWidgetItem(r.get('sec_name','') or ''))
            self.table.setItem(ri, 4, QTableWidgetItem(r.get('roll_number','') or ''))
            self.table.setItem(ri, 5, QTableWidgetItem(r.get('father_name','') or ''))
            self.table.setItem(ri, 6, QTableWidgetItem(r.get('father_phone','') or ''))
            badge = StatusBadge(r.get('status','active'))
            self.table.setCellWidget(ri, 7, badge)
            acts = self._actions(r)
            self.table.setCellWidget(ri, 8, acts)
            self.table.setRowHeight(ri, 44)

    def _actions(self, r):
        from ui.components.widgets import icon_btn, cell_widget
        edit_btn = icon_btn("✏", "#2563eb", "Edit Student")
        edit_btn.clicked.connect(lambda ch, rid=r['id']: self._edit(rid))
        view_btn = icon_btn("👁", "#6b7280", "View Profile")
        view_btn.clicked.connect(lambda ch, rid=r['id']: self._view(rid))
        id_btn   = icon_btn("🪪", "#f97316", "Generate ID Card")
        id_btn.clicked.connect(lambda ch, rid=r['id']: self._gen_id_card(rid))
        # FIX 3: Admin can delete any student
        del_btn = icon_btn("🗑", "#ef4444", "Delete Student")
        del_btn.clicked.connect(lambda ch, rid=r['id'], name=r.get('full_name',''): self._delete_student(rid, name))
        return cell_widget([edit_btn, view_btn, id_btn, del_btn])

    def _edit(self, sid):
        r = self.db.fetchone("SELECT * FROM students WHERE id=?", (sid,))
        dlg = StudentDialog(self.db, self, r)
        if dlg.exec() == QDialog.Accepted:
            self.refresh()

    def _view(self, sid):
        from modules.students.student_profile import StudentProfileDialog
        r = self.db.fetchone("SELECT * FROM students WHERE id=?", (sid,))
        if r:
            dlg = StudentProfileDialog(self.db, r, self)
            dlg.exec()  # view-only dialog, return value not needed

    def _gen_id_card(self, sid):
        """Generate a single modern ID card for this student."""
        s = self.db.fetchone(
            """SELECT st.*, c.name as class_name, sec.name as section_name,
                      sess.name as session_name
               FROM students st
               LEFT JOIN classes c ON st.class_id=c.id
               LEFT JOIN sections sec ON st.section_id=sec.id
               LEFT JOIN academic_sessions sess ON st.session_id=sess.id
               WHERE st.id=?""", (sid,))
        if not s:
            QMessageBox.warning(self, "Not Found", "Student record could not be found.")
            return
        school_info = self.db.fetchone("SELECT * FROM school_info WHERE id=1") or {}
        try:
            from utils.pdf_generator import generate_id_cards
            path = generate_id_cards([s], school_info, auto_print=False)
            QMessageBox.information(self, "ID Card Generated",
                f"ID card generated for {s.get('full_name','this student')}.\nSaved: {path}")
        except Exception as e:
            QMessageBox.critical(self, "ID Card Generation Failed",
                f"Could not generate the ID card:\n\n{e}")

    def _delete_student(self, sid, name):
        """FIX 3: Admin can delete any student."""
        reply = QMessageBox.warning(
            self, "⚠️ Delete Student",
            f"Permanently delete student <b>{name}</b>?<br><br>"
            "This will also delete all their attendance, results, fees, "
            "and portal access records.",
            QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            return
        try:
            # Cascade-delete all linked data
            self.db.execute("DELETE FROM attendance       WHERE student_id=?", (sid,))
            self.db.execute("DELETE FROM results          WHERE student_id=?", (sid,))
            self.db.execute("DELETE FROM fee_vouchers     WHERE student_id=?", (sid,))
            self.db.execute("DELETE FROM parent_access    WHERE student_id=?", (sid,))
            self.db.execute("DELETE FROM behavior_logs    WHERE student_id=?", (sid,))
            self.db.execute("DELETE FROM certificates     WHERE student_id=?", (sid,))
            self.db.execute("DELETE FROM activities       WHERE student_id=?", (sid,))
            self.db.execute("DELETE FROM promotions       WHERE student_id=?", (sid,))
            self.db.execute("DELETE FROM alumni           WHERE student_id=?", (sid,))
            self.db.execute("DELETE FROM students         WHERE id=?",         (sid,))
            self.refresh()
            QMessageBox.information(self, "Deleted", f"Student '{name}' deleted.")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def _filter(self):
        text = self.search.text().lower()
        for row in range(self.table.rowCount()):
            if not text:
                self.table.setRowHidden(row, False)
                continue
            row_text = " ".join(
                self.table.item(row, c).text().lower()
                for c in range(7) if self.table.item(row, c)
            )
            self.table.setRowHidden(row, text not in row_text)


class StudentDialog(QDialog):
    def __init__(self, db, parent=None, data=None):
        super().__init__(parent)
        self.db = db
        self.data = data
        self.setWindowTitle("Add Student" if not data else "Edit Student")
        self.setMinimumSize(700, 580)
        self._init_ui()
        if data:
            self._populate(data)

    def _init_ui(self):
        layout = QVBoxLayout(self)
        tabs = QTabWidget()

        def scrollable_tab():
            """Return (scroll_area, inner_widget) — wrap tab content so it
            always scrolls instead of getting cut off."""
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.NoFrame)
            scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
            inner = QWidget()
            scroll.setWidget(inner)
            return scroll, inner

        scroll1, t1 = scrollable_tab()
        g = QGridLayout(t1)
        g.setContentsMargins(16, 16, 16, 16)
        g.setSpacing(10)

        def inp(ph=""):
            e = QLineEdit(); e.setPlaceholderText(ph); e.setMinimumHeight(38); return e
        def combo(items):
            c = QComboBox(); c.addItems(items); c.setMinimumHeight(38); return c

        self.full_name = inp("Full name")
        self.gender = combo(["Male","Female","Other"])
        self.dob = QDateEdit(); self.dob.setCalendarPopup(True); self.dob.setMinimumHeight(38)
        self.blood_group = combo(["A+","A-","B+","B-","AB+","AB-","O+","O-","Unknown"])
        self.religion = inp()
        self.address = QTextEdit(); self.address.setMaximumHeight(60)
        self.class_combo = QComboBox(); self.class_combo.setMinimumHeight(38)
        classes = self.db.fetchall("SELECT id,name FROM classes ORDER BY level")
        for c in classes: self.class_combo.addItem(c['name'], c['id'])
        self.section_combo = QComboBox(); self.section_combo.setMinimumHeight(38)
        self.class_combo.currentIndexChanged.connect(self._load_sections)
        self._load_sections()
        self.roll = inp("Roll number")
        self.status = combo(["active","inactive","transferred","alumni"])

        fields = [
            ("Full Name *", self.full_name), ("Gender", self.gender),
            ("Date of Birth", self.dob), ("Blood Group", self.blood_group),
            ("Religion", self.religion), ("Address", self.address),
            ("Class *", self.class_combo), ("Section", self.section_combo),
            ("Roll Number", self.roll), ("Status", self.status),
        ]
        for i, (label, widget) in enumerate(fields):
            lbl = QLabel(label); lbl.setMinimumWidth(130)
            g.addWidget(lbl, i, 0)
            g.addWidget(widget, i, 1, 1, 3)

        tabs.addTab(scroll1, "👤 Student Info")

        scroll2, t2 = scrollable_tab()
        g2 = QGridLayout(t2)
        g2.setContentsMargins(16, 16, 16, 16)
        g2.setSpacing(10)
        self.father_name = inp("Father's full name")
        self.father_phone = inp("03XXXXXXXXX")
        self.mother_name = inp("Mother's full name")
        self.mother_phone = inp("03XXXXXXXXX")
        self.parent_email = inp("Email")
        self.emergency = inp("Emergency contact")

        for i, (label, widget) in enumerate([
            ("Father Name *", self.father_name), ("Father Phone", self.father_phone),
            ("Mother Name", self.mother_name), ("Mother Phone", self.mother_phone),
            ("Email", self.parent_email), ("Emergency Contact", self.emergency),
        ]):
            lbl = QLabel(label); lbl.setMinimumWidth(130)
            g2.addWidget(lbl, i, 0)
            g2.addWidget(widget, i, 1, 1, 3)
        g2.setRowStretch(6, 1)
        tabs.addTab(scroll2, "👨‍👩‍👧 Parent Info")

        layout.addWidget(tabs)
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel = QPushButton("Cancel"); cancel.setObjectName("btn_cancel")
        cancel.clicked.connect(self.reject)
        save = QPushButton("Save Student"); save.setObjectName("btn_add")
        save.clicked.connect(self._save)
        btn_row.addWidget(cancel)
        btn_row.addWidget(save)
        layout.addLayout(btn_row)

    def _load_sections(self):
        class_id = self.class_combo.currentData()
        self.section_combo.clear()
        self.section_combo.addItem("Select Section", None)
        if class_id:
            secs = self.db.fetchall("SELECT id,name FROM sections WHERE class_id=?", (class_id,))
            for s in secs:
                self.section_combo.addItem(s['name'], s['id'])

    def _populate(self, d):
        self.full_name.setText(d.get('full_name','') or '')
        self.religion.setText(d.get('religion','') or '')
        self.address.setPlainText(d.get('address','') or '')
        self.roll.setText(d.get('roll_number','') or '')
        self.father_name.setText(d.get('father_name','') or '')
        self.father_phone.setText(d.get('father_phone','') or '')
        self.mother_name.setText(d.get('mother_name','') or '')
        self.mother_phone.setText(d.get('mother_phone','') or '')
        self.parent_email.setText(d.get('parent_email','') or '')
        self.emergency.setText(d.get('emergency_contact','') or '')

    def _save(self):
        if not self.full_name.text().strip():
            QMessageBox.warning(self, "Required", "Full name required.")
            return
        try:
            if self.data:
                self.db.execute("""
                    UPDATE students SET full_name=?,gender=?,blood_group=?,religion=?,
                    address=?,father_name=?,mother_name=?,father_phone=?,mother_phone=?,
                    parent_email=?,emergency_contact=?,class_id=?,section_id=?,
                    roll_number=?,status=? WHERE id=?
                """, (
                    self.full_name.text(), self.gender.currentText(),
                    self.blood_group.currentText(), self.religion.text(),
                    self.address.toPlainText(), self.father_name.text(),
                    self.mother_name.text(), self.father_phone.text(),
                    self.mother_phone.text(), self.parent_email.text(),
                    self.emergency.text(), self.class_combo.currentData(),
                    self.section_combo.currentData(), self.roll.text(),
                    self.status.currentText(), self.data['id']
                ))
            else:
                count = self.db.fetchone("SELECT COUNT(*) as c FROM students")
                sid = f"STU{(count['c']+1):04d}"
                self.db.execute("""
                    INSERT INTO students (student_id,full_name,gender,blood_group,religion,
                    address,father_name,mother_name,father_phone,mother_phone,parent_email,
                    emergency_contact,class_id,section_id,roll_number,status)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    sid, self.full_name.text(), self.gender.currentText(),
                    self.blood_group.currentText(), self.religion.text(),
                    self.address.toPlainText(), self.father_name.text(),
                    self.mother_name.text(), self.father_phone.text(),
                    self.mother_phone.text(), self.parent_email.text(),
                    self.emergency.text(), self.class_combo.currentData(),
                    self.section_combo.currentData(), self.roll.text(), 'active'
                ))
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
