"""Student Profile Dialog"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt


class StudentProfileDialog(QDialog):
    def __init__(self, db, student, parent=None):
        super().__init__(parent)
        self.db = db
        self.s = student
        self.setWindowTitle(f"Student Profile - {student.get('full_name','')}")
        self.setMinimumSize(700, 600)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        # Header card
        header = QFrame()
        header.setStyleSheet("background:#1e3a8a;border-radius:10px;padding:16px;")
        hl = QHBoxLayout(header)
        avatar = QLabel("👤")
        avatar.setStyleSheet("font-size:48px;background:#1d4ed8;border-radius:35px;padding:12px;")
        avatar.setFixedSize(70,70)
        avatar.setAlignment(Qt.AlignCenter)
        info = QVBoxLayout()
        name = QLabel(self.s.get('full_name',''))
        name.setStyleSheet("color:white;font-size:20px;font-weight:700;")
        sid = QLabel(f"ID: {self.s.get('student_id','')}  |  Roll: {self.s.get('roll_number','')}")
        sid.setStyleSheet("color:#bfdbfe;font-size:13px;")
        info.addWidget(name)
        info.addWidget(sid)
        hl.addWidget(avatar)
        hl.addLayout(info, 1)
        layout.addWidget(header)

        # Tabs
        tabs = QTabWidget()

        # Profile tab (scrollable)
        profile_scroll = QScrollArea()
        profile_scroll.setWidgetResizable(True)
        profile_scroll.setFrameShape(QFrame.NoFrame)
        profile_scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        profile = QWidget()
        profile_scroll.setWidget(profile)
        pg = QGridLayout(profile)
        pg.setContentsMargins(12, 12, 12, 12)
        pg.setSpacing(10)
        fields = [
            ("Gender", self.s.get('gender','')),
            ("Date of Birth", str(self.s.get('dob',''))),
            ("Blood Group", self.s.get('blood_group','')),
            ("Religion", self.s.get('religion','')),
            ("Address", self.s.get('address','')),
            ("Father Name", self.s.get('father_name','')),
            ("Father Phone", self.s.get('father_phone','')),
            ("Mother Name", self.s.get('mother_name','')),
            ("Parent Email", self.s.get('parent_email','')),
            ("Status", self.s.get('status','').upper()),
        ]
        for i, (k, v) in enumerate(fields):
            kl = QLabel(k)
            kl.setStyleSheet("color:#8b949e;font-weight:600;font-size:12px;")
            kl.setMinimumWidth(140)
            vl = QLabel(str(v) if v else "—")
            vl.setStyleSheet("color:#e6edf3;font-size:13px;")
            pg.addWidget(kl, i, 0)
            pg.addWidget(vl, i, 1)
        pg.setRowStretch(len(fields), 1)
        tabs.addTab(profile_scroll, "👤 Profile")

        # Attendance tab
        att_tab = QWidget()
        al = QVBoxLayout(att_tab)
        att_data = self.db.fetchall(
            "SELECT date,status FROM attendance WHERE student_id=? ORDER BY date DESC LIMIT 30",
            (self.s.get('id'),)
        )
        att_table = QTableWidget(len(att_data), 2)
        att_table.setHorizontalHeaderLabels(["Date","Status"])
        att_table.verticalHeader().setVisible(False)
        att_table.horizontalHeader().setStretchLastSection(True)
        for i, a in enumerate(att_data):
            att_table.setItem(i, 0, QTableWidgetItem(str(a['date'])))
            att_table.setItem(i, 1, QTableWidgetItem(a['status'].upper()))
        al.addWidget(att_table)
        tabs.addTab(att_tab, "✅ Attendance")

        # Fee History tab
        fee_tab = QWidget()
        fl = QVBoxLayout(fee_tab)
        fee_data = self.db.fetchall(
            "SELECT * FROM fee_vouchers WHERE student_id=? ORDER BY id DESC LIMIT 20",
            (self.s.get('id'),)
        )
        fee_table = QTableWidget(len(fee_data), 4)
        fee_table.setHorizontalHeaderLabels(["Voucher","Month","Amount","Status"])
        fee_table.verticalHeader().setVisible(False)
        fee_table.horizontalHeader().setStretchLastSection(True)
        for i, f in enumerate(fee_data):
            fee_table.setItem(i, 0, QTableWidgetItem(f.get('voucher_id','') or ''))
            fee_table.setItem(i, 1, QTableWidgetItem(f"{f.get('month','')} {f.get('year','')}"))
            fee_table.setItem(i, 2, QTableWidgetItem(f"Rs.{f.get('total_amount',0):,.0f}"))
            fee_table.setItem(i, 3, QTableWidgetItem((f.get('status','') or '').upper()))
        fl.addWidget(fee_table)
        tabs.addTab(fee_tab, "💰 Fee History")

        layout.addWidget(tabs)

        close = QPushButton("Close")
        close.setObjectName("btn_cancel")
        close.clicked.connect(self.accept)
        layout.addWidget(close, 0, Qt.AlignRight)
