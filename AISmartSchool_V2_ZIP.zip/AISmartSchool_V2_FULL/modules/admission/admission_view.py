"""
Admission Management Module V2
  - Documents upload tab (step 9)
  - Uses AdmissionDialogV2
"""
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTabWidget, QTableWidget, QTableWidgetItem, QDialog, QDialogButtonBox,
    QGridLayout, QLineEdit, QComboBox, QDateEdit, QTextEdit, QFileDialog,
    QMessageBox, QFrame, QScrollArea, QGroupBox, QCheckBox, QHeaderView,
    QInputDialog, QStackedWidget, QSizePolicy
)
from PySide6.QtCore import Qt, QDate, Signal
from PySide6.QtGui import QPixmap
from ui.components.widgets import (
    SectionHeader, SearchBar, ModernTable, StatusBadge, shadow
)
import os


def enroll_student_from_admission(db, admission_id):
    """
    Create a `students` record from an approved/confirmed admission so the
    student immediately appears in every module (Students, Fees, Attendance,
    Exams, Results, Timetable rolls, ID Cards, Parent Portal, ...) since they
    all read from the shared `students` table.

    Safe to call more than once — if a student already exists for this
    admission, it is returned unchanged instead of being duplicated.
    Returns the generated/existing student_id string.
    """
    from datetime import date
    existing = db.fetchone("SELECT student_id FROM students WHERE admission_id=?", (admission_id,))
    if existing:
        return existing["student_id"]

    adm = db.fetchone("SELECT * FROM admissions WHERE id=?", (admission_id,))
    if not adm:
        raise ValueError("Admission record not found.")

    from core.demo_config import DEMO_MODE, DEMO_MAX_STUDENTS
    if DEMO_MODE:
        count = db.fetchone("SELECT COUNT(*) as c FROM students") or {"c": 0}
        if count["c"] >= DEMO_MAX_STUDENTS:
            raise ValueError(
                f"Demo Edition limit reached: only {DEMO_MAX_STUDENTS} students "
                f"are allowed. Contact ltsoftwaresolutions090@gmail.com or "
                f"+92 335 7876516 (WhatsApp) to unlock the Full Version.")

    count = db.fetchone("SELECT COUNT(*) as c FROM students")
    student_id = f"STU{(count['c'] + 1):05d}"

    # ── Auto-generate roll number: next sequential number within the
    #    student's class (e.g. Class 5's students get roll 1, 2, 3, ...).
    #    Previously this column was never set, so it stayed blank forever.
    class_id = adm.get('applied_class_id')
    roll_number = "1"
    if class_id:
        existing_rolls = db.fetchall(
            "SELECT roll_number FROM students WHERE class_id=? AND roll_number IS NOT NULL AND roll_number != ''",
            (class_id,)
        )
        max_roll = 0
        for row in existing_rolls:
            try:
                max_roll = max(max_roll, int(row["roll_number"]))
            except (ValueError, TypeError):
                continue
        roll_number = str(max_roll + 1)

    db.execute("""
        INSERT INTO students
        (student_id, admission_id, full_name, gender, dob, b_form_cnic,
         blood_group, religion, address, photo_path, father_name, mother_name,
         father_cnic, father_occupation, father_phone, mother_phone,
         parent_email, emergency_contact, class_id, section_id, session_id,
         transport, roll_number)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        student_id, admission_id,
        adm.get('full_name'), adm.get('gender'), adm.get('dob'),
        adm.get('b_form_cnic'), adm.get('blood_group'), adm.get('religion'),
        adm.get('address'), adm.get('photo_path'),
        adm.get('father_name'), adm.get('mother_name'), adm.get('father_cnic'),
        adm.get('father_occupation'), adm.get('father_phone'), adm.get('mother_phone'),
        adm.get('parent_email'), adm.get('emergency_contact'),
        adm.get('applied_class_id'), adm.get('section_id'), adm.get('session_id'),
        adm.get('transport', 0), roll_number
    ))
    db.execute(
        "UPDATE admissions SET status='approved', approved_date=? WHERE id=?",
        (str(date.today()), admission_id)
    )
    return student_id


class AdmissionView(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db = db
        self.user = user
        self._init_ui()
        self.refresh_table()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(16)

        header = SectionHeader("Admissions", "Manage student admission applications")
        btn_new = header.add_button("New Admission", "btn_add", "➕")
        btn_new.clicked.connect(self.new_record)
        layout.addWidget(header)

        tabs = QTabWidget()
        layout.addWidget(tabs)

        # All admissions tab
        all_tab = QWidget()
        all_layout = QVBoxLayout(all_tab)
        search_row = QHBoxLayout()
        self.search = SearchBar("Search by name, ID, class...")
        self.search.textChanged.connect(self._filter_table)
        self.status_filter = QComboBox()
        self.status_filter.addItems(["All Status","pending","approved","rejected","draft"])
        self.status_filter.setMinimumHeight(40)
        self.status_filter.currentTextChanged.connect(self._filter_table)
        search_row.addWidget(self.search, 1)
        search_row.addWidget(self.status_filter)
        all_layout.addLayout(search_row)

        headers = ["Adm#","Name","Class","Section","Date","Status","Documents","Actions"]
        self.table = ModernTable(headers)
        self.table.set_fixed_column(0, 90)
        self.table.set_fixed_column(5, 100)
        self.table.set_fixed_column(6, 100)
        self.table.set_fixed_column(7, 180)
        all_layout.addWidget(self.table)
        tabs.addTab(all_tab, "📋  All Admissions")

        # Pending tab
        pend_tab = QWidget()
        pend_layout = QVBoxLayout(pend_tab)
        self.pending_table = ModernTable(["Adm#","Name","Class","Applied Date","Actions"])
        self.pending_table.set_fixed_column(0, 90)
        self.pending_table.set_fixed_column(4, 150)
        pend_layout.addWidget(self.pending_table)
        tabs.addTab(pend_tab, "⏳  Pending")

        # Approved tab
        appr_tab = QWidget()
        appr_layout = QVBoxLayout(appr_tab)
        self.approved_table = ModernTable(["Adm#","Name","Class","Student ID","Approved"])
        self.approved_table.set_fixed_column(0, 90)
        self.approved_table.set_fixed_column(3, 100)
        self.approved_table.set_fixed_column(4, 110)
        appr_layout.addWidget(self.approved_table)
        tabs.addTab(appr_tab, "✅  Approved")

    def new_record(self):
        dlg = AdmissionDialogV2(self.db, self)
        if dlg.exec() == QDialog.Accepted:
            self.refresh_table()

    def refresh(self):
        """Alias so MainWindow's navigate-refresh hook (which looks for a
        plain `refresh()` method) picks this view up too."""
        self.refresh_table()

    def refresh_table(self):
        self.table.clear_rows()
        self.pending_table.clear_rows()
        self.approved_table.clear_rows()

        rows = self.db.fetchall("""
            SELECT a.*, c.name as class_name, s.name as sec_name
            FROM admissions a
            LEFT JOIN classes c ON a.applied_class_id=c.id
            LEFT JOIN sections s ON a.section_id=s.id
            ORDER BY a.id DESC
        """)

        for r in rows:
            # Count documents
            doc_count = sum(1 for k in ["birth_cert_path","prev_result_path",
                                         "transfer_cert_path","parent_cnic_path"]
                            if r.get(k))

            row_idx = self.table.rowCount()
            self.table.insertRow(row_idx)
            self.table.setItem(row_idx, 0, QTableWidgetItem(r.get('admission_no') or ''))
            self.table.setItem(row_idx, 1, QTableWidgetItem(r.get('full_name') or ''))
            self.table.setItem(row_idx, 2, QTableWidgetItem(r.get('class_name') or ''))
            self.table.setItem(row_idx, 3, QTableWidgetItem(r.get('sec_name') or ''))
            self.table.setItem(row_idx, 4, QTableWidgetItem(r.get('applied_date') or ''))

            status_badge = StatusBadge(r.get('status','pending'))
            self.table.setCellWidget(row_idx, 5, status_badge)

            doc_lbl = QLabel(f"📎 {doc_count}/4")
            doc_lbl.setAlignment(Qt.AlignCenter)
            doc_lbl.setStyleSheet(f"color:{'#22c55e' if doc_count==4 else '#f59e0b'};font-weight:600;")
            self.table.setCellWidget(row_idx, 6, doc_lbl)

            # Actions
            action_w = QWidget()
            action_l = QHBoxLayout(action_w)
            action_l.setContentsMargins(4,2,4,2); action_l.setSpacing(4)

            if r.get('status') == 'pending':
                approve_btn = QPushButton("✅")
                approve_btn.setToolTip("Approve")
                approve_btn.setFixedSize(30,30)
                approve_btn.setStyleSheet("background:#22c55e22;color:#22c55e;border:none;border-radius:6px;font-size:13px;")
                approve_btn.clicked.connect(lambda ch, rid=r['id']: self._approve(rid))
                action_l.addWidget(approve_btn)

                reject_btn = QPushButton("❌")
                reject_btn.setToolTip("Reject")
                reject_btn.setFixedSize(30,30)
                reject_btn.setStyleSheet("background:#ef444422;color:#ef4444;border:none;border-radius:6px;font-size:13px;")
                reject_btn.clicked.connect(lambda ch, rid=r['id']: self._reject(rid))
                action_l.addWidget(reject_btn)

            view_btn = QPushButton("👁")
            view_btn.setToolTip("View Details")
            view_btn.setFixedSize(30,30)
            view_btn.setStyleSheet("background:#3b82f622;color:#3b82f6;border:none;border-radius:6px;font-size:13px;")
            view_btn.clicked.connect(lambda ch, row=r: self._view_details(row))
            action_l.addWidget(view_btn)
            action_l.addStretch()
            self.table.setCellWidget(row_idx, 7, action_w)

            # Pending table
            if r.get('status') == 'pending':
                pi = self.pending_table.rowCount()
                self.pending_table.insertRow(pi)
                self.pending_table.setItem(pi, 0, QTableWidgetItem(r.get('admission_no') or ''))
                self.pending_table.setItem(pi, 1, QTableWidgetItem(r.get('full_name') or ''))
                self.pending_table.setItem(pi, 2, QTableWidgetItem(r.get('class_name') or ''))
                self.pending_table.setItem(pi, 3, QTableWidgetItem(r.get('applied_date') or ''))
                ab = QPushButton("✅ Approve")
                ab.setStyleSheet("background:#22c55e22;color:#22c55e;border:none;border-radius:6px;padding:4px 8px;")
                ab.clicked.connect(lambda ch, rid=r['id']: self._approve(rid))
                self.pending_table.setCellWidget(pi, 4, ab)

            # Approved table
            if r.get('status') == 'approved':
                ai2 = self.approved_table.rowCount()
                self.approved_table.insertRow(ai2)
                self.approved_table.setItem(ai2, 0, QTableWidgetItem(r.get('admission_no') or ''))
                self.approved_table.setItem(ai2, 1, QTableWidgetItem(r.get('full_name') or ''))
                self.approved_table.setItem(ai2, 2, QTableWidgetItem(r.get('class_name') or ''))
                # Try to find enrolled student ID
                stu = self.db.fetchone("SELECT student_id FROM students WHERE admission_id=?", (r['id'],))
                self.approved_table.setItem(ai2, 3, QTableWidgetItem(stu.get('student_id','') if stu else ''))
                self.approved_table.setItem(ai2, 4, QTableWidgetItem(r.get('approved_date') or ''))

    def _filter_table(self):
        text   = self.search.text().lower()
        status = self.status_filter.currentText()
        for row in range(self.table.rowCount()):
            show = True
            if text:
                match = any(
                    (self.table.item(row, c) and text in self.table.item(row, c).text().lower())
                    for c in range(5)
                )
                show = match
            if status != "All Status":
                status_w = self.table.cellWidget(row, 5)
                if status_w and hasattr(status_w, 'text'):
                    if status not in status_w.text().lower():
                        show = False
            self.table.setRowHidden(row, not show)

    def _approve(self, admission_id):
        adm = self.db.fetchone("SELECT * FROM admissions WHERE id=?", (admission_id,))
        if not adm:
            return
        try:
            student_id = enroll_student_from_admission(self.db, admission_id)
            QMessageBox.information(self, "Approved",
                f"Student approved and enrolled!\nStudent ID: {student_id}\n\n"
                f"They now appear in Students, Fees, Attendance, Exams, Results, "
                f"Timetable and the Parent Portal.")
            self.refresh_table()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def _reject(self, admission_id):
        reason, ok = QInputDialog.getText(self, "Reject Admission", "Reason for rejection:")
        if ok:
            self.db.execute(
                "UPDATE admissions SET status='rejected', rejection_reason=? WHERE id=?",
                (reason, admission_id))
            self.refresh_table()

    def _view_details(self, row):
        info = "\n".join([
            f"Admission No: {row.get('admission_no','')}",
            f"Name: {row.get('full_name','')}",
            f"Class: {row.get('class_name','')}",
            f"Father: {row.get('father_name','')}",
            f"Phone: {row.get('father_phone','')}",
            f"Status: {row.get('status','')}",
            f"Birth Cert: {'✅' if row.get('birth_cert_path') else '❌'}",
            f"Prev Result: {'✅' if row.get('prev_result_path') else '❌'}",
            f"Transfer Cert: {'✅' if row.get('transfer_cert_path') else '❌'}",
            f"Parent CNIC: {'✅' if row.get('parent_cnic_path') else '❌'}",
        ])
        QMessageBox.information(self, "Admission Details", info)


class AdmissionDialogV2(QDialog):
    """3-Step New Admission Wizard — fully scrollable, actually saves to the
    database (previous version silently discarded all entered data).

    Step 1: Student Information
    Step 2: Parent / Guardian & Contact
    Step 3: Class, Session, Transport, Documents + Review
    """

    STEP_TITLES = [
        "Step 1 of 3 — Student Information",
        "Step 2 of 3 — Parent / Guardian & Contact",
        "Step 3 of 3 — Class, Documents & Review",
    ]

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self._doc_paths = {"birth_cert_path": "", "prev_result_path": "",
                            "transfer_cert_path": "", "parent_cnic_path": "",
                            "photo_path": ""}
        self.setWindowTitle("New Admission")
        self.setMinimumSize(640, 640)
        self.resize(680, 700)
        self._current_step = 0
        self._init_ui()

    # ── UI SCAFFOLD ──────────────────────────────────────────────────────
    def _init_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Step indicator header
        self._hdr = QLabel(self.STEP_TITLES[0])
        self._hdr.setStyleSheet(
            "background:#1d4ed8;color:white;font-size:14px;font-weight:800;"
            "padding:14px 20px;")
        root.addWidget(self._hdr)

        # Progress dots
        dots_row = QHBoxLayout(); dots_row.setContentsMargins(20, 10, 20, 10); dots_row.setSpacing(6)
        self._dots = []
        for i in range(3):
            d = QLabel(); d.setFixedHeight(5)
            d.setStyleSheet("background:#334155;border-radius:2px;")
            dots_row.addWidget(d, 1)
            self._dots.append(d)
        dots_wrap = QWidget(); dots_wrap.setLayout(dots_row)
        root.addWidget(dots_wrap)

        # Stacked steps — EACH wrapped in its own scroll area
        self._stack = QStackedWidget()
        self._stack.addWidget(self._build_step1())
        self._stack.addWidget(self._build_step2())
        self._stack.addWidget(self._build_step3())
        root.addWidget(self._stack, 1)

        # Footer navigation — always visible, never scrolls away
        footer = QFrame()
        footer.setObjectName("dialogFooter")
        footer.setStyleSheet(
            "QFrame#dialogFooter{background:transparent;border-top:1px solid #30363d;}"
            "QFrame#dialogFooter QLabel{background:transparent;border:none;}")
        frow = QHBoxLayout(footer)
        frow.setContentsMargins(20, 12, 20, 12)
        self._btn_cancel = QPushButton("Cancel")
        self._btn_cancel.setObjectName("btn_cancel")
        self._btn_cancel.clicked.connect(self.reject)
        self._btn_back = QPushButton("◀ Back")
        self._btn_back.clicked.connect(self._go_back)
        self._btn_back.setEnabled(False)
        self._btn_next = QPushButton("Next ▶")
        self._btn_next.setObjectName("btn_add")
        self._btn_next.clicked.connect(self._go_next)
        frow.addWidget(self._btn_cancel)
        frow.addStretch()
        frow.addWidget(self._btn_back)
        frow.addWidget(self._btn_next)
        root.addWidget(footer, 0)

        self._update_step_ui()

    def _scroll_page(self, build_fn):
        """Wrap a page's form content in its own vertical QScrollArea."""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        inner = QWidget()
        build_fn(inner)
        scroll.setWidget(inner)
        return scroll

    @staticmethod
    def _inp(placeholder=""):
        e = QLineEdit(); e.setPlaceholderText(placeholder); e.setMinimumHeight(38)
        return e

    @staticmethod
    def _combo(items):
        c = QComboBox(); c.addItems(items); c.setMinimumHeight(38)
        return c

    # ── STEP 1: Student Info ────────────────────────────────────────────
    def _build_step1(self):
        def build(inner):
            lay = QVBoxLayout(inner)
            lay.setContentsMargins(24, 20, 24, 20); lay.setSpacing(12)
            g = QGridLayout(); g.setSpacing(10)

            self.txt_name = self._inp("Full name")
            self.combo_gender = self._combo(["Male", "Female", "Other"])
            self.date_dob = QDateEdit(); self.date_dob.setCalendarPopup(True)
            self.date_dob.setMinimumHeight(38); self.date_dob.setDate(QDate.currentDate().addYears(-10))
            self.txt_bform = self._inp("B-Form / CNIC number")
            self.combo_blood = self._combo(["Unknown","A+","A-","B+","B-","AB+","AB-","O+","O-"])
            self.txt_religion = self._inp("Religion")
            self.txt_prev_school = self._inp("Previous school (if any)")
            self.txt_address = QTextEdit(); self.txt_address.setFixedHeight(70)
            self.txt_address.setPlaceholderText("Home address")

            for i, (label, widget) in enumerate([
                ("Full Name *", self.txt_name), ("Gender", self.combo_gender),
                ("Date of Birth", self.date_dob), ("B-Form / CNIC", self.txt_bform),
                ("Blood Group", self.combo_blood), ("Religion", self.txt_religion),
                ("Previous School", self.txt_prev_school),
            ]):
                lbl = QLabel(label); lbl.setMinimumWidth(130)
                g.addWidget(lbl, i, 0); g.addWidget(widget, i, 1)
            lay.addLayout(g)
            lay.addWidget(QLabel("Address"))
            lay.addWidget(self.txt_address)

            # Photo
            photo_row = QHBoxLayout()
            self._lbl_photo = QLabel("No photo selected")
            self._lbl_photo.setStyleSheet("color:#94a3b8;font-size:11px;")
            btn_photo = QPushButton("📷  Upload Student Photo")
            btn_photo.clicked.connect(lambda: self._pick_file("photo_path", self._lbl_photo,
                                       "Images (*.png *.jpg *.jpeg)"))
            photo_row.addWidget(btn_photo); photo_row.addWidget(self._lbl_photo, 1)
            lay.addLayout(photo_row)
            lay.addStretch()
        return self._scroll_page(build)

    # ── STEP 2: Parent / Guardian ───────────────────────────────────────
    def _build_step2(self):
        def build(inner):
            lay = QVBoxLayout(inner)
            lay.setContentsMargins(24, 20, 24, 20); lay.setSpacing(12)
            g = QGridLayout(); g.setSpacing(10)

            self.txt_father = self._inp("Father's full name")
            self.txt_father_cnic = self._inp("Father's CNIC")
            self.txt_father_occ = self._inp("Father's occupation")
            self.txt_phone = self._inp("Father's phone — 03XXXXXXXXX")
            self.txt_mother = self._inp("Mother's full name")
            self.txt_mother_phone = self._inp("Mother's phone")
            self.txt_email = self._inp("Parent email")
            self.txt_emergency = self._inp("Emergency contact number")

            for i, (label, widget) in enumerate([
                ("Father Name *", self.txt_father), ("Father CNIC", self.txt_father_cnic),
                ("Father Occupation", self.txt_father_occ), ("Father Phone *", self.txt_phone),
                ("Mother Name", self.txt_mother), ("Mother Phone", self.txt_mother_phone),
                ("Parent Email", self.txt_email), ("Emergency Contact", self.txt_emergency),
            ]):
                lbl = QLabel(label); lbl.setMinimumWidth(130)
                g.addWidget(lbl, i, 0); g.addWidget(widget, i, 1)
            lay.addLayout(g)
            lay.addStretch()
        return self._scroll_page(build)

    # ── STEP 3: Class / Session / Documents / Review ────────────────────
    def _build_step3(self):
        def build(inner):
            lay = QVBoxLayout(inner)
            lay.setContentsMargins(24, 20, 24, 20); lay.setSpacing(14)

            g = QGridLayout(); g.setSpacing(10)
            self.combo_class = QComboBox(); self.combo_class.setMinimumHeight(38)
            self._load_classes()
            self.combo_class.currentIndexChanged.connect(self._reload_sections)
            self.combo_section = QComboBox(); self.combo_section.setMinimumHeight(38)
            self.combo_session = QComboBox(); self.combo_session.setMinimumHeight(38)
            self._load_sessions()
            self.chk_transport = QCheckBox("Requires School Transport")

            for i, (label, widget) in enumerate([
                ("Applied Class *", self.combo_class), ("Section", self.combo_section),
                ("Session", self.combo_session),
            ]):
                lbl = QLabel(label); lbl.setMinimumWidth(130)
                g.addWidget(lbl, i, 0); g.addWidget(widget, i, 1)
            lay.addLayout(g)
            lay.addWidget(self.chk_transport)
            self._reload_sections()

            # Documents
            gdoc = QGroupBox("📎 Documents (optional but recommended)")
            gdoc.setStyleSheet(
                "QGroupBox{border:1px solid #334155;border-radius:8px;margin-top:8px;"
                "padding:10px;font-weight:700;}"
                "QGroupBox::title{left:10px;padding:0 4px;}")
            gv = QVBoxLayout(gdoc)
            self._doc_labels = {}
            for key, label in [
                ("birth_cert_path",    "Birth Certificate"),
                ("prev_result_path",   "Previous Result / Report Card"),
                ("transfer_cert_path", "Transfer Certificate"),
                ("parent_cnic_path",   "Parent CNIC Copy"),
            ]:
                row = QHBoxLayout()
                btn = QPushButton(f"📄  Upload {label}")
                lbl = QLabel("Not uploaded"); lbl.setStyleSheet("color:#94a3b8;font-size:11px;")
                btn.clicked.connect(lambda ch, k=key, l=lbl: self._pick_file(
                    k, l, "Documents (*.pdf *.png *.jpg *.jpeg)"))
                self._doc_labels[key] = lbl
                row.addWidget(btn); row.addWidget(lbl, 1)
                gv.addLayout(row)
            lay.addWidget(gdoc)

            self.chk_confirm_now = QCheckBox(
                "✅ Confirm & enroll student immediately (skip pending review)")
            self.chk_confirm_now.setStyleSheet("font-weight:700;color:#22c55e;")
            lay.addWidget(self.chk_confirm_now)

            lay.addStretch()
        return self._scroll_page(build)

    # ── helpers ──────────────────────────────────────────────────────────
    def _pick_file(self, key, label_widget, file_filter):
        path, _ = QFileDialog.getOpenFileName(self, "Select File", "", file_filter)
        if path:
            self._doc_paths[key] = path
            label_widget.setText(f"✅  {os.path.basename(path)}")
            label_widget.setStyleSheet("color:#22c55e;font-size:11px;")

    def _load_classes(self):
        try:
            for cls in self.db.fetchall("SELECT id, name FROM classes ORDER BY level"):
                self.combo_class.addItem(cls.get('name', ''), cls.get('id'))
        except Exception as e:
            print(f"Error loading classes: {e}")

    def _load_sessions(self):
        try:
            sessions = self.db.fetchall("SELECT id, name FROM academic_sessions ORDER BY id DESC")
            for s in sessions:
                self.combo_session.addItem(s.get('name', ''), s.get('id'))
        except Exception as e:
            print(f"Error loading sessions: {e}")

    def _reload_sections(self):
        self.combo_section.clear()
        self.combo_section.addItem("None", None)
        cid = self.combo_class.currentData()
        if cid:
            for s in self.db.fetchall("SELECT id,name FROM sections WHERE class_id=?", (cid,)):
                self.combo_section.addItem(s['name'], s['id'])

    # ── STEP NAVIGATION ──────────────────────────────────────────────────
    def _update_step_ui(self):
        self._hdr.setText(self.STEP_TITLES[self._current_step])
        for i, d in enumerate(self._dots):
            d.setStyleSheet(
                f"background:{'#22c55e' if i <= self._current_step else '#334155'};"
                f"border-radius:2px;")
        self._stack.setCurrentIndex(self._current_step)
        self._btn_back.setEnabled(self._current_step > 0)
        self._btn_next.setText("Submit Admission ✅" if self._current_step == 2 else "Next ▶")

    def _validate_step(self) -> bool:
        if self._current_step == 0 and not self.txt_name.text().strip():
            QMessageBox.warning(self, "Required", "Please enter the student's full name.")
            return False
        if self._current_step == 1:
            if not self.txt_father.text().strip():
                QMessageBox.warning(self, "Required", "Please enter the father's name.")
                return False
            if not self.txt_phone.text().strip():
                QMessageBox.warning(self, "Required", "Please enter a contact phone number.")
                return False
        if self._current_step == 2 and not self.combo_class.currentData():
            QMessageBox.warning(self, "Required", "Please select the applied class.")
            return False
        return True

    def _go_back(self):
        if self._current_step > 0:
            self._current_step -= 1
            self._update_step_ui()

    def _go_next(self):
        if not self._validate_step():
            return
        if self._current_step < 2:
            self._current_step += 1
            self._update_step_ui()
        else:
            self._save()

    # ── SAVE ─────────────────────────────────────────────────────────────
    def _next_admission_no(self) -> str:
        row = self.db.fetchone("SELECT COUNT(*) as c FROM admissions")
        year = QDate.currentDate().year()
        return f"ADM-{year}-{(row['c'] + 1):04d}"

    def _save(self):
        try:
            admission_no = self._next_admission_no()
            self.db.execute("""
                INSERT INTO admissions
                (admission_no, full_name, gender, dob, b_form_cnic, blood_group,
                 religion, address, previous_school, photo_path, father_name,
                 mother_name, father_cnic, father_occupation, father_phone,
                 mother_phone, parent_email, emergency_contact, applied_class_id,
                 section_id, session_id, transport, status,
                 birth_cert_path, prev_result_path, transfer_cert_path, parent_cnic_path)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',?,?,?,?)
            """, (
                admission_no, self.txt_name.text().strip(), self.combo_gender.currentText(),
                self.date_dob.date().toString("yyyy-MM-dd"), self.txt_bform.text().strip(),
                self.combo_blood.currentText(), self.txt_religion.text().strip(),
                self.txt_address.toPlainText().strip(), self.txt_prev_school.text().strip(),
                self._doc_paths["photo_path"], self.txt_father.text().strip(),
                self.txt_mother.text().strip(), self.txt_father_cnic.text().strip(),
                self.txt_father_occ.text().strip(), self.txt_phone.text().strip(),
                self.txt_mother_phone.text().strip(), self.txt_email.text().strip(),
                self.txt_emergency.text().strip(), self.combo_class.currentData(),
                self.combo_section.currentData(), self.combo_session.currentData(),
                1 if self.chk_transport.isChecked() else 0,
                self._doc_paths["birth_cert_path"], self._doc_paths["prev_result_path"],
                self._doc_paths["transfer_cert_path"], self._doc_paths["parent_cnic_path"],
            ))
            adm = self.db.fetchone("SELECT id FROM admissions WHERE admission_no=?", (admission_no,))
            admission_id = adm["id"]

            if self.chk_confirm_now.isChecked():
                student_id = enroll_student_from_admission(self.db, admission_id)
                QMessageBox.information(self, "Admission Confirmed",
                    f"Admission {admission_no} saved and student enrolled immediately!\n\n"
                    f"Student ID: {student_id}\n\n"
                    f"The student now appears in Students, Fees, Attendance, Exams, "
                    f"Results, Timetable and the Parent Portal.")
            else:
                QMessageBox.information(self, "Admission Saved",
                    f"Admission {admission_no} saved as PENDING.\n\n"
                    f"Approve it from the Pending tab to enroll the student.")
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Save Failed", f"Could not save admission:\n\n{e}")
