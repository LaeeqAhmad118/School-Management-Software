"""
Theme Manager - Global QSS Styling Engine
"""
import json
import os

THEMES = {
    "dark_blue": {
        "name": "Dark Blue",
        "bg_primary": "#0d1117",
        "bg_secondary": "#161b22",
        "bg_card": "#1c2128",
        "bg_sidebar": "#0d1117",
        "accent": "#2563eb",
        "accent_hover": "#1d4ed8",
        "accent_light": "#1e3a8a",
        "text_primary": "#e6edf3",
        "text_secondary": "#8b949e",
        "border": "#30363d",
        "success": "#22c55e",
        "warning": "#f59e0b",
        "danger": "#ef4444",
        "info": "#3b82f6",
        "purple": "#8b5cf6",
        "orange": "#f97316",
        "btn_add": "#22c55e",
        "btn_edit": "#2563eb",
        "btn_delete": "#ef4444",
        "btn_cancel": "#6b7280",
        "btn_print": "#8b5cf6",
        "btn_export": "#f97316",
    },
    "dark_purple": {
        "name": "Dark Purple",
        "bg_primary": "#0f0a1e",
        "bg_secondary": "#1a1033",
        "bg_card": "#231545",
        "bg_sidebar": "#0f0a1e",
        "accent": "#7c3aed",
        "accent_hover": "#6d28d9",
        "accent_light": "#4c1d95",
        "text_primary": "#ede9fe",
        "text_secondary": "#a78bfa",
        "border": "#3b2d6e",
        "success": "#22c55e",
        "warning": "#f59e0b",
        "danger": "#ef4444",
        "info": "#3b82f6",
        "purple": "#8b5cf6",
        "orange": "#f97316",
        "btn_add": "#22c55e",
        "btn_edit": "#7c3aed",
        "btn_delete": "#ef4444",
        "btn_cancel": "#6b7280",
        "btn_print": "#8b5cf6",
        "btn_export": "#f97316",
    },
    "emerald": {
        "name": "Emerald",
        "bg_primary": "#022c22",
        "bg_secondary": "#064e3b",
        "bg_card": "#065f46",
        "bg_sidebar": "#022c22",
        "accent": "#10b981",
        "accent_hover": "#059669",
        "accent_light": "#064e3b",
        "text_primary": "#ecfdf5",
        "text_secondary": "#6ee7b7",
        "border": "#065f46",
        "success": "#22c55e",
        "warning": "#f59e0b",
        "danger": "#ef4444",
        "info": "#3b82f6",
        "purple": "#8b5cf6",
        "orange": "#f97316",
        "btn_add": "#22c55e",
        "btn_edit": "#10b981",
        "btn_delete": "#ef4444",
        "btn_cancel": "#6b7280",
        "btn_print": "#8b5cf6",
        "btn_export": "#f97316",
    },
    "black_gold": {
        "name": "Black Gold Premium",
        "bg_primary": "#0a0800",
        "bg_secondary": "#1a1400",
        "bg_card": "#231c00",
        "bg_sidebar": "#0a0800",
        "accent": "#f59e0b",
        "accent_hover": "#d97706",
        "accent_light": "#78350f",
        "text_primary": "#fffbeb",
        "text_secondary": "#fcd34d",
        "border": "#44370a",
        "success": "#22c55e",
        "warning": "#f59e0b",
        "danger": "#ef4444",
        "info": "#3b82f6",
        "purple": "#8b5cf6",
        "orange": "#f97316",
        "btn_add": "#22c55e",
        "btn_edit": "#f59e0b",
        "btn_delete": "#ef4444",
        "btn_cancel": "#6b7280",
        "btn_print": "#8b5cf6",
        "btn_export": "#f97316",
    },
    "light": {
        "name": "Light",
        "bg_primary": "#f8fafc",
        "bg_secondary": "#ffffff",
        "bg_card": "#ffffff",
        "bg_sidebar": "#1e293b",
        "accent": "#2563eb",
        "accent_hover": "#1d4ed8",
        "accent_light": "#dbeafe",
        "text_primary": "#0f172a",
        "text_secondary": "#64748b",
        "border": "#e2e8f0",
        "success": "#22c55e",
        "warning": "#f59e0b",
        "danger": "#ef4444",
        "info": "#3b82f6",
        "purple": "#8b5cf6",
        "orange": "#f97316",
        "btn_add": "#22c55e",
        "btn_edit": "#2563eb",
        "btn_delete": "#ef4444",
        "btn_cancel": "#6b7280",
        "btn_print": "#8b5cf6",
        "btn_export": "#f97316",
    }
}


class ThemeManager:
    def __init__(self, app):
        self.app = app
        self.current_theme = "dark_blue"
        self._colors = THEMES["dark_blue"]

    def get_themes(self):
        return {k: v["name"] for k, v in THEMES.items()}

    def get_color(self, key):
        return self._colors.get(key, "#ffffff")

    def apply_theme(self, theme_id):
        if theme_id not in THEMES:
            theme_id = "dark_blue"
        self.current_theme = theme_id
        self._colors = THEMES[theme_id]
        c = self._colors
        qss = self._build_qss(c)
        self.app.setStyleSheet(qss)

    def _build_qss(self, c):
        return f"""
/* ===== GLOBAL ===== */
* {{
    font-family: "Segoe UI", "Arial", sans-serif;
}}

QMainWindow, QDialog, QWidget {{
    background-color: {c['bg_primary']};
    color: {c['text_primary']};
}}

/* Explicit label color — prevents Windows system palette override */
QLabel {{
    color: {c['text_primary']};
    background-color: transparent;
}}

/* Scroll areas */
QScrollArea {{
    background-color: transparent;
    border: none;
}}
QScrollArea > QWidget > QWidget {{
    background-color: transparent;
}}

/* ===== SIDEBAR ===== */
#sidebar {{
    background-color: {c['bg_sidebar']};
    border-right: 1px solid {c['border']};
    min-width: 220px;
    max-width: 220px;
}}

#sidebar_logo_area {{
    background-color: {c['accent']};
    padding: 20px;
    border-bottom: 2px solid {c['accent_hover']};
}}

#sidebar_btn {{
    background-color: transparent;
    color: {c['text_secondary']};
    border: none;
    border-radius: 8px;
    padding: 10px 16px;
    text-align: left;
    font-size: 13px;
    font-weight: 500;
    margin: 2px 8px;
}}

#sidebar_btn:hover {{
    background-color: {c['accent_light']};
    color: {c['text_primary']};
}}

#sidebar_btn[active="true"] {{
    background-color: {c['accent']};
    color: white;
    font-weight: 600;
}}

/* ===== CARDS ===== */
#card {{
    background-color: {c['bg_card']};
    border: 1px solid {c['border']};
    border-radius: 12px;
    padding: 16px;
}}

#stat_card {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
        stop:0 {c['bg_card']}, stop:1 {c['bg_secondary']});
    border: 1px solid {c['border']};
    border-radius: 12px;
    padding: 16px;
}}

/* ===== BUTTONS ===== */
QPushButton {{
    border-radius: 8px;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
    border: none;
    color: white;
    min-height: 36px;
}}

QPushButton:hover {{
    opacity: 0.9;
}}

QPushButton:pressed {{
    opacity: 0.8;
}}

QPushButton#btn_add, QPushButton[class="btn_add"] {{
    background-color: {c['btn_add']};
}}
QPushButton#btn_add:hover {{
    background-color: #16a34a;
}}

QPushButton#btn_edit, QPushButton[class="btn_edit"] {{
    background-color: {c['btn_edit']};
}}
QPushButton#btn_edit:hover {{
    background-color: {c['accent_hover']};
}}

QPushButton#btn_delete, QPushButton[class="btn_delete"] {{
    background-color: {c['btn_delete']};
}}
QPushButton#btn_delete:hover {{
    background-color: #dc2626;
}}

QPushButton#btn_cancel, QPushButton[class="btn_cancel"] {{
    background-color: {c['btn_cancel']};
}}

QPushButton#btn_print, QPushButton[class="btn_print"] {{
    background-color: {c['btn_print']};
}}

QPushButton#btn_export, QPushButton[class="btn_export"] {{
    background-color: {c['btn_export']};
}}

QPushButton#btn_primary {{
    background-color: {c['accent']};
}}
QPushButton#btn_primary:hover {{
    background-color: {c['accent_hover']};
}}

/* ===== INPUTS ===== */
QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox,
QDateEdit, QComboBox, QTimeEdit {{
    background-color: {c['bg_secondary']};
    color: {c['text_primary']};
    border: 1px solid {c['border']};
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 13px;
    min-height: 36px;
    selection-background-color: {c['accent']};
}}

QLineEdit:focus, QTextEdit:focus, QComboBox:focus,
QDateEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus {{
    border: 2px solid {c['accent']};
    outline: none;
}}

QLineEdit[error="true"] {{
    border: 2px solid {c['danger']};
}}

QComboBox::drop-down {{
    border: none;
    width: 30px;
}}

QComboBox QAbstractItemView {{
    background-color: {c['bg_card']};
    color: {c['text_primary']};
    border: 1px solid {c['border']};
    selection-background-color: {c['accent']};
    outline: none;
}}

/* ===== TABLES ===== */
QTableWidget, QTableView {{
    background-color: {c['bg_secondary']};
    color: {c['text_primary']};
    gridline-color: {c['border']};
    border: 1px solid {c['border']};
    border-radius: 8px;
    selection-background-color: {c['accent_light']};
    alternate-background-color: {c['bg_card']};
    font-size: 13px;
}}

QTableWidget::item, QTableView::item {{
    padding: 6px 12px;
    border: none;
}}

QTableWidget::item:selected, QTableView::item:selected {{
    background-color: {c['accent_light']};
    color: {c['text_primary']};
}}

QHeaderView::section {{
    background-color: {c['bg_card']};
    color: {c['text_secondary']};
    padding: 10px 12px;
    border: none;
    border-bottom: 2px solid {c['accent']};
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
}}

/* ===== TABS ===== */
QTabWidget::pane {{
    border: 1px solid {c['border']};
    border-radius: 8px;
    background-color: {c['bg_secondary']};
}}

QTabBar::tab {{
    background-color: {c['bg_card']};
    color: {c['text_secondary']};
    padding: 10px 20px;
    border: none;
    border-bottom: 2px solid transparent;
    font-size: 13px;
    font-weight: 500;
    min-width: 100px;
}}

QTabBar::tab:selected {{
    color: {c['accent']};
    border-bottom: 2px solid {c['accent']};
    background-color: {c['bg_secondary']};
    font-weight: 600;
}}

QTabBar::tab:hover {{
    color: {c['text_primary']};
    background-color: {c['bg_secondary']};
}}

/* ===== SCROLLBAR ===== */
QScrollBar:vertical {{
    background: {c['bg_secondary']};
    width: 8px;
    border-radius: 4px;
}}
QScrollBar::handle:vertical {{
    background: {c['border']};
    border-radius: 4px;
    min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{
    background: {c['text_secondary']};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0px;
}}

QScrollBar:horizontal {{
    background: {c['bg_secondary']};
    height: 8px;
    border-radius: 4px;
}}
QScrollBar::handle:horizontal {{
    background: {c['border']};
    border-radius: 4px;
}}

/* ===== LABELS ===== */
QLabel#title {{
    font-size: 22px;
    font-weight: 700;
    color: {c['text_primary']};
}}

QLabel#subtitle {{
    font-size: 14px;
    color: {c['text_secondary']};
}}

QLabel#section_title {{
    font-size: 15px;
    font-weight: 600;
    color: {c['accent']};
}}

/* ===== GROUP BOX ===== */
QGroupBox {{
    border: 1px solid {c['border']};
    border-radius: 8px;
    margin-top: 10px;
    padding: 12px;
    font-weight: 600;
    color: {c['text_secondary']};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 0 8px;
    color: {c['accent']};
}}

/* ===== MENU BAR ===== */
QMenuBar {{
    background-color: {c['bg_secondary']};
    color: {c['text_primary']};
    border-bottom: 1px solid {c['border']};
}}
QMenuBar::item:selected {{
    background-color: {c['accent']};
}}
QMenu {{
    background-color: {c['bg_card']};
    border: 1px solid {c['border']};
    color: {c['text_primary']};
}}
QMenu::item:selected {{
    background-color: {c['accent']};
}}

/* ===== STATUS BAR ===== */
QStatusBar {{
    background-color: {c['bg_secondary']};
    color: {c['text_secondary']};
    border-top: 1px solid {c['border']};
    padding: 4px;
}}

/* ===== PROGRESS BAR ===== */
QProgressBar {{
    background-color: {c['bg_card']};
    border: 1px solid {c['border']};
    border-radius: 4px;
    text-align: center;
    color: {c['text_primary']};
    height: 10px;
}}
QProgressBar::chunk {{
    background-color: {c['accent']};
    border-radius: 4px;
}}

/* ===== CHECKBOX & RADIO ===== */
QCheckBox, QRadioButton {{
    color: {c['text_primary']};
    spacing: 8px;
}}
QCheckBox::indicator {{
    width: 18px;
    height: 18px;
    border: 2px solid {c['border']};
    border-radius: 4px;
    background: {c['bg_secondary']};
}}
QCheckBox::indicator:checked {{
    background: {c['accent']};
    border-color: {c['accent']};
}}

/* ===== SPLITTER ===== */
QSplitter::handle {{
    background-color: {c['border']};
    width: 1px;
}}

/* ===== TOOLTIP ===== */
QToolTip {{
    background-color: {c['bg_card']};
    color: {c['text_primary']};
    border: 1px solid {c['border']};
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 12px;
}}

/* ===== DIALOG ===== */
QDialog {{
    background-color: {c['bg_primary']};
    border: 1px solid {c['border']};
    border-radius: 12px;
}}

/* ===== MESSAGE BOX ===== */
QMessageBox {{
    background-color: {c['bg_card']};
}}
"""
