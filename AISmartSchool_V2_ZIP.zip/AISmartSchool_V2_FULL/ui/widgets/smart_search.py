"""Smart Search Dialog - Ctrl+K"""
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QKeySequence, QShortcut


class SmartSearchDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Smart Search")
        self.setMinimumWidth(600)
        self.setMaximumHeight(500)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setStyleSheet("""
            QDialog { background:#161b22; border:2px solid #2563eb; border-radius:12px; }
        """)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16,16,16,16); layout.setSpacing(12)

        # Search input
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍  Search students, fees, results, staff...")
        self.search_input.setMinimumHeight(52)
        self.search_input.setStyleSheet("""
            QLineEdit { font-size:16px; border:2px solid #2563eb; border-radius:10px;
                        padding:10px 16px; background:#0d1117; color:white; }
        """)
        self.search_input.textChanged.connect(self._debounce_search)
        layout.addWidget(self.search_input)

        # Category row
        cat_row = QHBoxLayout()
        self._cat_btns = {}
        for cat in ["All","Students","Fees","Staff","Exams"]:
            btn = QPushButton(cat); btn.setCheckable(True)
            btn.setStyleSheet("""
                QPushButton { background:#1c2128; color:#8b949e; border:1px solid #30363d;
                              border-radius:6px; padding:4px 12px; font-size:12px; }
                QPushButton:checked { background:#2563eb; color:white; border-color:#2563eb; }
            """)
            btn.clicked.connect(lambda ch, c=cat: self._filter_category(c))
            if cat == "All": btn.setChecked(True)
            self._cat_btns[cat] = btn
            cat_row.addWidget(btn)
        cat_row.addStretch()
        layout.addLayout(cat_row)

        # Results
        self.results_list = QListWidget()
        self.results_list.setStyleSheet("""
            QListWidget { background:#0d1117; border:1px solid #30363d; border-radius:8px;
                          color:white; font-size:13px; }
            QListWidget::item { padding:10px 14px; border-bottom:1px solid #1c2128; }
            QListWidget::item:selected { background:#1e3a8a; }
        """)
        self.results_list.itemDoubleClicked.connect(self._open_result)
        layout.addWidget(self.results_list)

        hint = QLabel("Press Enter to open • Esc to close")
        hint.setStyleSheet("color:#30363d; font-size:11px;")
        hint.setAlignment(Qt.AlignCenter)
        layout.addWidget(hint)

        self._timer = QTimer(); self._timer.setSingleShot(True); self._timer.timeout.connect(self._do_search)
        self._current_results = []

        QShortcut(QKeySequence("Escape"), self, self.close)
        self.search_input.setFocus()

    def _debounce_search(self):
        self._timer.start(300)

    def _do_search(self):
        text = self.search_input.text().strip()
        self.results_list.clear()
        self._current_results = []
        if len(text) < 2:
            return
        results = []
        # Students
        students = self.db.fetchall("""
            SELECT 'student' as type, student_id as code, full_name as name,
                   father_name as detail FROM students WHERE full_name LIKE ? OR student_id LIKE ? LIMIT 10
        """, (f"%{text}%", f"%{text}%"))
        results.extend(students)
        # Fee vouchers
        vouchers = self.db.fetchall("""
            SELECT 'voucher' as type, v.voucher_id as code,
                   s.full_name as name, v.status as detail
            FROM fee_vouchers v JOIN students s ON v.student_id=s.id
            WHERE v.voucher_id LIKE ? OR s.full_name LIKE ? LIMIT 5
        """, (f"%{text}%", f"%{text}%"))
        results.extend(vouchers)
        # Staff
        staff = self.db.fetchall("""
            SELECT 'staff' as type, employee_id as code, full_name as name,
                   designation as detail FROM staff WHERE full_name LIKE ? LIMIT 5
        """, (f"%{text}%",))
        results.extend(staff)

        for r in results:
            icon = {"student":"👨‍🎓","voucher":"💰","staff":"👥"}.get(r['type'],"📄")
            item = QListWidgetItem(f"{icon}  {r.get('name','')}  [{r.get('code','')}]  —  {r.get('detail','') or ''}")
            item.setData(Qt.UserRole, r)
            self.results_list.addItem(item)
            self._current_results.append(r)

        if not results:
            self.results_list.addItem(QListWidgetItem("  No results found."))

    def _filter_category(self, cat):
        for k, b in self._cat_btns.items():
            b.setChecked(k == cat)
        self._do_search()

    def _open_result(self, item):
        data = item.data(Qt.UserRole)
        if data:
            QMessageBox.information(self, "Result",
                f"Type: {data.get('type','').title()}\nName: {data.get('name','')}\nID: {data.get('code','')}")
        self.close()
