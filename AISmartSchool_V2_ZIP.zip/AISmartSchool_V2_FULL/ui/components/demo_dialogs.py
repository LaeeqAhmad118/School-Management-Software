"""Demo Edition UI: the 'Upgrade to Full Version' dialog and a reusable
WhatsApp purchase card, both built around the WhatsApp brand so the
purchase path is the obvious, unmissable action."""
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QApplication, QFrame
)
from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from core.demo_config import (
    VENDOR_NAME, CONTACT_EMAIL, CONTACT_PHONE, CONTACT_WHATSAPP, WHATSAPP_LINK
)

WHATSAPP_GREEN = "#25D366"
WHATSAPP_GREEN_DARK = "#1DA851"


def _whatsapp_card(parent=None, compact=False) -> QFrame:
    """
    A branded WhatsApp purchase card — phone number front and center, one
    big green 'Chat on WhatsApp' button as the primary call to action.
    Reusable: the upgrade dialog embeds one, and it can also be dropped
    straight into a screen (e.g. the Dashboard) as a persistent banner.
    """
    card = QFrame(parent)
    card.setObjectName("whatsappCard")
    card.setStyleSheet(f"""
        QFrame#whatsappCard {{
            background: rgba(37, 211, 102, 0.10);
            border: 1.5px solid rgba(37, 211, 102, 0.45);
            border-radius: 14px;
        }}
        QFrame#whatsappCard QLabel {{
            background: transparent;
            border: none;
        }}
    """)
    lay = QVBoxLayout(card)
    lay.setContentsMargins(18, 16, 18, 16)
    lay.setSpacing(4 if compact else 6)

    top = QHBoxLayout()
    icon = QLabel("💬")
    icon.setStyleSheet("font-size:22px;background:transparent;")
    top.addWidget(icon)
    title = QLabel("Purchase the Full Version on WhatsApp")
    title.setWordWrap(True)
    title.setStyleSheet(
        f"color:{WHATSAPP_GREEN};font-size:13.5px;font-weight:800;background:transparent;")
    top.addWidget(title, 1)
    lay.addLayout(top)

    number_lbl = QLabel(CONTACT_PHONE)
    number_lbl.setStyleSheet(
        "color:#f8fafc;font-size:19px;font-weight:900;background:transparent;letter-spacing:0.5px;")
    lay.addWidget(number_lbl)

    if not compact:
        sub = QLabel(f"Message {VENDOR_NAME} — pricing, activation, and setup "
                      f"help, all in one chat.")
        sub.setWordWrap(True)
        sub.setStyleSheet("color:#9ca3af;font-size:11.5px;background:transparent;")
        lay.addWidget(sub)

    lay.addSpacing(4)
    btn_row = QHBoxLayout()
    btn_row.setSpacing(8)

    chat_btn = QPushButton("💬  Chat on WhatsApp")
    chat_btn.setCursor(Qt.PointingHandCursor)
    chat_btn.setFixedHeight(42)
    chat_btn.setStyleSheet(f"""
        QPushButton {{
            background: {WHATSAPP_GREEN}; color: white; border: none;
            border-radius: 10px; font-weight: 800; font-size: 13px; padding: 0 16px;
        }}
        QPushButton:hover {{ background: {WHATSAPP_GREEN_DARK}; }}
    """)
    chat_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(WHATSAPP_LINK)))
    btn_row.addWidget(chat_btn, 1)

    copy_btn = QPushButton("Copy Number")
    copy_btn.setCursor(Qt.PointingHandCursor)
    copy_btn.setFixedHeight(42)
    copy_btn.setStyleSheet(
        "QPushButton{background:rgba(255,255,255,0.06);color:#d1d5db;"
        "border:1px solid rgba(255,255,255,0.15);border-radius:10px;"
        "font-weight:700;font-size:12px;padding:0 14px;}"
        "QPushButton:hover{background:rgba(255,255,255,0.12);}")
    copy_btn.clicked.connect(lambda: QApplication.clipboard().setText(CONTACT_PHONE))
    btn_row.addWidget(copy_btn)

    lay.addLayout(btn_row)
    return card


def whatsapp_purchase_banner(parent=None) -> QFrame:
    """Public entry point for embedding the WhatsApp card directly into a
    screen (e.g. the Dashboard) rather than inside a popup dialog."""
    return _whatsapp_card(parent, compact=True)


def show_upgrade_dialog(parent=None, reason: str = ""):
    """
    Show the branded 'you've hit a Demo limit / upgrade' dialog. `reason`
    is an optional one-line explanation shown at the top (e.g. "The Demo
    Edition is limited to 20 students.").
    """
    dlg = QDialog(parent)
    dlg.setWindowTitle("Upgrade to Full Version")
    dlg.setMinimumWidth(440)
    dlg.setStyleSheet("""
        QDialog { background:#0f172a; }
        QLabel { color:#cbd5e1; }
    """)
    lay = QVBoxLayout(dlg)
    lay.setContentsMargins(28, 26, 28, 24)
    lay.setSpacing(10)

    badge = QLabel("🔒  DEMO VERSION")
    badge.setStyleSheet(
        "color:#fbbf24;background:rgba(217,119,6,0.15);border:1px solid rgba(217,119,6,0.4);"
        "border-radius:8px;padding:5px 12px;font-weight:800;font-size:11.5px;")
    badge.setFixedWidth(150)
    lay.addWidget(badge)

    if reason:
        r = QLabel(reason)
        r.setWordWrap(True)
        r.setStyleSheet("color:#f1f5f9;font-size:14px;font-weight:700;margin-top:6px;")
        lay.addWidget(r)

    sub = QLabel("Unlock unlimited students, staff, and every feature — including "
                  "Backup & Restore — with the Full Version.")
    sub.setWordWrap(True)
    sub.setStyleSheet("color:#94a3b8;font-size:12px;margin-top:2px;")
    lay.addWidget(sub)

    lay.addSpacing(12)

    # WhatsApp is the primary, unmissable purchase path.
    lay.addWidget(_whatsapp_card(dlg, compact=False))

    lay.addSpacing(10)
    line = QFrame(); line.setFrameShape(QFrame.HLine)
    line.setStyleSheet("background:#30363d;max-height:1px;border:none;")
    lay.addWidget(line)
    lay.addSpacing(8)

    email_row = QHBoxLayout()
    email_lbl = QLabel(f"📧  Or email: {CONTACT_EMAIL}")
    email_lbl.setStyleSheet("color:#94a3b8;font-size:11.5px;")
    email_row.addWidget(email_lbl, 1)
    email_copy = QPushButton("Copy")
    email_copy.setCursor(Qt.PointingHandCursor)
    email_copy.setFixedWidth(60)
    email_copy.setStyleSheet(
        "QPushButton{background:#1f2937;color:#cbd5e1;border:1px solid #30363d;"
        "border-radius:6px;padding:4px;font-size:11px;font-weight:700;}"
        "QPushButton:hover{background:#273449;}")
    email_copy.clicked.connect(lambda: QApplication.clipboard().setText(CONTACT_EMAIL))
    email_row.addWidget(email_copy)
    lay.addLayout(email_row)

    lay.addSpacing(14)
    close_btn = QPushButton("Continue with Demo")
    close_btn.setCursor(Qt.PointingHandCursor)
    close_btn.setFixedHeight(38)
    close_btn.setStyleSheet(
        "QPushButton{background:#1f2937;color:#e2e8f0;border:1px solid #30363d;"
        "border-radius:8px;font-weight:700;}"
        "QPushButton:hover{background:#273449;}")
    close_btn.clicked.connect(dlg.accept)
    lay.addWidget(close_btn)

    dlg.exec()
