"""
Reusable UI Components V4 — Zero QGraphicsOpacityEffect on child widgets.

Performance fix: NEVER call setGraphicsEffect() on a widget that contains
children. Qt must re-composite the entire subtree through an offscreen
buffer on every repaint event — including mouse-move. This is the cause
of the "cursor-move makes UI appear" bug.

Safe animation: number counter via QTimer text update only.
"""
from PySide6.QtWidgets import (
    QWidget, QLabel, QPushButton, QFrame, QHBoxLayout, QVBoxLayout,
    QGraphicsDropShadowEffect, QLineEdit, QSizePolicy, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView, QScrollArea
)
from core.color_utils import rgba
from PySide6.QtCore import Qt, QTimer, Signal, QSize, QPoint
from PySide6.QtGui import QColor, QFont, QIcon, QPixmap, QPainter


# ── Shadow (standalone, never attached to containers) ─────────────────────────
def shadow(widget=None, radius=10, alpha=35):
    """
    Lightweight drop shadow.
    widget=None → returns effect without attaching (caller attaches if safe).
    Only attach to simple leaf widgets, never to containers with many children.
    """
    eff = QGraphicsDropShadowEffect()
    eff.setBlurRadius(radius)
    eff.setOffset(0, 2)
    eff.setColor(QColor(0, 0, 0, alpha))
    if widget is not None:
        widget.setGraphicsEffect(eff)
    return eff


# ── Stat Card — number counter animation, NO graphics effect ──────────────────
class StatCard(QFrame):
    """
    Compact stat card with animated number counter.
    Animation = pure QTimer text update. Zero GPU/compositing cost.
    """
    def __init__(self, title, value, icon="", color="#2563eb", parent=None):
        super().__init__(parent)
        self.setObjectName("stat_card")
        self._color    = color
        self._timer    = None

        self._build(title, value, icon, color)

    def _build(self, title, value, icon, color):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(12)

        # Left: text block
        left = QVBoxLayout()
        left.setSpacing(3)

        self.title_lbl = QLabel(title)
        self.title_lbl.setStyleSheet(
            f"color:#94a3b8;font-size:11px;font-weight:700;"
            f"letter-spacing:0.5px;background:transparent;")

        self.value_lbl = QLabel(str(value))
        self.value_lbl.setStyleSheet(
            "color:#f1f5f9;font-size:24px;font-weight:800;background:transparent;")

        left.addWidget(self.title_lbl)
        left.addWidget(self.value_lbl)

        # Right: icon bubble
        icon_lbl = QLabel(icon)
        icon_lbl.setFixedSize(44, 44)
        icon_lbl.setAlignment(Qt.AlignCenter)
        icon_lbl.setStyleSheet(
            f"font-size:20px;background:{rgba(color, '22')};border-radius:10px;"
            f"border:1px solid {rgba(color, '44')};")

        layout.addLayout(left, 1)
        layout.addWidget(icon_lbl, 0, Qt.AlignVCenter)

        # Counter animation via QTimer (text only, no graphics effect)
        raw = str(value).replace(",","").replace("Rs.","").strip()
        try:
            target = int(float(raw))
            if target > 0:
                self._start_counter(target)
        except ValueError:
            pass

    def _start_counter(self, target):
        steps    = min(25, target)
        interval = 20   # ms
        step_val = target / steps
        current  = [0.0]

        self._timer = QTimer(self)
        def tick():
            current[0] = min(current[0] + step_val, target)
            self.value_lbl.setText(f"{int(current[0]):,}")
            if current[0] >= target:
                self._timer.stop()
        self._timer.timeout.connect(tick)
        self._timer.start(interval)


# ── Section Header ────────────────────────────────────────────────────────────
class SectionHeader(QWidget):
    def __init__(self, title, subtitle="", parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 10)

        left = QVBoxLayout()
        left.setSpacing(1)

        t = QLabel(title)
        t.setStyleSheet(
            "font-size:20px;font-weight:800;background:transparent;")
        left.addWidget(t)

        if subtitle:
            s = QLabel(subtitle)
            s.setStyleSheet(
                "font-size:12px;color:#8b949e;background:transparent;")
            left.addWidget(s)

        self.actions_layout = QHBoxLayout()
        self.actions_layout.setAlignment(Qt.AlignRight)
        self.actions_layout.setSpacing(6)

        layout.addLayout(left)
        layout.addStretch()
        layout.addLayout(self.actions_layout)

    def add_button(self, text, color_class="btn_primary", icon=""):
        btn = QPushButton(f"{icon} {text}".strip() if icon else text)
        btn.setObjectName(color_class)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setMinimumHeight(36)
        self.actions_layout.addWidget(btn)
        return btn


# ── Search Bar ────────────────────────────────────────────────────────────────
class SearchBar(QLineEdit):
    def __init__(self, placeholder="Search...", parent=None):
        super().__init__(parent)
        self.setPlaceholderText(f"🔍  {placeholder}")
        self.setMinimumWidth(260)
        self.setMinimumHeight(38)
        self.setStyleSheet("border-radius:19px;padding:6px 16px;font-size:13px;")


# ── Modern Table ──────────────────────────────────────────────────────────────
class ModernTable(QTableWidget):
    """High-performance table — bordered, modern styling.
    Deliberately has NO inline stylesheet: bordered/grid styling comes from
    the active theme's global QSS (see core/theme_manager.py) so it adapts
    correctly across every theme instead of always looking the same.

    All columns default to Stretch (evenly fill the full available width —
    "adjustable to screen", no huge dead gaps, no cramped overlapping
    columns). Call set_fixed_column(index, width) for any column that
    should stay a specific narrow width instead (IDs, status badges,
    action-icon columns)."""
    def __init__(self, headers, parent=None):
        super().__init__(parent)
        self.setColumnCount(len(headers))
        self.setHorizontalHeaderLabels(headers)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.verticalHeader().setVisible(False)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.horizontalHeader().setMinimumSectionSize(35)
        self.setShowGrid(True)
        self.setWordWrap(False)
        self.setSortingEnabled(True)
        self.setMinimumHeight(200)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.verticalHeader().setDefaultSectionSize(42)
        self.setFrameShape(QFrame.NoFrame)
        # NO setGraphicsEffect here — would cause repaint on every mouse-move

    def set_fixed_column(self, index: int, width: int):
        """Keep this one column at a fixed pixel width (e.g. an ID, a
        status badge, or an action-icons column) while every other,
        unspecified column keeps stretching to fill the rest evenly."""
        self.horizontalHeader().setSectionResizeMode(index, QHeaderView.Fixed)
        self.setColumnWidth(index, width)

    def add_row(self, data_list):
        row = self.rowCount()
        self.insertRow(row)
        for col, val in enumerate(data_list):
            item = QTableWidgetItem(str(val) if val is not None else "")
            item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
            self.setItem(row, col, item)
        return row

    def clear_rows(self):
        self.setRowCount(0)


# ── Status Badge ──────────────────────────────────────────────────────────────
class StatusBadge(QLabel):
    COLORS = {
        "active":    "#22c55e", "pending":  "#f59e0b", "paid":     "#22c55e",
        "unpaid":    "#ef4444", "overdue":  "#f97316", "partial":  "#3b82f6",
        "cancelled": "#6b7280", "approved": "#22c55e", "rejected": "#ef4444",
        "draft":     "#8b5cf6", "leave":    "#3b82f6", "present":  "#22c55e",
        "absent":    "#ef4444", "late":     "#f59e0b",
    }

    def __init__(self, status, parent=None):
        super().__init__(parent)
        self.set_status(status)
        self.setAlignment(Qt.AlignCenter)
        self.setFixedHeight(22)

    def set_status(self, status):
        key = (status or "").lower()
        fg  = self.COLORS.get(key, "#8b949e")
        self.setText((status or "N/A").upper())
        self.setStyleSheet(
            f"color:{fg};border:1px solid {rgba(fg, '55')};border-radius:11px;"
            f"padding:1px 8px;font-size:10px;font-weight:700;background:transparent;")


# ── Notification Bell ─────────────────────────────────────────────────────────
class NotificationBell(QPushButton):
    def __init__(self, parent=None):
        super().__init__("🔔", parent)
        self.setFixedSize(36, 36)
        self.setStyleSheet("""
            QPushButton {
                border-radius:18px;font-size:15px;
                background:transparent;border:1px solid #30363d;
            }
            QPushButton:hover { background:#1c2128; }
        """)
        self.count_lbl = QLabel("0", self)
        self.count_lbl.setFixedSize(16, 16)
        self.count_lbl.move(22, 0)
        self.count_lbl.setAlignment(Qt.AlignCenter)
        self.count_lbl.setStyleSheet(
            "background:#ef4444;color:white;border-radius:8px;"
            "font-size:9px;font-weight:700;")
        self.count_lbl.hide()

    def set_count(self, n):
        if n > 0:
            self.count_lbl.setText(str(min(n, 99)))
            self.count_lbl.show()
        else:
            self.count_lbl.hide()


# ── Utility helpers ───────────────────────────────────────────────────────────
def icon_btn(icon, color="#2563eb", tooltip=""):
    btn = QPushButton(icon)
    btn.setFixedSize(30, 30)
    btn.setCursor(Qt.PointingHandCursor)
    btn.setStyleSheet(
        f"QPushButton{{background:{rgba(color, '22')};color:{color};"
        f"border:1px solid {rgba(color, '66')};border-radius:6px;font-size:14px;padding:0px;}}"
        f"QPushButton:hover{{background:{rgba(color, '44')};border:1px solid {color};}}")
    if tooltip:
        btn.setToolTip(tooltip)
    return btn


def cell_widget(buttons):
    w = QWidget()
    l = QHBoxLayout(w)
    l.setContentsMargins(6, 2, 6, 2)
    l.setSpacing(5)
    for b in buttons:
        l.addWidget(b)
    l.addStretch()
    return w


# ── Scrollable Dialog Helper ───────────────────────────────────────────────────
def make_scrollable(dialog):
    """
    Turn any QDialog into a scrollable-content dialog.
    Usage:
        outer, content, footer = make_scrollable(self)
        # build your form INTO `content` (e.g. QFormLayout(content) or QVBoxLayout(content))
        # add Save/Cancel buttons to `footer` (QHBoxLayout) — footer stays pinned, always visible
    Returns (outer_layout, content_widget, footer_layout).
    """
    outer = QVBoxLayout(dialog)
    outer.setContentsMargins(0, 0, 0, 0)
    outer.setSpacing(0)

    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.NoFrame)
    scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")

    content = QWidget()
    content.setStyleSheet("background:transparent;")
    scroll.setWidget(content)
    outer.addWidget(scroll, 1)

    footer_wrap = QFrame()
    footer_wrap.setObjectName("dialogFooter")
    footer_wrap.setStyleSheet(
        "QFrame#dialogFooter{background:transparent;border-top:1px solid #30363d;}"
        "QFrame#dialogFooter QLabel{background:transparent;border:none;}")
    footer = QHBoxLayout(footer_wrap)
    footer.setContentsMargins(16, 12, 16, 12)
    outer.addWidget(footer_wrap, 0)

    return outer, content, footer


# Kept for backward compat — no longer applies opacity effects
def animate_fade_in(widget, duration=280):
    """DEPRECATED: was using QGraphicsOpacityEffect. Now a no-op."""
    return None


def animate_slide_up(widget, duration=300, offset=20):
    """Slide a widget up from offset pixels below."""
    from PySide6.QtCore import QPropertyAnimation, QEasingCurve
    orig = widget.pos()
    anim = QPropertyAnimation(widget, b"pos")
    anim.setDuration(duration)
    anim.setStartValue(QPoint(orig.x(), orig.y() + offset))
    anim.setEndValue(orig)
    anim.setEasingCurve(QEasingCurve.OutCubic)
    anim.start()
    return anim


# ── Falling Particles — gentle "falling" animation layer ──────────────────────
class FallingParticles(QWidget):
    """
    Soft particles that drift downward with a gentle horizontal sway,
    looping back to the top when they leave the bottom edge. Meant to be
    layered ON TOP of a flowing/orb background (e.g. AnimatedBackground in
    login_window.py) as a lightweight decorative overlay — never intercepts
    mouse events.

    Usage:
        particles = FallingParticles(parent_widget, count=26)
        particles.setGeometry(parent_widget.rect())
        particles.raise_()
    """
    import random as _random

    def __init__(self, parent=None, count=24, colors=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        colors = colors or ["#3b82f6", "#8b5cf6", "#06b6d4", "#22c55e", "#f8fafc"]
        r = self._random
        self._particles = []
        for _ in range(count):
            self._particles.append({
                "x": r.uniform(0, 1),
                "y": r.uniform(-1, 1),
                "size": r.uniform(2.5, 6.0),
                "speed": r.uniform(0.00035, 0.0011),
                "sway": r.uniform(0.15, 0.5),
                "phase": r.uniform(0, 6.283),
                "color": QColor(r.choice(colors)),
                "alpha": r.uniform(0.25, 0.75),
            })
        self._t = 0.0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(33)  # ~30fps — deliberately modest for a background layer

    def _tick(self):
        import math
        self._t += 1
        for p in self._particles:
            p["y"] += p["speed"]
            if p["y"] > 1.05:
                p["y"] = -0.05
        self.update()

    def paintEvent(self, event):
        import math
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        for particle in self._particles:
            sway_x = particle["x"] + math.sin(self._t * 0.02 + particle["phase"]) * (particle["sway"] * 0.03)
            cx = sway_x * w
            cy = particle["y"] * h
            c = QColor(particle["color"])
            c.setAlphaF(particle["alpha"])
            p.setBrush(c)
            p.setPen(Qt.NoPen)
            p.drawEllipse(QPoint(int(cx), int(cy)), particle["size"], particle["size"])
        p.end()

    def resizeEvent(self, event):
        super().resizeEvent(event)


# ── Donut Chart — pure QPainter, animated sweep, no external chart lib ────────
class DonutChart(QWidget):
    """
    Animated donut chart. Pass segments as [(label, value, color_hex), ...].
    Draws a ring with a rounded-cap sweep animation, a centered total/label,
    and an optional legend below.

    Usage:
        chart = DonutChart([
            ("Paid", 120, "#22c55e"),
            ("Pending", 40, "#f59e0b"),
            ("Overdue", 15, "#ef4444"),
        ], center_label="Vouchers")
    """
    def __init__(self, segments, center_label="", show_legend=True, parent=None):
        super().__init__(parent)
        self._segments = [s for s in segments if (s[1] or 0) > 0] or [("No data", 1, "#334155")]
        self._center_label = center_label
        self._show_legend = show_legend
        self._ratio = 0.0
        self.setMinimumHeight(200 if show_legend else 140)
        self.setMinimumWidth(160)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._step)
        self._timer.setInterval(16)
        QTimer.singleShot(120, self._timer.start)

    def _step(self):
        self._ratio = min(self._ratio + 0.045, 1.0)
        self.update()
        if self._ratio >= 1.0:
            self._timer.stop()

    def set_segments(self, segments):
        self._segments = [s for s in segments if (s[1] or 0) > 0] or [("No data", 1, "#334155")]
        self._ratio = 0.0
        self._timer.start()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        legend_h = 0
        if self._show_legend:
            legend_h = 18 * len(self._segments) + 6

        ring_area_h = self.height() - legend_h
        side = min(self.width(), ring_area_h) - 16
        side = max(side, 60)
        cx = (self.width() - side) / 2
        cy = (ring_area_h - side) / 2 + 4
        thickness = max(10, int(side * 0.22))

        total = sum(v for _, v, _ in self._segments) or 1
        start_angle = 90 * 16  # Qt angles are in 1/16th of a degree; start at 12 o'clock

        rect_x, rect_y, rect_w, rect_h = cx, cy, side, side

        for label, value, color in self._segments:
            sweep_full = -(value / total) * 360 * 16
            sweep = sweep_full * self._ratio
            pen = p.pen()
            pen.setColor(QColor(color))
            pen.setWidth(thickness)
            pen.setCapStyle(Qt.FlatCap)
            p.setPen(pen)
            p.drawArc(int(rect_x), int(rect_y), int(rect_w), int(rect_h),
                      int(start_angle), int(sweep))
            start_angle += sweep_full

        # Center label
        if self._center_label:
            p.setPen(QColor("#f1f5f9"))
            p.setFont(QFont("Segoe UI", max(9, int(side * 0.09)), QFont.Bold))
            p.drawText(int(rect_x), int(rect_y), int(rect_w), int(rect_h),
                       Qt.AlignCenter, str(self._center_label))

        # Legend
        if self._show_legend:
            ly = ring_area_h + 6
            p.setFont(QFont("Segoe UI", 8))
            for label, value, color in self._segments:
                p.setBrush(QColor(color))
                p.setPen(Qt.NoPen)
                p.drawEllipse(6, ly + 4, 9, 9)
                p.setPen(QColor("#cbd5e1"))
                pct = (value / total) * 100
                p.drawText(20, ly, self.width() - 24, 16, Qt.AlignVCenter | Qt.AlignLeft,
                           f"{label}  ({value:.0f} · {pct:.0f}%)")
                ly += 18
        p.end()
