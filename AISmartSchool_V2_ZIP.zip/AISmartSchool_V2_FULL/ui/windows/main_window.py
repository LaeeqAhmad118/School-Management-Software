"""
Main Window V3 — Zero QGraphicsOpacityEffect on child widgets.
Performance fix: startup uses setWindowOpacity(), navigation uses
geometry slide only. No offscreen compositing buffers on widgets.
"""
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel,
    QPushButton, QFrame, QStackedWidget, QScrollArea,
    QStatusBar, QMessageBox, QMenu, QToolButton, QApplication
)
from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QPoint
from PySide6.QtGui import QKeySequence, QShortcut, QFont, QAction, QPixmap

from ui.components.widgets import NotificationBell
from modules.dashboard.dashboard_view      import DashboardView
from modules.admission.admission_view      import AdmissionView
from modules.students.students_view        import StudentsView
from modules.fees.fees_view                import FeesView
from modules.attendance.attendance_view    import AttendanceView
from modules.exams.exams_view              import ExamsView
from modules.paper_creation.paper_creation_view import PaperCreationView
from modules.results.results_view          import ResultsView
from modules.timetable.timetable_view      import TimetableView
from modules.staff.staff_view              import StaffView
from modules.reports.reports_view          import ReportsView
from modules.ai.ai_view                    import AIView
from modules.settings.settings_view        import SettingsView
from modules.backup.backup_view            import BackupView
from modules.parent_portal.parent_portal_view import ParentPortalView
from modules.promotion.promotion_view       import PromotionView
from core.school_context import SchoolContext
from datetime import datetime

MENU_ITEMS = [
    ("dashboard",     "📊", "Dashboard",       ["admin","teacher","accounts","admission","exam","staff"]),
    ("admissions",    "📋", "Admissions",      ["admin","admission"]),
    ("students",      "👨‍🎓", "Students",        ["admin","admission","teacher"]),
    ("fees",          "💰", "Fee Management",  ["admin","accounts"]),
    ("attendance",    "✅", "Attendance",      ["admin","teacher"]),
    ("exams",            "📝", "Examinations",    ["admin","exam","teacher"]),
    ("paper_creation",   "📄", "Paper Creation",  ["admin","exam","teacher"]),
    ("results",          "🏆", "Results",         ["admin","exam","teacher"]),
    ("timetable",     "🗓", "Timetable",       ["admin","teacher"]),
    ("staff",         "👥", "Staff & HR",      ["admin"]),
    ("reports",       "📈", "Reports",         ["admin","accounts"]),
    ("ai",            "🤖", "AI Analytics",    ["admin"]),
    ("settings",      "⚙",  "Settings",        ["admin"]),
    ("promotion",     "🎓", "Promotion",       ["admin"]),
    ("backup",        "💾", "Backup",          ["admin"]),
    ("parent_portal", "👨‍👩‍👧", "Parent Portal", ["admin"]),
]


class MainWindow(QMainWindow):
    def __init__(self, db, theme_manager, user_data):
        super().__init__()
        self.db            = db
        self.theme_manager = theme_manager
        self.user          = user_data
        self.role          = user_data.get("role", "staff")
        self._views        = {}
        self._nav_anim     = None   # keep last nav animation alive

        self._ctx = SchoolContext.instance()
        self._ctx.load(db)
        self._ctx.school_updated.connect(self._on_school_updated)

        font = QFont("Segoe UI"); font.setPointSize(10); self.setFont(font)
        self.setWindowTitle(f"AI EduHub ERP — {self._ctx.name}")

        # Minimum size must never exceed what actually fits on-screen — a
        # fixed 1280x800 floor was TALLER than the usable area on common
        # laptop panels (e.g. 1366x768 leaves under 800px once the taskbar
        # is subtracted), which silently overrode showMaximized() and
        # clipped content with no way to shrink the window to compensate.
        screen = QApplication.primaryScreen()
        avail = screen.availableGeometry() if screen else None
        if avail is not None:
            min_w = min(1024, avail.width())
            min_h = min(650, avail.height())
        else:
            min_w, min_h = 1024, 650
        self.setMinimumSize(min_w, min_h)
        self.showMaximized()

        self._init_ui()
        self._setup_shortcuts()
        self._navigate("dashboard")
        self._start_clock()

        # Startup fade: window opacity only — GPU composited, zero widget cost
        self.setWindowOpacity(0.0)
        anim = QPropertyAnimation(self, b"windowOpacity")
        anim.setDuration(300)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.start()
        self._startup_anim = anim   # keep reference

    # ── Layout ────────────────────────────────────────────────────────────────
    def _init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # IMPORTANT: self.stack must exist before _build_sidebar()
        self.stack = QStackedWidget()

        self.sidebar = self._build_sidebar()
        root.addWidget(self.sidebar)

        right = QVBoxLayout()
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(0)
        right.addWidget(self._build_topbar())
        right.addWidget(self.stack, 1)

        container = QWidget()
        container.setLayout(right)
        root.addWidget(container, 1)

        self.status     = QStatusBar()
        self.setStatusBar(self.status)
        self.status_lbl = QLabel("Ready")
        self.clock_lbl  = QLabel()
        self.status.addWidget(self.status_lbl)
        self.status.addPermanentWidget(self.clock_lbl)

    # ── Sidebar ───────────────────────────────────────────────────────────────
    def _build_sidebar(self):
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(230)
        sidebar.setStyleSheet(
            "QFrame#sidebar{background:#0d1117;border-right:1px solid #30363d;}")

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Logo area
        self.logo_area = QFrame()
        self.logo_area.setObjectName("logoArea")
        self.logo_area.setFixedHeight(104)
        self.logo_area.setStyleSheet("""
            QFrame#logoArea {
                background:qlineargradient(x1:0,y1:0,x2:1,y2:1,
                    stop:0 #1e3a8a,stop:1 #2563eb);
                border-bottom:2px solid #1d4ed8;
            }
            QFrame#logoArea QLabel {
                background: transparent;
                border: none;
            }
        """)
        la = QHBoxLayout(self.logo_area)
        la.setContentsMargins(10, 8, 10, 8)
        la.setSpacing(8)

        self.sidebar_logo_lbl = QLabel()
        self.sidebar_logo_lbl.setFixedSize(50, 50)
        self.sidebar_logo_lbl.setAlignment(Qt.AlignCenter)
        self.sidebar_logo_lbl.setStyleSheet(
            "background:#1e3a8a;border-radius:25px;font-size:20px;"
            "font-weight:900;color:white;border:2px solid #60a5fa;")

        txt = QWidget()
        txt.setStyleSheet("background:transparent;")
        tv = QVBoxLayout(txt)
        tv.setContentsMargins(0, 0, 0, 0)
        tv.setSpacing(1)

        self.sidebar_name_lbl = QLabel()
        self.sidebar_name_lbl.setStyleSheet(
            "color:white;font-size:12px;font-weight:900;background:transparent;")
        self.sidebar_name_lbl.setWordWrap(True)

        sub = QLabel("AI EduHub ERP")
        sub.setStyleSheet(
            "color:#bfdbfe;font-size:8px;font-weight:600;"
            "letter-spacing:1px;background:transparent;")

        tv.addWidget(self.sidebar_name_lbl)
        tv.addWidget(sub)

        la.addWidget(self.sidebar_logo_lbl)
        la.addWidget(txt, 1)
        layout.addWidget(self.logo_area)
        self._refresh_sidebar_branding()

        # Nav scroll
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")

        nav_w = QWidget()
        nav_w.setStyleSheet("background:transparent;")
        nav_l = QVBoxLayout(nav_w)
        nav_l.setContentsMargins(0, 6, 0, 6)
        nav_l.setSpacing(1)

        self._nav_buttons = {}
        from core.demo_config import DEMO_MODE, DEMO_LOCKED_MODULES
        for key, icon, label, roles in MENU_ITEMS:
            if self.role not in roles:
                continue
            locked = DEMO_MODE and key in DEMO_LOCKED_MODULES
            label_text = f"  {icon}  {label}" + ("   🔒" if locked else "")
            btn = QPushButton(label_text)
            btn.setMinimumHeight(44)
            btn.setCursor(Qt.PointingHandCursor)
            lock_style = "color:#6b7280;" if locked else ""
            btn.setStyleSheet(f"""
                QPushButton {{
                    text-align:left;padding-left:16px;{lock_style}
                    color:{'#6b7280' if locked else '#8b949e'};
                    border:none;background:transparent;font-size:13px;
                }}
                QPushButton:hover {{background:#1c2128;color:{'#9ca3af' if locked else 'white'};}}
                QPushButton[active="true"] {{
                    background:#1e3a8a;color:white;
                    border-left:3px solid #2563eb;font-weight:700;
                }}
            """)
            if locked:
                btn.clicked.connect(lambda checked, k=key, n=DEMO_LOCKED_MODULES.get(key, ""):
                                     self._show_locked_module(n))
            else:
                btn.clicked.connect(lambda checked, k=key: self._navigate(k))
            self._nav_buttons[key] = btn
            nav_l.addWidget(btn)

        nav_l.addStretch(1)
        scroll.setWidget(nav_w)
        layout.addWidget(scroll, 1)

        # User profile bottom
        uf = QFrame()
        uf.setObjectName("userFooter")
        uf.setFixedHeight(68)
        uf.setStyleSheet(
            "QFrame#userFooter{border-top:1px solid #30363d;background:#161b22;}"
            "QFrame#userFooter QLabel{background:transparent;border:none;}")
        ul = QHBoxLayout(uf)
        ul.setContentsMargins(10, 8, 10, 8)
        ul.setSpacing(8)

        av = QLabel((self.user.get("full_name") or "U")[0].upper())
        av.setFixedSize(36, 36)
        av.setAlignment(Qt.AlignCenter)
        av.setStyleSheet(
            "background:#1e3a8a;border-radius:18px;font-size:15px;"
            "font-weight:700;color:white;")

        utxt = QWidget()
        utxt.setStyleSheet("background:transparent;")
        utv = QVBoxLayout(utxt)
        utv.setContentsMargins(0, 0, 0, 0)
        utv.setSpacing(0)

        fn = self.user.get("full_name","User")
        uname = QLabel(fn[:18] + ("…" if len(fn)>18 else ""))
        uname.setStyleSheet(
            "color:#e6edf3;font-size:12px;font-weight:700;background:transparent;")
        urole = QLabel(self.role.upper())
        urole.setStyleSheet("color:#8b949e;font-size:10px;background:transparent;")
        utv.addWidget(uname); utv.addWidget(urole)

        logout = QPushButton("⏻")
        logout.setFixedSize(28, 28)
        logout.setCursor(Qt.PointingHandCursor)
        logout.setToolTip("Logout")
        logout.setStyleSheet(
            "QPushButton{background:#1c2128;border:1px solid #30363d;"
            "border-radius:6px;color:#ef4444;font-size:13px;}"
            "QPushButton:hover{background:#ef4444;color:white;border:none;}")
        logout.clicked.connect(self._logout)

        ul.addWidget(av); ul.addWidget(utxt, 1); ul.addWidget(logout)
        layout.addWidget(uf)
        return sidebar

    def _refresh_sidebar_branding(self):
        name = self._ctx.name
        logo = self._ctx.logo_path
        self.sidebar_name_lbl.setText(name.upper()[:22])
        if logo:
            px = QPixmap(logo)
            if not px.isNull():
                px = px.scaled(46, 46, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                self.sidebar_logo_lbl.setPixmap(px)
                self.sidebar_logo_lbl.setText("")
                return
        self.sidebar_logo_lbl.setPixmap(QPixmap())
        self.sidebar_logo_lbl.setText(name[0].upper() if name else "S")

    def _on_school_updated(self, info):
        self._refresh_sidebar_branding()
        self.setWindowTitle(f"AI EduHub ERP — {self._ctx.name}")
        for view in self._views.values():
            if hasattr(view, "on_school_updated"):
                try:
                    view.on_school_updated(info)
                except Exception:
                    pass

    # ── Topbar ────────────────────────────────────────────────────────────────
    def _build_topbar(self):
        bar = QFrame()
        bar.setFixedHeight(54)
        bar.setObjectName("header_bar")
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(20, 0, 20, 0)

        self.page_title = QLabel("Dashboard")
        self.page_title.setStyleSheet(
            "color:#e6edf3;font-size:17px;font-weight:700;background:transparent;")

        search = QPushButton("🔍  Quick Search   Ctrl+K")
        search.setStyleSheet(
            "background:#1c2128;border:1px solid #30363d;border-radius:8px;"
            "color:#8b949e;padding:6px 14px;font-size:12px;")
        search.clicked.connect(self._open_search)

        self.notif_bell = NotificationBell()

        theme_btn = QToolButton()
        theme_btn.setText("🎨")
        theme_btn.setFixedSize(34, 34)
        theme_btn.setStyleSheet(
            "background:#1c2128;border:1px solid #30363d;border-radius:7px;font-size:15px;")
        theme_menu = QMenu(self)
        try:
            themes = (self.theme_manager.get_all_themes()
                      if hasattr(self.theme_manager, "get_all_themes")
                      else self.theme_manager.get_themes())
            for tid, tname in themes.items():
                act = QAction(tname, self)
                act.triggered.connect(lambda ch, t=tid: self.theme_manager.apply_theme(t))
                theme_menu.addAction(act)
        except Exception:
            pass
        theme_btn.setMenu(theme_menu)
        theme_btn.setPopupMode(QToolButton.InstantPopup)

        layout.addWidget(self.page_title)
        layout.addStretch()

        from core.demo_config import DEMO_MODE
        if DEMO_MODE:
            demo_badge = QLabel("🔒 DEMO")
            demo_badge.setStyleSheet(
                "color:#fbbf24;background:rgba(217,119,6,0.15);border:1px solid rgba(217,119,6,0.4);"
                "border-radius:7px;padding:5px 10px;font-weight:800;font-size:11px;")
            layout.addWidget(demo_badge)
            layout.addSpacing(6)
            upgrade_btn = QPushButton("💎 Upgrade")
            upgrade_btn.setCursor(Qt.PointingHandCursor)
            upgrade_btn.setStyleSheet(
                "QPushButton{background:#2563eb;color:white;border:none;border-radius:7px;"
                "padding:6px 12px;font-weight:700;font-size:11.5px;}"
                "QPushButton:hover{background:#1d4ed8;}")
            upgrade_btn.clicked.connect(self._show_upgrade_dialog)
            layout.addWidget(upgrade_btn)
            layout.addSpacing(8)

        layout.addWidget(search)
        layout.addSpacing(8)
        layout.addWidget(self.notif_bell)
        layout.addSpacing(8)
        layout.addWidget(theme_btn)
        return bar

    def _show_upgrade_dialog(self):
        from ui.components.demo_dialogs import show_upgrade_dialog
        show_upgrade_dialog(self, "Ready to unlock the Full Version?")

    def _show_locked_module(self, module_name: str):
        from ui.components.demo_dialogs import show_upgrade_dialog
        show_upgrade_dialog(self, f"🔒 {module_name} is available in the Full Version.")

    # ── Navigation — geometry slide, NO opacity effect ─────────────────────
    def _navigate(self, key):
        if key not in self._views:
            self._views[key] = self._create_view(key)
            self.stack.addWidget(self._views[key])

        new_widget = self._views[key]
        self.stack.setCurrentWidget(new_widget)

        # Cached views can go stale — e.g. a student enrolled via Admission
        # won't appear on the Students screen until it reloads from the DB.
        # Re-run whichever reload hook the view exposes every time we
        # navigate to it, not just the first time it's created.
        for method_name in ("refresh", "load_data", "_load_data", "reload"):
            method = getattr(new_widget, method_name, None)
            if callable(method):
                try:
                    method()
                except Exception:
                    pass
                break

        # Geometry slide — no QGraphicsOpacityEffect
        orig = new_widget.pos()
        anim = QPropertyAnimation(new_widget, b"pos")
        anim.setDuration(200)
        anim.setStartValue(QPoint(orig.x() + 30, orig.y()))
        anim.setEndValue(orig)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.start()
        self._nav_anim = anim   # keep alive

        self.current_module = key
        for k, btn in self._nav_buttons.items():
            btn.setProperty("active", "true" if k == key else "false")
            btn.style().unpolish(btn)
            btn.style().polish(btn)
        for k, icon, label, _ in MENU_ITEMS:
            if k == key:
                self.page_title.setText(f"{icon}  {label}")
                break
        self.status_lbl.setText(f"Module: {key.title()}")

    def _create_view(self, key):
        views = {
            "dashboard":     lambda: DashboardView(self.db, self.user),
            "admissions":    lambda: AdmissionView(self.db, self.user),
            "students":      lambda: StudentsView(self.db, self.user),
            "fees":          lambda: FeesView(self.db, self.user),
            "attendance":    lambda: AttendanceView(self.db, self.user),
            "exams":          lambda: ExamsView(self.db, self.user),
            "paper_creation": lambda: PaperCreationView(self.db, self.user),
            "results":        lambda: ResultsView(self.db, self.user),
            "timetable":     lambda: TimetableView(self.db, self.user),
            "staff":         lambda: StaffView(self.db, self.user),
            "reports":       lambda: ReportsView(self.db, self.user),
            "ai":            lambda: AIView(self.db, self.user),
            "settings":      lambda: SettingsView(self.db, self.user, self.theme_manager),
            "backup":        lambda: BackupView(self.db, self.user),
            "promotion":     lambda: PromotionView(self.db, self.user),
            "parent_portal": lambda: ParentPortalView(self.db, self.user),
        }
        f = views.get(key)
        return f() if f else QLabel(f"Module: {key}")

    # ── Misc ──────────────────────────────────────────────────────────────────
    def _setup_shortcuts(self):
        for seq, fn in [("Ctrl+D", lambda: self._navigate("dashboard")),
                         ("Ctrl+K", self._open_search),
                         ("Ctrl+L", self._logout)]:
            sc = QShortcut(QKeySequence(seq), self)
            sc.activated.connect(fn)

        # Zoom in/out/reset — the whole app's fonts, padding, borders, and
        # fixed control sizes scale together (see ThemeManager._scale_qss_px).
        # Bind both "Ctrl+=" (the physical key most keyboards use for "+"
        # without needing Shift) and "Ctrl++" / "Ctrl+Shift+=" so it works
        # the way people actually expect regardless of keyboard layout.
        for seq in ("Ctrl+=", "Ctrl++", "Ctrl+Shift+="):
            sc = QShortcut(QKeySequence(seq), self)
            sc.setContext(Qt.ApplicationShortcut)
            sc.activated.connect(self._zoom_in)
        for seq in ("Ctrl+-", "Ctrl+_"):
            sc = QShortcut(QKeySequence(seq), self)
            sc.setContext(Qt.ApplicationShortcut)
            sc.activated.connect(self._zoom_out)
        sc0 = QShortcut(QKeySequence("Ctrl+0"), self)
        sc0.setContext(Qt.ApplicationShortcut)
        sc0.activated.connect(self._zoom_reset)

    def _zoom_in(self):
        z = self.theme_manager.zoom_in()
        self._show_zoom_toast(z)

    def _zoom_out(self):
        z = self.theme_manager.zoom_out()
        self._show_zoom_toast(z)

    def _zoom_reset(self):
        z = self.theme_manager.zoom_reset()
        self._show_zoom_toast(z)

    def _show_zoom_toast(self, zoom_factor):
        try:
            self.status_lbl.setText(f"🔍 Zoom: {int(round(zoom_factor * 100))}%")
        except Exception:
            pass

    def _open_search(self):
        try:
            from ui.widgets.smart_search import SmartSearchDialog
            SmartSearchDialog(self.db, self).exec()
        except Exception:
            pass

    def _start_clock(self):
        self._clock_timer = QTimer()
        self._clock_timer.timeout.connect(self._tick)
        self._clock_timer.start(1000)
        self._tick()

    def _tick(self):
        self.clock_lbl.setText(
            datetime.now().strftime("  %A, %d %b %Y  |  %I:%M:%S %p  "))

    def _logout(self):
        if QMessageBox.question(
            self, "Logout", "Are you sure you want to logout?",
            QMessageBox.Yes | QMessageBox.No
        ) == QMessageBox.Yes:
            self.close()
            from ui.windows.login_window import LoginWindow
            self._login = LoginWindow(self.db, self.theme_manager)
            self._login.login_success.connect(
                lambda u: MainWindow(self.db, self.theme_manager, u).show())
            self._login.show()
