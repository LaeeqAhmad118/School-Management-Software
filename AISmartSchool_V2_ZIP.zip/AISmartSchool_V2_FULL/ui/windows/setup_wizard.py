"""
First-Launch Setup Wizard  — fixed UI
"""
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QComboBox, QFrame, QGridLayout, QScrollArea,
    QWidget, QMessageBox, QSizePolicy, QFileDialog
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont


LABEL_STYLE  = "color:#e6edf3; font-size:13px; font-weight:500;"
REQ_STYLE    = "color:#f87171; font-size:13px; font-weight:600;"
SECTION_STYLE= "color:#60a5fa; font-size:14px; font-weight:700; padding:4px 0;"
INPUT_STYLE  = """
    QLineEdit, QComboBox {
        background:#1c2128;
        color:#e6edf3;
        border:1px solid #30363d;
        border-radius:7px;
        padding:6px 12px;
        font-size:13px;
        min-height:38px;
    }
    QLineEdit:focus, QComboBox:focus {
        border:2px solid #2563eb;
    }
    QComboBox QAbstractItemView {
        background:#1c2128;
        color:#e6edf3;
        selection-background-color:#2563eb;
    }
"""


def _lbl(text, required=False):
    l = QLabel(text)
    l.setStyleSheet(REQ_STYLE if required else LABEL_STYLE)
    l.setMinimumWidth(140)
    l.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    return l


def _inp(placeholder=""):
    e = QLineEdit()
    e.setPlaceholderText(placeholder)
    e.setMinimumHeight(38)
    e.setStyleSheet(INPUT_STYLE)
    return e


class SetupWizard(QDialog):
    setup_complete = Signal()

    def __init__(self, db, theme_manager):
        super().__init__()
        self.db = db
        self.theme_manager = theme_manager
        self.setWindowTitle("AI EduHub ERP — Initial Setup")
        self.setMinimumSize(780, 640)
        self.setModal(True)
        self.setStyleSheet("QDialog { background:#0d1117; }")
        self._init_ui()

    # ──────────────────────────────────────────────────────────────────
    def _init_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Header ────────────────────────────────────────────────────
        header = QFrame()
        header.setFixedHeight(90)
        header.setStyleSheet("""
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 #1d4ed8, stop:1 #2563eb);
        """)
        hl = QVBoxLayout(header)
        hl.setContentsMargins(28, 14, 28, 14)
        hl.setSpacing(4)

        title = QLabel("🏫   School Management ERP")
        title.setStyleSheet(
            "color:white; font-size:20px; font-weight:700; background:transparent;"
        )
        sub = QLabel("Initial Setup  —  Configure your school system before first use")
        sub.setStyleSheet(
            "color:#bfdbfe; font-size:12px; background:transparent;"
        )
        hl.addWidget(title)
        hl.addWidget(sub)
        root.addWidget(header)

        # ── Scrollable form area ──────────────────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border:none; background:#0d1117; }")
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        form_widget = QWidget()
        form_widget.setStyleSheet("background:#0d1117;")
        form_layout = QVBoxLayout(form_widget)
        form_layout.setContentsMargins(32, 24, 32, 8)
        form_layout.setSpacing(0)

        # ── Section: School Information ───────────────────────────────
        form_layout.addWidget(self._section_header("🏫  School Information"))
        g1 = self._make_grid()

        self.school_name = _inp("e.g. Bright Future School")
        self.address     = _inp("Full address")
        self.phone       = _inp("e.g. 03001234567")
        self.email       = _inp("school@email.com")
        self.principal   = _inp("Principal name")
        self.city        = _inp("City")
        self.session     = _inp("e.g. 2024-2025")

        self.theme_combo = QComboBox()
        self.theme_combo.setMinimumHeight(38)
        self.theme_combo.setStyleSheet(INPUT_STYLE)
        for k, v in {
            "dark_blue": "🌑  Dark Blue",
            "dark_purple": "🟣  Dark Purple",
            "emerald": "🟢  Emerald",
            "black_gold": "⭐  Black Gold Premium",
            "light": "☀️  Light",
        }.items():
            self.theme_combo.addItem(v, k)

        rows1 = [
            (_lbl("School Name", True),   self.school_name, None,              None),
            (_lbl("Address"),             self.address,     None,              None),
            (_lbl("Phone"),               self.phone,       _lbl("Email"),     self.email),
            (_lbl("Principal"),           self.principal,   _lbl("City"),      self.city),
            (_lbl("Academic Session", True), self.session,  _lbl("Theme"),     self.theme_combo),
        ]
        self._fill_grid(g1, rows1)
        form_layout.addLayout(g1)


        # ── Logo upload row
        logo_row = QHBoxLayout(); logo_row.setSpacing(8)
        logo_lbl_text = QLabel("School Logo")
        logo_lbl_text.setStyleSheet(LABEL_STYLE); logo_lbl_text.setMinimumWidth(140)
        logo_lbl_text.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self._logo_path = ""
        self.logo_preview = QLabel("No logo selected (optional)")
        self.logo_preview.setStyleSheet("color:#8b949e;font-size:12px;background:#1c2128;"
                                        "border:1px solid #30363d;border-radius:7px;padding:6px 12px;")
        self.logo_preview.setMinimumHeight(38)
        logo_btn = QPushButton("📁  Browse Logo")
        logo_btn.setMinimumHeight(38)
        logo_btn.setStyleSheet("background:#1c2128;color:#60a5fa;border:1px solid #30363d;"
                               "border-radius:7px;padding:6px 14px;font-size:12px;")
        logo_btn.setCursor(Qt.PointingHandCursor)
        logo_btn.clicked.connect(self._browse_logo)
        logo_row.addWidget(logo_lbl_text)
        logo_row.addWidget(self.logo_preview, 1)
        logo_row.addWidget(logo_btn)
        form_layout.addLayout(logo_row)
        form_layout.addSpacing(4)

        # ── Divider ───────────────────────────────────────────────────
        form_layout.addSpacing(20)
        div = QFrame()
        div.setFrameShape(QFrame.HLine)
        div.setStyleSheet("color:#30363d; background:#30363d; max-height:1px;")
        form_layout.addWidget(div)
        form_layout.addSpacing(12)

        # ── Section: Admin Account ────────────────────────────────────
        form_layout.addWidget(self._section_header("🔐  Administrator Account"))
        g2 = self._make_grid()

        self.admin_name = _inp("Full name of administrator")
        self.admin_user = _inp("admin")
        self.admin_pass = QLineEdit()
        self.admin_pass.setEchoMode(QLineEdit.Password)
        self.admin_pass.setPlaceholderText("Minimum 6 characters")
        self.admin_pass.setMinimumHeight(38)
        self.admin_pass.setStyleSheet(INPUT_STYLE)

        self.admin_email = _inp("admin@school.com  (optional)")

        rows2 = [
            (_lbl("Full Name", True),  self.admin_name,  None,               None),
            (_lbl("Username", True),   self.admin_user,  _lbl("Password", True), self.admin_pass),
            (_lbl("Email"),            self.admin_email, None,               None),
        ]
        self._fill_grid(g2, rows2)
        form_layout.addLayout(g2)
        form_layout.addStretch()

        scroll.setWidget(form_widget)
        root.addWidget(scroll, 1)

        # ── Footer buttons ────────────────────────────────────────────
        footer = QFrame()
        footer.setFixedHeight(68)
        footer.setStyleSheet("background:#161b22; border-top:1px solid #30363d;")
        fl = QHBoxLayout(footer)
        fl.setContentsMargins(28, 12, 28, 12)

        hint = QLabel("* Required fields")
        hint.setStyleSheet("color:#6b7280; font-size:11px;")
        fl.addWidget(hint)
        fl.addStretch()

        self.btn_complete = QPushButton("  ✓   Complete Setup")
        self.btn_complete.setMinimumWidth(200)
        self.btn_complete.setMinimumHeight(44)
        self.btn_complete.setCursor(Qt.PointingHandCursor)
        self.btn_complete.setStyleSheet("""
            QPushButton {
                background:#22c55e; color:white;
                font-size:14px; font-weight:700;
                border-radius:8px; border:none;
            }
            QPushButton:hover  { background:#16a34a; }
            QPushButton:pressed{ background:#15803d; }
        """)
        self.btn_complete.clicked.connect(self._complete)
        fl.addWidget(self.btn_complete)
        root.addWidget(footer)

    # ── Helpers ───────────────────────────────────────────────────────

    def _browse_logo(self):
        import os, shutil
        path, _ = QFileDialog.getOpenFileName(
            self, "Select School Logo",
            os.path.expanduser("~"),
            "Images (*.png *.jpg *.jpeg *.svg *.bmp)")
        if path:
            # Copy to permanent location
            logo_dir = os.path.join(os.path.expanduser("~"), ".ai_eduhub_erp", "logos")
            os.makedirs(logo_dir, exist_ok=True)
            ext = os.path.splitext(path)[1]
            dest = os.path.join(logo_dir, f"school_logo{ext}")
            shutil.copy2(path, dest)
            self._logo_path = dest
            name = os.path.basename(path)
            self.logo_preview.setText(f"✅  {name}")
            self.logo_preview.setStyleSheet(
                "color:#22c55e;font-size:12px;background:#1c2128;"
                "border:1px solid rgba(34,197,94,0.267);border-radius:7px;padding:6px 12px;")

    def _section_header(self, text):
        lbl = QLabel(text)
        lbl.setStyleSheet(SECTION_STYLE)
        lbl.setContentsMargins(0, 8, 0, 10)
        return lbl

    def _make_grid(self):
        g = QGridLayout()
        g.setSpacing(10)
        g.setColumnMinimumWidth(0, 140)
        g.setColumnMinimumWidth(2, 120)
        g.setColumnStretch(1, 2)
        g.setColumnStretch(3, 2)
        return g

    def _fill_grid(self, grid, rows):
        for r, (l1, w1, l2, w2) in enumerate(rows):
            grid.addWidget(l1, r, 0)
            if l2 is None:
                grid.addWidget(w1, r, 1, 1, 3)
            else:
                grid.addWidget(w1, r, 1)
                grid.addWidget(l2, r, 2)
                grid.addWidget(w2, r, 3)

    # ── Save ──────────────────────────────────────────────────────────
    def _complete(self):
        errs = []
        if not self.school_name.text().strip():
            errs.append("School Name")
        if not self.session.text().strip():
            errs.append("Academic Session")
        if not self.admin_name.text().strip():
            errs.append("Admin Full Name")
        if not self.admin_user.text().strip():
            errs.append("Admin Username")
        if len(self.admin_pass.text()) < 6:
            errs.append("Password (min 6 characters)")

        if errs:
            QMessageBox.warning(
                self, "Required Fields Missing",
                "Please fill in:\n• " + "\n• ".join(errs)
            )
            return

        try:
            self.db.execute(
                "INSERT OR REPLACE INTO school_info "
                "(id,name,address,phone,email,principal,city,logo_path) VALUES (1,?,?,?,?,?,?,?)",
                (
                    self.school_name.text().strip(),
                    self.address.text().strip(),
                    self.phone.text().strip(),
                    self.email.text().strip(),
                    self.principal.text().strip(),
                    self.city.text().strip(),
                    self._logo_path,
                )
            )
            self.db.execute(
                "INSERT INTO academic_sessions (name,is_active) VALUES (?,1)",
                (self.session.text().strip(),)
            )
            self.db.create_admin(
                self.admin_user.text().strip(),
                self.admin_pass.text(),
                self.admin_name.text().strip(),
                self.admin_email.text().strip(),
            )
            self.db.execute(
                "INSERT OR REPLACE INTO app_config (key,value) VALUES ('theme',?)",
                (self.theme_combo.currentData(),)
            )
            self.db.mark_setup_complete()

            # Apply selected theme immediately
            self.theme_manager.apply_theme(self.theme_combo.currentData())

            QMessageBox.information(
                self, "Setup Complete",
                "✓  Setup completed successfully!\n\nYou can now log in with your admin credentials."
            )
            self.setup_complete.emit()
            self.accept()

        except Exception as e:
            QMessageBox.critical(self, "Setup Error", f"Setup failed:\n\n{e}")
