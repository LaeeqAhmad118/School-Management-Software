"""
Login Window — AI EduHub ERP
==============================================================
Modern, animated, fully-offline login screen.

Features:
  - Split-screen layout: animated branding panel + glass login card
  - Floating gradient blobs + particle animation in the background
  - Smooth fade-in / slide-in entrance animation
  - Shake animation on invalid login
  - "Remember Me" — persists username (and optionally password) in
    the local app_config table (SQLite). No external services.
  - "Forgot Password" — fully offline security-question based reset
    flow (3 steps: identify user -> answer question -> set new password)
  - Password visibility toggle
  - Live clock + greeting
"""
import os
from datetime import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFrame, QCheckBox, QGraphicsDropShadowEffect, QStackedWidget,
    QMessageBox, QApplication, QSizePolicy, QGraphicsOpacityEffect, QScrollArea,
)
from PySide6.QtCore import (
    Qt, QTimer, QPropertyAnimation, QEasingCurve, QRect, QPoint,
    QSequentialAnimationGroup, QParallelAnimationGroup, Signal, QSize,
)
from PySide6.QtGui import (
    QFont, QColor, QPainter, QLinearGradient, QPixmap, QPalette,
    QRadialGradient, QBrush, QIcon, QShortcut, QKeySequence,
)

from core.school_context import SchoolContext


# ════════════════════════════════════════════════════════════════════
#  ANIMATED BACKGROUND — floating gradient blobs
# ════════════════════════════════════════════════════════════════════
class AnimatedBackground(QWidget):
    """Soft floating gradient orbs that drift slowly across the panel."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        # Each orb: [x, y, radius, color, dx, dy]
        self._orbs = [
            [0.15, 0.20, 220, QColor(59, 130, 246, 90),  0.18, 0.12],
            [0.80, 0.15, 260, QColor(124, 58, 237, 70),  -0.14, 0.16],
            [0.30, 0.80, 200, QColor(6, 182, 212, 70),   0.12, -0.10],
            [0.85, 0.75, 240, QColor(34, 197, 94, 55),   -0.10, -0.14],
        ]
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(40)  # ~25 fps

    def _tick(self):
        w = max(self.width(), 1)
        h = max(self.height(), 1)
        for orb in self._orbs:
            orb[0] += orb[4] / w
            orb[1] += orb[5] / h
            # Bounce within [0.05, 0.95]
            if orb[0] < 0.05 or orb[0] > 0.95:
                orb[4] *= -1
            if orb[1] < 0.05 or orb[1] > 0.95:
                orb[5] *= -1
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        for x_frac, y_frac, radius, color, _, _ in self._orbs:
            cx, cy = x_frac * w, y_frac * h
            grad = QRadialGradient(cx, cy, radius)
            grad.setColorAt(0.0, color)
            transparent = QColor(color)
            transparent.setAlpha(0)
            grad.setColorAt(1.0, transparent)
            painter.setBrush(QBrush(grad))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(QPoint(int(cx), int(cy)), radius, radius)
        painter.end()


# ════════════════════════════════════════════════════════════════════
#  INPUT FIELD — rounded, icon-prefixed, glass style
# ════════════════════════════════════════════════════════════════════
class GlassInput(QLineEdit):
    def __init__(self, placeholder="", password=False, parent=None):
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        if password:
            self.setEchoMode(QLineEdit.Password)
        self.setFixedHeight(48)
        self.setStyleSheet("""
            QLineEdit {
                background: rgba(255, 255, 255, 0.06);
                border: 1.5px solid rgba(255, 255, 255, 0.12);
                border-radius: 12px;
                padding: 0 16px;
                color: #f1f5f9;
                font-size: 14px;
                selection-background-color: #3b82f6;
            }
            QLineEdit:focus {
                border: 1.5px solid #3b82f6;
                background: rgba(59, 130, 246, 0.08);
            }
            QLineEdit::placeholder {
                color: #64748b;
            }
        """)


# ════════════════════════════════════════════════════════════════════
#  PRIMARY BUTTON — gradient, hover glow, press animation
# ════════════════════════════════════════════════════════════════════
class GradientButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setFixedHeight(48)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #3b82f6, stop:1 #2563eb);
                color: white;
                border: none;
                border-radius: 12px;
                font-size: 14px;
                font-weight: 700;
                letter-spacing: 0.5px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #60a5fa, stop:1 #3b82f6);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #2563eb, stop:1 #1d4ed8);
            }
            QPushButton:disabled {
                background: #334155;
                color: #64748b;
            }
        """)
        glow = QGraphicsDropShadowEffect(self)
        glow.setBlurRadius(24)
        glow.setColor(QColor(59, 130, 246, 140))
        glow.setOffset(0, 4)
        self.setGraphicsEffect(glow)


class GhostButton(QPushButton):
    """Secondary / link-style button."""
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #93c5fd;
                border: none;
                font-size: 12.5px;
                font-weight: 600;
                text-align: left;
                padding: 2px;
            }
            QPushButton:hover {
                color: #bfdbfe;
                text-decoration: underline;
            }
        """)


class OutlineButton(QPushButton):
    """Outlined button — used for back/cancel in forgot-password flow."""
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setFixedHeight(46)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("""
            QPushButton {
                background: transparent;
                color: #cbd5e1;
                border: 1.5px solid rgba(255,255,255,0.18);
                border-radius: 12px;
                font-size: 13px;
                font-weight: 600;
            }
            QPushButton:hover {
                border: 1.5px solid rgba(255,255,255,0.35);
                background: rgba(255,255,255,0.04);
            }
        """)


# ════════════════════════════════════════════════════════════════════
#  GLASS CARD — frosted-glass container with drop shadow
# ════════════════════════════════════════════════════════════════════
class GlassCard(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("glassCard")
        self.setStyleSheet("""
            QFrame#glassCard {
                background: rgba(15, 23, 42, 0.72);
                border: 1px solid rgba(255, 255, 255, 0.10);
                border-radius: 22px;
            }
            QFrame#glassCard QLabel {
                background: transparent;
                border: none;
            }
        """)
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(50)
        shadow.setColor(QColor(0, 0, 0, 160))
        shadow.setOffset(0, 14)
        self.setGraphicsEffect(shadow)


# ════════════════════════════════════════════════════════════════════
#  MAIN LOGIN WINDOW
# ════════════════════════════════════════════════════════════════════
class LoginWindow(QWidget):

    login_success = Signal(dict)
    switch_school_requested = Signal()
    create_account_requested = Signal()

    def __init__(self, db, theme_manager=None, parent=None, school_label=None, show_switch_school=False):
        super().__init__(parent)
        self.db = db
        self.theme_manager = theme_manager
        self._school_label = school_label
        self._show_switch_school = show_switch_school
        self._ctx = SchoolContext.instance()
        try:
            self._ctx.load(db)
        except Exception:
            pass

        self.setWindowTitle("AI EduHub ERP — Login")
        self.setMinimumSize(1024, 680)
        self.resize(1180, 760)

        self._build_ui()
        self._load_remember_me()
        self._start_clock()
        self._setup_zoom_shortcuts()
        QTimer.singleShot(80, self._play_entrance_animation)

    def _setup_zoom_shortcuts(self):
        """Same Ctrl+=/Ctrl+-/Ctrl+0 zoom as the main app, available here
        too so sizing preference carries over before the user even logs in."""
        if not self.theme_manager:
            return
        for seq in ("Ctrl+=", "Ctrl++", "Ctrl+Shift+="):
            sc = QShortcut(QKeySequence(seq), self)
            sc.setContext(Qt.ApplicationShortcut)
            sc.activated.connect(self.theme_manager.zoom_in)
        for seq in ("Ctrl+-", "Ctrl+_"):
            sc = QShortcut(QKeySequence(seq), self)
            sc.setContext(Qt.ApplicationShortcut)
            sc.activated.connect(self.theme_manager.zoom_out)
        sc0 = QShortcut(QKeySequence("Ctrl+0"), self)
        sc0.setContext(Qt.ApplicationShortcut)
        sc0.activated.connect(self.theme_manager.zoom_reset)

    # ──────────────────────────────────────────────────────────────
    #  UI CONSTRUCTION
    # ──────────────────────────────────────────────────────────────
    def _build_ui(self):
        self.setStyleSheet("""
            QWidget#root {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #0a0f1e, stop:0.5 #0f172a, stop:1 #111827);
            }
        """)
        self.setObjectName("root")

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── LEFT: animated branding panel ──────────────────────────
        self.left_panel = self._build_branding_panel()
        root.addWidget(self.left_panel, 5)

        # ── RIGHT: login card area ──────────────────────────────────
        right_wrap = QWidget()
        right_wrap.setStyleSheet("background: transparent;")
        right_layout = QVBoxLayout(right_wrap)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setAlignment(Qt.AlignCenter)

        self.stack = QStackedWidget()
        self.stack.setMaximumWidth(440)
        self.stack.setMinimumWidth(400)

        self.login_card = self._build_login_card()
        self.forgot_card = self._build_forgot_password_card()

        self.stack.addWidget(self.login_card)
        self.stack.addWidget(self.forgot_card)
        self.stack.setCurrentIndex(0)

        # Safety net: if the card's content is ever taller than the window
        # (a smaller screen, or more content added later — like the
        # first-run CTA), it scrolls instead of overlapping. On a normal
        # screen with room to spare this is invisible; it only engages
        # when actually needed.
        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setFrameShape(QFrame.NoFrame)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        right_scroll.setStyleSheet("QScrollArea{background:transparent;border:none;}")
        scroll_inner = QWidget()
        scroll_inner.setStyleSheet("background:transparent;")
        scroll_inner_lay = QVBoxLayout(scroll_inner)
        scroll_inner_lay.setContentsMargins(40, 26, 40, 26)
        scroll_inner_lay.setAlignment(Qt.AlignCenter)
        scroll_inner_lay.addWidget(self.stack)
        right_scroll.setWidget(scroll_inner)

        right_layout.addWidget(right_scroll)
        root.addWidget(right_wrap, 4)

    # ──────────────────────────────────────────────────────────────
    #  LEFT BRANDING PANEL
    # ──────────────────────────────────────────────────────────────
    def _build_branding_panel(self):
        panel = QFrame()
        panel.setStyleSheet("""
            QFrame#brandPanel {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #1e3a8a, stop:0.5 #1e1b4b, stop:1 #0f172a);
                border-right: 1px solid rgba(255,255,255,0.06);
            }
        """)
        panel.setObjectName("brandPanel")

        # Animated background blobs (absolute, behind content) — the "flow" layer
        self.bg_anim = AnimatedBackground(panel)
        self.bg_anim.setGeometry(0, 0, 2000, 2000)

        # Gentle falling particles overlay — the "falling" layer, on top of the flow
        from ui.components.widgets import FallingParticles
        self.bg_particles = FallingParticles(panel, count=22)
        self.bg_particles.setGeometry(0, 0, 2000, 2000)
        self.bg_particles.raise_()

        # Content layout
        content = QVBoxLayout(panel)
        content.setContentsMargins(60, 60, 60, 60)
        content.setSpacing(0)

        # Logo + title row
        top_row = QHBoxLayout()
        top_row.setSpacing(16)

        self.logo_label = QLabel()
        self.logo_label.setFixedSize(58, 58)
        self._load_logo_pixmap()
        top_row.addWidget(self.logo_label)

        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        name_lbl = QLabel(self._ctx.name or "AI EduHub ERP")
        name_lbl.setStyleSheet(
            "color:#ffffff; font-size:22px; font-weight:800; background:transparent;")
        name_lbl.setWordWrap(True)
        tagline_lbl = QLabel("Smart Education Management")
        tagline_lbl.setStyleSheet(
            "color:#93c5fd; font-size:12px; font-weight:600; "
            "letter-spacing:1.5px; background:transparent;")
        title_box.addWidget(name_lbl)
        title_box.addWidget(tagline_lbl)
        top_row.addLayout(title_box)
        top_row.addStretch()
        content.addLayout(top_row)

        content.addStretch(2)

        # Hero heading
        hero = QLabel(
            "Manage your\nentire school\nfrom one place.")
        hero.setStyleSheet(
            "color:#ffffff; font-size:42px; font-weight:800; "
            "line-height:1.25; background:transparent;")
        hero.setWordWrap(True)
        content.addWidget(hero)

        content.addSpacing(18)

        sub = QLabel(
            "Admissions, fees, attendance, exams, results, AI-powered\n"
            "paper creation and more — all fully offline and secure.")
        sub.setStyleSheet(
            "color:#cbd5e1; font-size:14px; font-weight:400; "
            "line-height:1.6; background:transparent;")
        sub.setWordWrap(True)
        content.addWidget(sub)

        content.addStretch(1)

        # Feature pills
        pills_row = QHBoxLayout()
        pills_row.setSpacing(10)
        for icon, text in [("🎓", "Admissions"), ("💳", "Fees"),
                           ("✅", "Attendance"), ("🤖", "AI Papers")]:
            pill = QLabel(f"{icon}  {text}")
            pill.setStyleSheet("""
                QLabel {
                    color: #e2e8f0;
                    background: rgba(255,255,255,0.08);
                    border: 1px solid rgba(255,255,255,0.10);
                    border-radius: 18px;
                    padding: 8px 16px;
                    font-size: 12px;
                    font-weight: 600;
                }
            """)
            pills_row.addWidget(pill)
        pills_row.addStretch()
        content.addLayout(pills_row)

        content.addSpacing(28)

        # Live clock + date
        self.clock_lbl = QLabel("")
        self.clock_lbl.setStyleSheet(
            "color:#64748b; font-size:12px; font-weight:500; background:transparent;")
        content.addWidget(self.clock_lbl)

        return panel

    def _load_logo_pixmap(self):
        logo_path = getattr(self._ctx, "logo_path", "") or ""
        if logo_path and os.path.exists(logo_path):
            pix = QPixmap(logo_path).scaled(
                58, 58, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.logo_label.setPixmap(pix)
            self.logo_label.setStyleSheet(
                "background: transparent; border-radius: 12px;")
        else:
            # Fallback: initial-letter badge
            name = (self._ctx.name or "A").strip()
            initial = name[0].upper() if name else "A"
            self.logo_label.setText(initial)
            self.logo_label.setAlignment(Qt.AlignCenter)
            self.logo_label.setStyleSheet("""
                QLabel {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                        stop:0 #3b82f6, stop:1 #7c3aed);
                    color: white;
                    font-size: 26px;
                    font-weight: 800;
                    border-radius: 14px;
                }
            """)

    # ──────────────────────────────────────────────────────────────
    #  LOGIN CARD
    # ──────────────────────────────────────────────────────────────
    def _build_login_card(self):
        card = GlassCard()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(40, 40, 40, 36)
        layout.setSpacing(0)

        self._setup_complete = False
        try:
            self._setup_complete = bool(self.db.is_setup_complete())
        except Exception:
            pass

        # Greeting
        greeting = self._time_greeting()
        greet_lbl = QLabel(greeting)
        greet_lbl.setStyleSheet(
            "color:#93c5fd; font-size:13px; font-weight:600; "
            "letter-spacing:1px; background:transparent;")
        layout.addWidget(greet_lbl)

        title = QLabel("Welcome Back" if self._setup_complete else "Welcome!")
        title.setStyleSheet(
            "color:#f8fafc; font-size:28px; font-weight:800; "
            "background:transparent; margin-top:4px;")
        layout.addWidget(title)

        if self._setup_complete:
            subtitle_text = "Sign in to continue to your dashboard"
            if self._school_label:
                subtitle_text = f"Signing in to  🏫  {self._school_label}"
        else:
            subtitle_text = "No school set up on this device yet — let's get started"
        subtitle = QLabel(subtitle_text)
        subtitle.setStyleSheet(
            "color:#94a3b8; font-size:13px; background:transparent; margin-top:4px;")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        # First-run call-to-action — only shown until a school + admin
        # account exist on this device. Disappears permanently once setup
        # completes; from then on this is a normal login screen.
        self._setup_cta = None
        if not self._setup_complete:
            layout.addSpacing(18)
            cta_card = QFrame()
            cta_card.setObjectName("ctaCard")
            cta_card.setMinimumHeight(148)
            cta_card.setStyleSheet("""
                QFrame#ctaCard {
                    background: rgba(59,130,246,0.10);
                    border: 1.5px solid rgba(59,130,246,0.35);
                    border-radius: 14px;
                }
                QFrame#ctaCard QLabel {
                    background: transparent;
                    border: none;
                }
            """)
            cta_lay = QVBoxLayout(cta_card)
            cta_lay.setContentsMargins(18, 16, 18, 16)
            cta_lay.setSpacing(8)
            cta_msg = QLabel("👋  Don't have an account yet?")
            cta_msg.setStyleSheet(
                "color:#dbeafe; font-size:13.5px; font-weight:700; background:transparent;")
            cta_lay.addWidget(cta_msg)
            cta_sub = QLabel("Create your school and admin\naccount to begin — takes a minute.")
            cta_sub.setMinimumHeight(34)
            cta_sub.setStyleSheet(
                "color:#93c5fd; font-size:11.5px; background:transparent;")
            cta_lay.addWidget(cta_sub)
            cta_lay.addSpacing(2)
            self._setup_cta = GradientButton("🚀  Create Account / Set Up School")
            self._setup_cta.clicked.connect(self.create_account_requested.emit)
            cta_lay.addWidget(self._setup_cta)
            layout.addWidget(cta_card)

            div_row = QHBoxLayout()
            div_line1 = QFrame(); div_line1.setFixedHeight(1)
            div_line1.setStyleSheet("background:rgba(255,255,255,0.12);")
            div_line2 = QFrame(); div_line2.setFixedHeight(1)
            div_line2.setStyleSheet("background:rgba(255,255,255,0.12);")
            div_text = QLabel("ALREADY HAVE CREDENTIALS?")
            div_text.setStyleSheet(
                "color:#64748b; font-size:10px; font-weight:700; "
                "letter-spacing:1px; background:transparent;")
            div_row.addWidget(div_line1, 1)
            div_row.addWidget(div_text, 0)
            div_row.addWidget(div_line2, 1)
            layout.addSpacing(18)
            layout.addLayout(div_row)

        layout.addSpacing(20 if not self._setup_complete else 28)

        # Username field
        layout.addWidget(self._field_label("Username or Email"))
        self.username_input = GlassInput("Enter your username or email")
        self.username_input.returnPressed.connect(self._focus_password)
        layout.addWidget(self.username_input)

        layout.addSpacing(16)

        # Password field with visibility toggle
        layout.addWidget(self._field_label("Password"))
        pwd_row = QFrame()
        pwd_row.setStyleSheet("background: transparent;")
        pwd_layout = QHBoxLayout(pwd_row)
        pwd_layout.setContentsMargins(0, 0, 0, 0)
        pwd_layout.setSpacing(0)

        self.password_input = GlassInput("Enter your password", password=True)
        self.password_input.returnPressed.connect(self._attempt_login)

        self.toggle_pwd_btn = QPushButton("👁")
        self.toggle_pwd_btn.setFixedSize(48, 48)
        self.toggle_pwd_btn.setCursor(Qt.PointingHandCursor)
        self.toggle_pwd_btn.setCheckable(True)
        self.toggle_pwd_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255,255,255,0.06);
                border: 1.5px solid rgba(255,255,255,0.12);
                border-left: none;
                border-radius: 0px;
                border-top-right-radius: 12px;
                border-bottom-right-radius: 12px;
                color: #94a3b8;
                font-size: 15px;
            }
            QPushButton:hover { color: #e2e8f0; }
            QPushButton:checked { color: #3b82f6; }
        """)
        self.toggle_pwd_btn.clicked.connect(self._toggle_password_visibility)

        # Adjust password input to remove right radius (merge with toggle button)
        self.password_input.setStyleSheet(self.password_input.styleSheet() + """
            QLineEdit {
                border-top-right-radius: 0px;
                border-bottom-right-radius: 0px;
                border-right: none;
            }
        """)

        pwd_layout.addWidget(self.password_input)
        pwd_layout.addWidget(self.toggle_pwd_btn)
        layout.addWidget(pwd_row)

        layout.addSpacing(14)

        # Remember me + Forgot password row
        row = QHBoxLayout()
        self.remember_check = QCheckBox("Remember me")
        self.remember_check.setCursor(Qt.PointingHandCursor)
        self.remember_check.setStyleSheet("""
            QCheckBox {
                color: #cbd5e1;
                font-size: 12.5px;
                font-weight: 500;
                spacing: 8px;
            }
            QCheckBox::indicator {
                width: 18px; height: 18px;
                border-radius: 5px;
                border: 1.5px solid rgba(255,255,255,0.25);
                background: rgba(255,255,255,0.04);
            }
            QCheckBox::indicator:checked {
                background: #3b82f6;
                border: 1.5px solid #3b82f6;
                image: none;
            }
        """)
        row.addWidget(self.remember_check)
        row.addStretch()

        if self._show_switch_school:
            self.switch_school_btn = GhostButton("🏫 Switch School")
            self.switch_school_btn.clicked.connect(self.switch_school_requested.emit)
            row.addWidget(self.switch_school_btn)
            row.addSpacing(14)

        self.forgot_btn = GhostButton("Forgot password?")
        self.forgot_btn.clicked.connect(self._show_forgot_password)
        row.addWidget(self.forgot_btn)
        layout.addLayout(row)

        layout.addSpacing(24)

        # Error message label (hidden until needed)
        self.error_lbl = QLabel("")
        self.error_lbl.setWordWrap(True)
        self.error_lbl.setStyleSheet("""
            QLabel {
                color: #fca5a5;
                background: rgba(239, 68, 68, 0.10);
                border: 1px solid rgba(239, 68, 68, 0.25);
                border-radius: 10px;
                padding: 10px 14px;
                font-size: 12.5px;
                font-weight: 600;
            }
        """)
        self.error_lbl.setVisible(False)
        layout.addWidget(self.error_lbl)
        layout.addSpacing(8)

        # Login button
        self.login_btn = GradientButton("Sign In")
        self.login_btn.clicked.connect(self._attempt_login)
        layout.addWidget(self.login_btn)

        layout.addSpacing(20)

        # Footer
        footer = QLabel("🔒  Your data stays on this device — 100% offline")
        footer.setAlignment(Qt.AlignCenter)
        footer.setStyleSheet(
            "color:#64748b; font-size:11px; font-weight:500; background:transparent;")
        layout.addWidget(footer)

        return card

    def _field_label(self, text):
        lbl = QLabel(text)
        lbl.setStyleSheet(
            "color:#cbd5e1; font-size:12.5px; font-weight:600; "
            "background:transparent; margin-bottom:6px;")
        return lbl

    # ──────────────────────────────────────────────────────────────
    #  FORGOT PASSWORD CARD  (3-step offline flow)
    # ──────────────────────────────────────────────────────────────
    def _build_forgot_password_card(self):
        card = GlassCard()
        outer = QVBoxLayout(card)
        outer.setContentsMargins(40, 40, 40, 36)
        outer.setSpacing(0)

        # Header (shared across steps)
        header_row = QHBoxLayout()
        back_btn = QPushButton("←")
        back_btn.setFixedSize(36, 36)
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.setStyleSheet("""
            QPushButton {
                background: rgba(255,255,255,0.06);
                border: 1px solid rgba(255,255,255,0.10);
                border-radius: 10px;
                color: #cbd5e1;
                font-size: 16px;
                font-weight: 700;
            }
            QPushButton:hover { background: rgba(255,255,255,0.12); }
        """)
        back_btn.clicked.connect(self._show_login)
        header_row.addWidget(back_btn)
        header_row.addStretch()
        outer.addLayout(header_row)

        outer.addSpacing(20)

        title = QLabel("Reset Password")
        title.setStyleSheet(
            "color:#f8fafc; font-size:26px; font-weight:800; background:transparent;")
        outer.addWidget(title)

        self.fp_subtitle = QLabel(
            "Enter your username or email to begin.")
        self.fp_subtitle.setWordWrap(True)
        self.fp_subtitle.setStyleSheet(
            "color:#94a3b8; font-size:13px; background:transparent; margin-top:4px;")
        outer.addWidget(self.fp_subtitle)

        outer.addSpacing(24)

        # Step indicator
        self.fp_step_row = QHBoxLayout()
        self.fp_step_dots = []
        for i in range(3):
            dot = QLabel(str(i + 1))
            dot.setFixedSize(28, 28)
            dot.setAlignment(Qt.AlignCenter)
            self.fp_step_dots.append(dot)
            self.fp_step_row.addWidget(dot)
            if i < 2:
                line = QFrame()
                line.setFixedHeight(2)
                line.setStyleSheet("background: rgba(255,255,255,0.10);")
                self.fp_step_row.addWidget(line, 1)
        outer.addLayout(self.fp_step_row)
        outer.addSpacing(24)

        # Stacked steps
        self.fp_stack = QStackedWidget()
        self.fp_stack.addWidget(self._fp_step1())
        self.fp_stack.addWidget(self._fp_step2())
        self.fp_stack.addWidget(self._fp_step3())
        self.fp_stack.addWidget(self._fp_step_done())
        outer.addWidget(self.fp_stack)

        outer.addSpacing(8)

        # Shared error/info label
        self.fp_msg_lbl = QLabel("")
        self.fp_msg_lbl.setWordWrap(True)
        self.fp_msg_lbl.setVisible(False)
        outer.addWidget(self.fp_msg_lbl)

        self._fp_set_step(0)
        return card

    def _fp_set_step(self, index):
        """Update the step indicator dots and switch the visible step."""
        self.fp_stack.setCurrentIndex(min(index, 2) if index < 3 else 3)
        for i, dot in enumerate(self.fp_step_dots):
            if i < index or index == 3:
                # completed
                dot.setText("✓")
                dot.setStyleSheet("""
                    background: #22c55e; color: white; border-radius: 14px;
                    font-size: 13px; font-weight: 700;
                """)
            elif i == index:
                dot.setText(str(i + 1))
                dot.setStyleSheet("""
                    background: #3b82f6; color: white; border-radius: 14px;
                    font-size: 13px; font-weight: 700;
                """)
            else:
                dot.setText(str(i + 1))
                dot.setStyleSheet("""
                    background: rgba(255,255,255,0.08); color: #64748b;
                    border-radius: 14px; font-size: 13px; font-weight: 700;
                    border: 1px solid rgba(255,255,255,0.10);
                """)
        self.fp_msg_lbl.setVisible(False)

        subtitles = {
            0: "Enter your username or email to begin.",
            1: "Answer your security question to verify your identity.",
            2: "Choose a new password for your account.",
            3: "All done! You can now sign in with your new password.",
        }
        self.fp_subtitle.setText(subtitles.get(index, ""))

    # ── Step 1: identify user ───────────────────────────────────────
    def _fp_step1(self):
        w = QWidget()
        w.setStyleSheet("background: transparent;")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        lay.addWidget(self._field_label("Username or Email"))
        self.fp_identifier = GlassInput("Enter your username or email")
        self.fp_identifier.returnPressed.connect(self._fp_find_user)
        lay.addWidget(self.fp_identifier)

        lay.addSpacing(24)
        btn = GradientButton("Continue")
        btn.clicked.connect(self._fp_find_user)
        lay.addWidget(btn)
        lay.addStretch()
        return w

    # ── Step 2: security question ───────────────────────────────────
    def _fp_step2(self):
        w = QWidget()
        w.setStyleSheet("background: transparent;")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.fp_question_lbl = QLabel("")
        self.fp_question_lbl.setWordWrap(True)
        self.fp_question_lbl.setStyleSheet("""
            QLabel {
                color: #e2e8f0;
                background: rgba(59,130,246,0.10);
                border: 1px solid rgba(59,130,246,0.25);
                border-radius: 10px;
                padding: 12px 14px;
                font-size: 13px;
                font-weight: 600;
            }
        """)
        lay.addWidget(self.fp_question_lbl)
        lay.addSpacing(18)

        lay.addWidget(self._field_label("Your Answer"))
        self.fp_answer = GlassInput("Type your answer")
        self.fp_answer.returnPressed.connect(self._fp_verify_answer)
        lay.addWidget(self.fp_answer)

        lay.addSpacing(24)
        btn = GradientButton("Verify Answer")
        btn.clicked.connect(self._fp_verify_answer)
        lay.addWidget(btn)
        lay.addStretch()
        return w

    # ── Step 3: new password ─────────────────────────────────────────
    def _fp_step3(self):
        w = QWidget()
        w.setStyleSheet("background: transparent;")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        lay.addWidget(self._field_label("New Password"))
        self.fp_new_pwd = GlassInput("Enter new password", password=True)
        lay.addWidget(self.fp_new_pwd)
        lay.addSpacing(16)

        lay.addWidget(self._field_label("Confirm New Password"))
        self.fp_confirm_pwd = GlassInput("Re-enter new password", password=True)
        self.fp_confirm_pwd.returnPressed.connect(self._fp_set_new_password)
        lay.addWidget(self.fp_confirm_pwd)

        lay.addSpacing(24)
        btn = GradientButton("Reset Password")
        btn.clicked.connect(self._fp_set_new_password)
        lay.addWidget(btn)
        lay.addStretch()
        return w

    # ── Step 4: success ───────────────────────────────────────────────
    def _fp_step_done(self):
        w = QWidget()
        w.setStyleSheet("background: transparent;")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.setAlignment(Qt.AlignCenter)

        icon = QLabel("✅")
        icon.setAlignment(Qt.AlignCenter)
        icon.setStyleSheet("font-size:54px; background:transparent;")
        lay.addWidget(icon)
        lay.addSpacing(12)

        msg = QLabel("Password reset successfully!")
        msg.setAlignment(Qt.AlignCenter)
        msg.setWordWrap(True)
        msg.setStyleSheet(
            "color:#f8fafc; font-size:16px; font-weight:700; background:transparent;")
        lay.addWidget(msg)
        lay.addSpacing(24)

        btn = GradientButton("Back to Sign In")
        btn.clicked.connect(self._show_login)
        lay.addWidget(btn)
        return w

    # ──────────────────────────────────────────────────────────────
    #  FORGOT-PASSWORD LOGIC (offline security question flow)
    # ──────────────────────────────────────────────────────────────
    def _fp_show_msg(self, text, kind="error"):
        colors = {
            "error": ("#fca5a5", "rgba(239,68,68,0.10)",  "rgba(239,68,68,0.25)"),
            "info":  ("#93c5fd", "rgba(59,130,246,0.10)", "rgba(59,130,246,0.25)"),
            "warn":  ("#fcd34d", "rgba(245,158,11,0.10)", "rgba(245,158,11,0.25)"),
        }
        fg, bg, bd = colors.get(kind, colors["error"])
        self.fp_msg_lbl.setStyleSheet(f"""
            QLabel {{
                color: {fg};
                background: {bg};
                border: 1px solid {bd};
                border-radius: 10px;
                padding: 10px 14px;
                font-size: 12.5px;
                font-weight: 600;
            }}
        """)
        self.fp_msg_lbl.setText(text)
        self.fp_msg_lbl.setVisible(True)

    def _fp_find_user(self):
        identifier = self.fp_identifier.text().strip()
        if not identifier:
            self._fp_show_msg("Please enter your username or email.")
            return

        try:
            user = self.db.get_user_by_identifier(identifier)
        except Exception:
            user = None

        if not user:
            self._fp_show_msg("No account found with that username or email.")
            return

        question = user.get("security_question")
        if not question:
            self._fp_show_msg(
                "No security question is set for this account.\n\n"
                "Please ask your system administrator to reset your "
                "password from the Settings → Users panel.",
                kind="warn",
            )
            return

        self._fp_user = user
        self.fp_question_lbl.setText(f"🔐  {question}")
        self.fp_answer.clear()
        self._fp_set_step(1)
        self.fp_answer.setFocus()

    def _fp_verify_answer(self):
        answer = self.fp_answer.text().strip()
        if not answer:
            self._fp_show_msg("Please type your answer.")
            return

        identifier = self._fp_user.get("username") or self._fp_user.get("email")
        try:
            ok = self.db.verify_security_answer(identifier, answer)
        except Exception:
            ok = False

        if not ok:
            self._fp_show_msg("That answer doesn't match. Please try again.")
            self._shake_widget(self.fp_answer)
            return

        self.fp_new_pwd.clear()
        self.fp_confirm_pwd.clear()
        self._fp_set_step(2)
        self.fp_new_pwd.setFocus()

    def _fp_set_new_password(self):
        new_pwd = self.fp_new_pwd.text()
        confirm = self.fp_confirm_pwd.text()

        if len(new_pwd) < 4:
            self._fp_show_msg("Password must be at least 4 characters long.")
            return
        if new_pwd != confirm:
            self._fp_show_msg("Passwords do not match.")
            self._shake_widget(self.fp_confirm_pwd)
            return

        identifier = self._fp_user.get("username") or self._fp_user.get("email")
        try:
            self.db.reset_password(identifier, new_pwd)
        except Exception as e:
            self._fp_show_msg(f"Failed to reset password: {e}")
            return

        # If remember-me had a saved password for this user, clear it
        # (it's now stale) but keep the remembered username.
        try:
            if self.db.get_config("remember_username") == self._fp_user.get("username"):
                self.db.delete_config("remember_password")
        except Exception:
            pass

        self._fp_set_step(3)

    def _show_forgot_password(self):
        # Pre-fill with whatever's in the username box for convenience
        self.fp_identifier.setText(self.username_input.text().strip())
        self._fp_set_step(0)
        self._crossfade_to(1)
        self.fp_identifier.setFocus()

    def _show_login(self):
        self._crossfade_to(0)
        self.username_input.setFocus()

    def _crossfade_to(self, index):
        """Animate a fade transition between login and forgot-password cards.

        Note: setGraphicsEffect() replaces any existing effect on a widget
        (Qt only allows one at a time), so the GlassCard's permanent drop
        shadow is restored once each fade animation finishes. Any in-flight
        entrance animation on the current widget is stopped first, since it
        also owns a QGraphicsOpacityEffect on the same widget and would
        otherwise be left holding a dangling target once we overwrite it.
        """
        current = self.stack.currentWidget()

        # Stop the entrance animation if it's still running on this widget —
        # otherwise overwriting its QGraphicsOpacityEffect below leaves the
        # QPropertyAnimation pointing at a destroyed target.
        entrance = getattr(self, "_entrance_anim", None)
        if entrance is not None and entrance.state() == QPropertyAnimation.Running:
            entrance.stop()

        # Guard against overlapping crossfades (e.g. rapid double-click)
        in_flight = getattr(self, "_fp_fade_out_anim", None)
        if in_flight is not None and in_flight.state() == QPropertyAnimation.Running:
            in_flight.stop()
        in_flight_in = getattr(self, "_fp_fade_anim", None)
        if in_flight_in is not None and in_flight_in.state() == QPropertyAnimation.Running:
            in_flight_in.stop()

        effect = QGraphicsOpacityEffect(current)
        current.setGraphicsEffect(effect)
        anim_out = QPropertyAnimation(effect, b"opacity", self)
        anim_out.setDuration(160)
        anim_out.setStartValue(1.0)
        anim_out.setEndValue(0.0)
        anim_out.setEasingCurve(QEasingCurve.InOutQuad)

        def switch():
            self.stack.setCurrentIndex(index)
            new_widget = self.stack.currentWidget()
            new_effect = QGraphicsOpacityEffect(new_widget)
            new_widget.setGraphicsEffect(new_effect)
            anim_in = QPropertyAnimation(new_effect, b"opacity", self)
            anim_in.setDuration(220)
            anim_in.setStartValue(0.0)
            anim_in.setEndValue(1.0)
            anim_in.setEasingCurve(QEasingCurve.InOutQuad)
            anim_in.finished.connect(lambda: self._restore_card_shadow(new_widget))
            anim_in.start()
            self._fp_fade_anim = anim_in  # keep ref alive

        anim_out.finished.connect(switch)
        anim_out.start()
        self._fp_fade_out_anim = anim_out  # keep ref alive

    def _restore_card_shadow(self, card):
        """Re-attach the permanent drop shadow that QGraphicsOpacityEffect
        temporarily replaced during the crossfade animation."""
        shadow = QGraphicsDropShadowEffect(card)
        shadow.setBlurRadius(50)
        shadow.setColor(QColor(0, 0, 0, 160))
        shadow.setOffset(0, 14)
        card.setGraphicsEffect(shadow)

    # ──────────────────────────────────────────────────────────────
    #  PASSWORD VISIBILITY TOGGLE
    # ──────────────────────────────────────────────────────────────
    def _toggle_password_visibility(self):
        if self.toggle_pwd_btn.isChecked():
            self.password_input.setEchoMode(QLineEdit.Normal)
            self.toggle_pwd_btn.setText("🙈")
        else:
            self.password_input.setEchoMode(QLineEdit.Password)
            self.toggle_pwd_btn.setText("👁")

    def _focus_password(self):
        self.password_input.setFocus()

    # ──────────────────────────────────────────────────────────────
    #  REMEMBER ME — persisted via app_config table
    # ──────────────────────────────────────────────────────────────
    def _load_remember_me(self):
        try:
            remembered_user = self.db.get_config("remember_username", "")
            remembered_pwd  = self.db.get_config("remember_password", "")
            remember_flag   = self.db.get_config("remember_enabled", "0")
        except Exception:
            remembered_user, remembered_pwd, remember_flag = "", "", "0"

        if remember_flag == "1" and remembered_user:
            self.username_input.setText(remembered_user)
            self.remember_check.setChecked(True)
            if remembered_pwd:
                try:
                    import base64
                    decoded = base64.b64decode(remembered_pwd.encode()).decode()
                    self.password_input.setText(decoded)
                except Exception:
                    pass
            self.password_input.setFocus()
        else:
            self.username_input.setFocus()

    def _save_remember_me(self, username, password):
        try:
            if self.remember_check.isChecked():
                encoded = base64.b64encode(password.encode()).decode()
                self.db.set_config("remember_enabled", "1")
                self.db.set_config("remember_username", username)
                self.db.set_config("remember_password", encoded)
            else:
                self.db.set_config("remember_enabled", "0")
                self.db.delete_config("remember_username")
                self.db.delete_config("remember_password")
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────────
    #  LOGIN LOGIC
    # ──────────────────────────────────────────────────────────────
    def _attempt_login(self):
        username = self.username_input.text().strip()
        password = self.password_input.text()

        self.error_lbl.setVisible(False)

        if not username or not password:
            self._show_error("Please enter both username and password.")
            self._shake_widget(self.stack.currentWidget())
            return

        self.login_btn.setEnabled(False)
        self.login_btn.setText("Signing in...")
        QApplication.processEvents()

        try:
            user = self.db.get_user(username, password)
        except Exception as e:
            user = None
            self._show_error(f"Database error: {e}")

        self.login_btn.setEnabled(True)
        self.login_btn.setText("Sign In")

        if user:
            self._save_remember_me(username, password)
            try:
                self.db.execute(
                    "UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?",
                    (user["id"],)
                )
            except Exception:
                pass
            self.login_success.emit(user)
        else:
            self._show_error("Invalid username or password. Please try again.")
            self._shake_widget(self.stack.currentWidget())
            self.password_input.clear()
            self.password_input.setFocus()

    def _show_error(self, text):
        self.error_lbl.setText(f"⚠  {text}")
        self.error_lbl.setVisible(True)

    # ──────────────────────────────────────────────────────────────
    #  ANIMATIONS
    # ──────────────────────────────────────────────────────────────
    def _shake_widget(self, widget):
        """Horizontal shake animation for invalid input feedback."""
        anim = QPropertyAnimation(widget, b"pos", self)
        start_pos = widget.pos()
        anim.setDuration(380)
        anim.setKeyValueAt(0.0,  start_pos)
        anim.setKeyValueAt(0.12, start_pos + QPoint(-10, 0))
        anim.setKeyValueAt(0.24, start_pos + QPoint(10, 0))
        anim.setKeyValueAt(0.36, start_pos + QPoint(-8, 0))
        anim.setKeyValueAt(0.48, start_pos + QPoint(8, 0))
        anim.setKeyValueAt(0.60, start_pos + QPoint(-5, 0))
        anim.setKeyValueAt(0.72, start_pos + QPoint(5, 0))
        anim.setKeyValueAt(1.0,  start_pos)
        anim.setEasingCurve(QEasingCurve.InOutQuad)
        anim.start()
        self._shake_anim = anim  # keep reference alive

    def _play_entrance_animation(self):
        """Fade + slide in the login card on window show."""
        card = self.stack.currentWidget()
        effect = QGraphicsOpacityEffect(card)
        card.setGraphicsEffect(effect)

        fade = QPropertyAnimation(effect, b"opacity", self)
        fade.setDuration(550)
        fade.setStartValue(0.0)
        fade.setEndValue(1.0)
        fade.setEasingCurve(QEasingCurve.OutCubic)

        start_pos = card.pos()
        slide = QPropertyAnimation(card, b"pos", self)
        slide.setDuration(550)
        slide.setStartValue(start_pos + QPoint(0, 28))
        slide.setEndValue(start_pos)
        slide.setEasingCurve(QEasingCurve.OutCubic)

        group = QParallelAnimationGroup(self)
        group.addAnimation(fade)
        group.addAnimation(slide)
        group.finished.connect(lambda: self._restore_card_shadow(card))
        group.start()
        self._entrance_anim = group  # keep reference alive

    # ──────────────────────────────────────────────────────────────
    #  LIVE CLOCK
    # ──────────────────────────────────────────────────────────────
    def _start_clock(self):
        self._update_clock()
        self._clock_timer = QTimer(self)
        self._clock_timer.timeout.connect(self._update_clock)
        self._clock_timer.start(1000)

    def _update_clock(self):
        now = datetime.now()
        text = now.strftime("%A, %d %B %Y   •   %I:%M:%S %p")
        self.clock_lbl.setText(text)

    def _time_greeting(self):
        hour = datetime.now().hour
        if hour < 12:
            return "GOOD MORNING"
        elif hour < 17:
            return "GOOD AFTERNOON"
        else:
            return "GOOD EVENING"

    # ──────────────────────────────────────────────────────────────
    #  RESIZE — keep animated background covering full panel
    # ──────────────────────────────────────────────────────────────
    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "left_panel") and hasattr(self, "bg_anim"):
            self.bg_anim.setGeometry(0, 0, self.left_panel.width(), self.left_panel.height())
