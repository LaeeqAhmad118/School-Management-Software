# School Management ERP System
## AI-Powered | Offline | Enterprise-Grade

### Features
- ✅ Full Offline Operation
- 🔐 Role-Based Access Control (Admin, Teacher, Accounts, Admission, Exam, Staff)
- 📊 Animated AI-powered Dashboard
- 📋 Multi-step Admission Wizard with auto-approval workflow
- 👨‍🎓 Complete Student Management with Digital Passport
- 💰 Advanced Fee Management with 3-copy A4 vouchers
- ✅ Daily Attendance with QR support
- 📝 Exam & Result Management
- 🗓 Timetable with clash prevention
- 👥 Staff & HR Management
- 📈 Reports & Excel Export
- 🤖 Offline AI Analytics & Smart Assistant
- 🎨 5 Premium Themes (Dark Blue, Dark Purple, Emerald, Black Gold, Light)
- 💾 Automatic & Manual Backup
- ⌨️ Full Keyboard Shortcut System

---

### Quick Start

#### Step 1: Install Python 3.10+
Download from https://www.python.org/downloads/

#### Step 2: Install Dependencies
**Windows:** Double-click `install.bat`
**Linux/Mac:** Run `./install.sh`

Or manually:
```
pip install PySide6 reportlab openpyxl qrcode Pillow
```

#### Step 3: Run
```
python main.py
```

---

### Build EXE (Windows)
```
pip install pyinstaller
pyinstaller --onefile --windowed --name="AI EduHub ERP" main.py
```
The EXE will be in the `dist/` folder.

---

### Keyboard Shortcuts
| Key | Action |
|-----|--------|
| Ctrl+N | New Record |
| Ctrl+S | Save |
| Ctrl+F / Ctrl+K | Smart Search |
| Ctrl+L | Logout |
| Ctrl+P | Print |
| Ctrl+E | Export |
| F1 | Dashboard |
| F2 | Admissions |
| F3 | Students |
| F4 | Fees |
| F5 | Attendance |
| F6 | Exams |
| F7 | Reports |
| F8 | AI Analytics |
| F9 | Settings |

---

### Default Login (after setup)
Use the credentials you create in the Setup Wizard.

---

### Data Location
Database: `~/.ai_eduhub_erp/school_erp.db`
Backups: `~/.ai_eduhub_erp/backups/`
Exports: `~/.ai_eduhub_erp/exports/`

---

### Tech Stack
- Python 3.10+
- PySide6 (Qt6)
- SQLite (offline database)
- ReportLab (PDF generation)
- OpenPyXL (Excel export)
- QRCode (QR generation)
