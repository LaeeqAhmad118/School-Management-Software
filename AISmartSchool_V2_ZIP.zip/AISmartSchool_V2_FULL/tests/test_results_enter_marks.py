import os
import sys
import tempfile
import unittest

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from PySide6.QtWidgets import QApplication

from database.db_manager import DatabaseManager
from modules.results.results_view import EnterMarksDialog


class EnterMarksDialogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        fd, path = tempfile.mkstemp(suffix='.db')
        os.close(fd)
        self.db = DatabaseManager(path)
        self.db.initialize()

        self.db.execute("INSERT INTO classes (id, name, level) VALUES (1, 'Grade 5', 5)")
        self.db.execute("INSERT INTO exams (id, name, class_id, status) VALUES (1, 'Mid Term', 1, 'scheduled')")
        self.db.execute("INSERT INTO subjects (id, name, class_id) VALUES (1, 'Math', 1)")
        self.db.execute("INSERT INTO students (id, student_id, full_name, class_id, status, roll_number) VALUES (1, 'STU00001', 'Alice', 1, 'active', '1')")
        self.db.execute("INSERT INTO students (id, student_id, full_name, class_id, status, roll_number) VALUES (2, 'STU00002', 'Bob', 1, 'active', '2')")
        self.db.execute("INSERT INTO exam_subjects (exam_id, subject_id, total_marks, passing_marks) VALUES (1, 1, 100, 40)")

    def test_invalid_subject_selection_does_not_load_students(self):
        dlg = EnterMarksDialog(self.db)
        dlg.exam_cb.setCurrentIndex(1)
        dlg.class_cb.setCurrentIndex(1)
        dlg.subj_cb.clear()
        dlg.subj_cb.addItem('Wrong Subject', 999)
        dlg.subj_cb.setCurrentIndex(0)

        dlg._load_students()

        self.assertEqual(dlg.marks_table.rowCount(), 0)
        self.assertEqual(getattr(dlg, '_student_ids', []), [])

    def test_valid_subject_selection_loads_students(self):
        dlg = EnterMarksDialog(self.db)
        dlg.exam_cb.setCurrentIndex(1)
        dlg.class_cb.setCurrentIndex(1)
        dlg.subj_cb.clear()
        dlg.subj_cb.addItem('Math', 1)
        dlg.subj_cb.setCurrentIndex(0)

        dlg._load_students()

        self.assertEqual(dlg.marks_table.rowCount(), 2)
        self.assertEqual(len(getattr(dlg, '_student_ids', [])), 2)


if __name__ == '__main__':
    unittest.main()
