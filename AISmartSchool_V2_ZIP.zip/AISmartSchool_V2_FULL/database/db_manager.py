"""
Database Manager V2
  - Single database per installation: each school runs its own copy of the
    app, with its own local database file — simple, isolated, no
    cross-school picker screen needed.
  - All original schema preserved + documents columns added
"""
import sqlite3
import os
import hashlib
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

BASE_DIR  = os.path.join(os.path.expanduser("~"), ".ai_eduhub_erp")
DB_PATH   = os.path.join(BASE_DIR, "ai_eduhub_erp.db")   # default / fallback


def get_db_path_for_school(school_code: str) -> str:
    """Return isolated DB path for a given school code (e.g. SMS-0001)."""
    safe = school_code.replace("/","_").replace("\\","_").strip()
    return os.path.join(BASE_DIR, "schools", f"{safe}.db")


class DatabaseManager:
    def __init__(self, db_path=None):
        self.db_path = db_path or DB_PATH
        _dir = os.path.dirname(self.db_path)
        if _dir:
            os.makedirs(_dir, exist_ok=True)
        self._connection = None

    # ── Connection ────────────────────────────────────────────────────────
    def get_connection(self):
        if self._connection is None:
            self._connection = sqlite3.connect(self.db_path, check_same_thread=False)
            self._connection.row_factory = sqlite3.Row
            self._connection.execute("PRAGMA foreign_keys = ON")
            self._connection.execute("PRAGMA journal_mode = WAL")
        return self._connection

    def execute(self, query, params=None):
        conn = self.get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(query, params or [])
            conn.commit()
            return cursor
        except sqlite3.Error as e:
            conn.rollback()
            logger.error(f"DB Error: {e} | Query: {query}")
            raise

    def fetchall(self, query, params=None):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(query, params or [])
        return [dict(row) for row in cursor.fetchall()]

    def fetchone(self, query, params=None):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(query, params or [])
        row = cursor.fetchone()
        return dict(row) if row else None

    # ── Setup / Auth ──────────────────────────────────────────────────────
    def is_setup_complete(self):
        try:
            result = self.fetchone("SELECT value FROM app_config WHERE key='setup_complete'")
            return result and result['value'] == '1'
        except Exception:
            return False

    def initialize(self):
        self._create_tables()

    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    def verify_password(self, password, hash_):
        return self.hash_password(password) == hash_

    def create_admin(self, username, password, full_name, email=""):
        ph = self.hash_password(password)
        self.execute(
            "INSERT OR REPLACE INTO users (username,email,password_hash,full_name,role) VALUES (?,?,?,?,?)",
            (username, email, ph, full_name, 'admin')
        )

    def get_user(self, username, password):
        ph = self.hash_password(password)
        return self.fetchone(
            "SELECT * FROM users WHERE (username=? OR email=?) AND password_hash=? AND is_active=1",
            (username, username, ph)
        )

    # ── Forgot Password / Security Question ────────────────────────────────
    def get_user_by_identifier(self, identifier):
        """Find an active user by username or email (no password check)."""
        identifier = (identifier or "").strip()
        if not identifier:
            return None
        return self.fetchone(
            "SELECT * FROM users WHERE (username=? OR email=?) AND is_active=1",
            (identifier, identifier)
        )

    def get_security_question(self, identifier):
        """Return the security question for a user, or None if not set."""
        user = self.get_user_by_identifier(identifier)
        if user and user.get("security_question"):
            return user["security_question"]
        return None

    def verify_security_answer(self, identifier, answer):
        """Check a security answer (case-insensitive, trimmed)."""
        user = self.get_user_by_identifier(identifier)
        if not user or not user.get("security_answer_hash"):
            return False
        normalized = (answer or "").strip().lower()
        return self.hash_password(normalized) == user["security_answer_hash"]

    def set_security_question(self, user_id, question, answer):
        """Set/update a user's security question and answer (answer hashed)."""
        normalized = (answer or "").strip().lower()
        self.execute(
            "UPDATE users SET security_question=?, security_answer_hash=? WHERE id=?",
            (question, self.hash_password(normalized), user_id)
        )

    def reset_password(self, identifier, new_password):
        """Reset a user's password after security-answer verification."""
        user = self.get_user_by_identifier(identifier)
        if not user:
            return False
        ph = self.hash_password(new_password)
        self.execute("UPDATE users SET password_hash=? WHERE id=?", (ph, user["id"]))
        return True

    def mark_setup_complete(self):
        self.execute(
            "INSERT OR REPLACE INTO app_config (key,value) VALUES ('setup_complete','1')"
        )

    # ── Generic app_config key/value store (used for "Remember Me" etc.) ──
    def get_config(self, key, default=None):
        result = self.fetchone("SELECT value FROM app_config WHERE key=?", (key,))
        return result["value"] if result else default

    def set_config(self, key, value):
        self.execute(
            "INSERT OR REPLACE INTO app_config (key,value) VALUES (?,?)",
            (key, value)
        )

    def delete_config(self, key):
        self.execute("DELETE FROM app_config WHERE key=?", (key,))

    # ── Schema ────────────────────────────────────────────────────────────
    def _create_tables(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        schema = """
        CREATE TABLE IF NOT EXISTS app_config (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS school_info (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            address TEXT,
            phone TEXT,
            email TEXT,
            website TEXT,
            logo_path TEXT,
            bank_name TEXT,
            bank_account TEXT,
            stamp_path TEXT,
            principal TEXT,
            established TEXT,
            motto TEXT,
            city TEXT,
            country TEXT DEFAULT 'Pakistan',
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE,
            password_hash TEXT NOT NULL,
            full_name TEXT,
            role TEXT NOT NULL DEFAULT 'staff',
            is_active INTEGER DEFAULT 1,
            last_login DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            avatar_path TEXT,
            phone TEXT,
            security_question TEXT,
            security_answer_hash TEXT
        );

        CREATE TABLE IF NOT EXISTS login_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            ip_address TEXT,
            status TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS academic_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            start_date DATE,
            end_date DATE,
            is_active INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            level INTEGER,
            is_final_class INTEGER DEFAULT 0,
            session_id INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES academic_sessions(id)
        );

        CREATE TABLE IF NOT EXISTS sections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            capacity INTEGER DEFAULT 40,
            room TEXT,
            FOREIGN KEY (class_id) REFERENCES classes(id)
        );

        CREATE TABLE IF NOT EXISTS subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            code TEXT,
            class_id INTEGER,
            teacher_id INTEGER,
            is_optional INTEGER DEFAULT 0,
            FOREIGN KEY (class_id) REFERENCES classes(id)
        );

        CREATE TABLE IF NOT EXISTS admissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admission_no TEXT UNIQUE,
            full_name TEXT NOT NULL,
            gender TEXT,
            dob DATE,
            b_form_cnic TEXT,
            blood_group TEXT,
            religion TEXT,
            address TEXT,
            previous_school TEXT,
            photo_path TEXT,
            father_name TEXT,
            mother_name TEXT,
            father_cnic TEXT,
            father_occupation TEXT,
            father_phone TEXT,
            mother_phone TEXT,
            parent_email TEXT,
            emergency_contact TEXT,
            applied_class_id INTEGER,
            section_id INTEGER,
            session_id INTEGER,
            transport INTEGER DEFAULT 0,
            transport_route TEXT,
            status TEXT DEFAULT 'pending',
            applied_date DATE DEFAULT CURRENT_DATE,
            approved_date DATE,
            approved_by INTEGER,
            rejection_reason TEXT,
            birth_cert_path TEXT,
            prev_result_path TEXT,
            transfer_cert_path TEXT,
            parent_cnic_path TEXT,
            notes TEXT,
            FOREIGN KEY (applied_class_id) REFERENCES classes(id),
            FOREIGN KEY (session_id) REFERENCES academic_sessions(id)
        );

        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT UNIQUE NOT NULL,
            admission_id INTEGER UNIQUE,
            full_name TEXT NOT NULL,
            gender TEXT,
            dob DATE,
            b_form_cnic TEXT,
            blood_group TEXT,
            religion TEXT,
            address TEXT,
            photo_path TEXT,
            father_name TEXT,
            mother_name TEXT,
            father_cnic TEXT,
            father_occupation TEXT,
            father_phone TEXT,
            mother_phone TEXT,
            parent_email TEXT,
            emergency_contact TEXT,
            class_id INTEGER,
            section_id INTEGER,
            session_id INTEGER,
            roll_number TEXT,
            status TEXT DEFAULT 'active',
            qr_code_path TEXT,
            behavior_score INTEGER DEFAULT 100,
            transport INTEGER DEFAULT 0,
            transport_route TEXT,
            enrollment_date DATE DEFAULT CURRENT_DATE,
            FOREIGN KEY (class_id) REFERENCES classes(id),
            FOREIGN KEY (section_id) REFERENCES sections(id),
            FOREIGN KEY (session_id) REFERENCES academic_sessions(id),
            FOREIGN KEY (admission_id) REFERENCES admissions(id)
        );

        CREATE TABLE IF NOT EXISTS fee_structures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_id INTEGER NOT NULL,
            session_id INTEGER,
            admission_fee REAL DEFAULT 0,
            monthly_fee REAL DEFAULT 0,
            exam_fee REAL DEFAULT 0,
            computer_fee REAL DEFAULT 0,
            transport_fee REAL DEFAULT 0,
            misc_charges REAL DEFAULT 0,
            late_fine_per_day REAL DEFAULT 50,
            due_date_day INTEGER DEFAULT 10,
            FOREIGN KEY (class_id) REFERENCES classes(id)
        );

        CREATE TABLE IF NOT EXISTS fee_vouchers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            voucher_id TEXT UNIQUE NOT NULL,
            student_id INTEGER NOT NULL,
            month TEXT,
            year INTEGER,
            admission_fee REAL DEFAULT 0,
            monthly_fee REAL DEFAULT 0,
            exam_fee REAL DEFAULT 0,
            computer_fee REAL DEFAULT 0,
            transport_fee REAL DEFAULT 0,
            misc_charges REAL DEFAULT 0,
            discount REAL DEFAULT 0,
            scholarship REAL DEFAULT 0,
            fine REAL DEFAULT 0,
            total_amount REAL NOT NULL,
            paid_amount REAL DEFAULT 0,
            remaining_amount REAL,
            due_date DATE,
            paid_date DATE,
            status TEXT DEFAULT 'pending',
            payment_method TEXT,
            transaction_ref TEXT,
            notes TEXT,
            generated_by INTEGER,
            generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            qr_code_path TEXT,
            FOREIGN KEY (student_id) REFERENCES students(id)
        );

        CREATE TABLE IF NOT EXISTS voucher_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            voucher_id INTEGER,
            changed_by INTEGER,
            prev_status TEXT,
            new_status TEXT,
            prev_paid REAL,
            new_paid REAL,
            notes TEXT,
            changed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (voucher_id) REFERENCES fee_vouchers(id)
        );

        CREATE TABLE IF NOT EXISTS discounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            discount_type TEXT,
            percentage REAL,
            amount REAL,
            reason TEXT,
            valid_from DATE,
            valid_to DATE,
            approved_by INTEGER,
            FOREIGN KEY (student_id) REFERENCES students(id)
        );

        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            date DATE NOT NULL,
            status TEXT NOT NULL,
            class_id INTEGER,
            section_id INTEGER,
            marked_by INTEGER,
            time_in TEXT,
            qr_verified INTEGER DEFAULT 0,
            remarks TEXT,
            UNIQUE(student_id, date),
            FOREIGN KEY (student_id) REFERENCES students(id)
        );

        CREATE TABLE IF NOT EXISTS staff (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id TEXT UNIQUE NOT NULL,
            user_id INTEGER,
            full_name TEXT NOT NULL,
            gender TEXT,
            dob DATE,
            cnic TEXT,
            phone TEXT,
            email TEXT,
            address TEXT,
            designation TEXT,
            department TEXT,
            qualification TEXT,
            joining_date DATE,
            salary REAL,
            bank_account TEXT,
            photo_path TEXT,
            status TEXT DEFAULT 'active',
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS staff_attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            staff_id INTEGER NOT NULL,
            date DATE NOT NULL,
            status TEXT NOT NULL,
            time_in TEXT,
            time_out TEXT,
            remarks TEXT,
            UNIQUE(staff_id, date),
            FOREIGN KEY (staff_id) REFERENCES staff(id)
        );

        CREATE TABLE IF NOT EXISTS leave_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            staff_id INTEGER,
            leave_type TEXT,
            from_date DATE,
            to_date DATE,
            reason TEXT,
            status TEXT DEFAULT 'pending',
            approved_by INTEGER,
            applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (staff_id) REFERENCES staff(id)
        );

        CREATE TABLE IF NOT EXISTS exams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            exam_type TEXT,
            class_id INTEGER,
            session_id INTEGER,
            start_date DATE,
            end_date DATE,
            result_date DATE,
            status TEXT DEFAULT 'scheduled',
            created_by INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (class_id) REFERENCES classes(id)
        );

        CREATE TABLE IF NOT EXISTS exam_subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_id INTEGER NOT NULL,
            subject_id INTEGER NOT NULL,
            total_marks REAL DEFAULT 100,
            passing_marks REAL DEFAULT 40,
            exam_date DATE,
            exam_time TEXT,
            FOREIGN KEY (exam_id) REFERENCES exams(id),
            FOREIGN KEY (subject_id) REFERENCES subjects(id)
        );

        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            exam_id INTEGER NOT NULL,
            subject_id INTEGER NOT NULL,
            obtained_marks REAL,
            total_marks REAL,
            grade TEXT,
            remarks TEXT,
            entered_by INTEGER,
            entered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(student_id, exam_id, subject_id),
            FOREIGN KEY (student_id) REFERENCES students(id),
            FOREIGN KEY (exam_id) REFERENCES exams(id)
        );

        CREATE TABLE IF NOT EXISTS timetable (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_id INTEGER NOT NULL,
            section_id INTEGER NOT NULL DEFAULT 0,
            subject_id INTEGER NOT NULL,
            teacher_id INTEGER,
            day TEXT NOT NULL,
            period INTEGER NOT NULL,
            start_time TEXT,
            end_time TEXT,
            room TEXT,
            UNIQUE(class_id, section_id, day, period),
            FOREIGN KEY (class_id) REFERENCES classes(id),
            FOREIGN KEY (subject_id) REFERENCES subjects(id)
        );

        CREATE TABLE IF NOT EXISTS homework (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            class_id INTEGER,
            section_id INTEGER,
            subject_id INTEGER,
            assigned_by INTEGER,
            title TEXT NOT NULL,
            description TEXT,
            due_date DATE,
            assigned_date DATE DEFAULT CURRENT_DATE,
            FOREIGN KEY (class_id) REFERENCES classes(id)
        );

        CREATE TABLE IF NOT EXISTS promotions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            from_class_id INTEGER,
            to_class_id INTEGER,
            from_session_id INTEGER,
            to_session_id INTEGER,
            promoted_by INTEGER,
            promoted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT,
            remarks TEXT,
            FOREIGN KEY (student_id) REFERENCES students(id)
        );

        CREATE TABLE IF NOT EXISTS alumni (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER UNIQUE,
            passed_out_year INTEGER,
            final_class_id INTEGER,
            final_result TEXT,
            contact_updated TEXT,
            FOREIGN KEY (student_id) REFERENCES students(id)
        );

        CREATE TABLE IF NOT EXISTS behavior_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            category TEXT,
            description TEXT,
            points INTEGER DEFAULT 0,
            logged_by INTEGER,
            log_date DATE DEFAULT CURRENT_DATE,
            FOREIGN KEY (student_id) REFERENCES students(id)
        );

        CREATE TABLE IF NOT EXISTS certificates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            cert_type TEXT,
            cert_date DATE DEFAULT CURRENT_DATE,
            description TEXT,
            file_path TEXT,
            issued_by INTEGER,
            FOREIGN KEY (student_id) REFERENCES students(id)
        );

        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT,
            message TEXT,
            type TEXT DEFAULT 'info',
            is_read INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT,
            module TEXT,
            description TEXT,
            ip TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS backups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            path TEXT,
            size INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by INTEGER,
            notes TEXT
        );

        CREATE TABLE IF NOT EXISTS parent_access (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER UNIQUE,
            access_code TEXT UNIQUE,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students(id)
        );

        CREATE TABLE IF NOT EXISTS salary_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            staff_id INTEGER NOT NULL,
            month TEXT,
            year INTEGER,
            basic_salary REAL,
            allowances REAL DEFAULT 0,
            deductions REAL DEFAULT 0,
            net_salary REAL,
            payment_date DATE,
            payment_method TEXT,
            status TEXT DEFAULT 'pending',
            processed_by INTEGER,
            FOREIGN KEY (staff_id) REFERENCES staff(id)
        );

        CREATE INDEX IF NOT EXISTS idx_students_class ON students(class_id);
        CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance(student_id);
        CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date);
        CREATE INDEX IF NOT EXISTS idx_vouchers_student ON fee_vouchers(student_id);
        CREATE INDEX IF NOT EXISTS idx_results_student ON results(student_id);
        CREATE INDEX IF NOT EXISTS idx_results_exam ON results(exam_id);
        """
        for stmt in schema.split(';'):
            stmt = stmt.strip()
            if stmt:
                try:
                    cursor.execute(stmt)
                except sqlite3.Error as e:
                    if 'already exists' not in str(e):
                        logger.error(f"Schema error: {e}")
        conn.commit()

        # Run migrations for columns added in V2
        self._migrate_v2(cursor, conn)
        logger.info("Database schema created/verified.")

    def _migrate_v2(self, cursor, conn):
        """Add new columns to existing databases without breaking anything."""
        migrations = [
            ("admissions", "birth_cert_path",    "TEXT DEFAULT ''"),
            ("admissions", "prev_result_path",   "TEXT DEFAULT ''"),
            ("admissions", "transfer_cert_path", "TEXT DEFAULT ''"),
            ("admissions", "parent_cnic_path",   "TEXT DEFAULT ''"),
            ("attendance", "qr_verified",         "INTEGER DEFAULT 0"),
            ("users",      "security_question",      "TEXT"),
            ("users",      "security_answer_hash",   "TEXT"),
        ]
        for table, col, col_def in migrations:
            try:
                cursor.execute(f"ALTER TABLE {table} ADD COLUMN {col} {col_def}")
                conn.commit()
            except sqlite3.OperationalError:
                pass  # column already exists

    def reset_database(self):
        """Reset database to trigger setup wizard on next startup.
        
        Clears all app_config entries and specifically sets setup_complete to '0'.
        This forces the application to show the setup wizard.
        """
        try:
            self.execute("DELETE FROM app_config")
            self.execute("INSERT INTO app_config (key, value) VALUES ('setup_complete', '0')")
            logger.info("Database reset to setup mode. Setup wizard will show on next startup.")
            return True
        except Exception as e:
            logger.error(f"Failed to reset database: {e}")
            return False

    def reset_and_clear_database(self):
        """Complete database reset - deletes all data and triggers setup wizard.
        
        Use this for a full reset that clears all school data.
        """
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # List of all data tables (not config tables)
            data_tables = [
                'admissions', 'students', 'staff', 'classes', 'sections',
                'subjects', 'academic_sessions', 'fee_structures', 'fee_vouchers',
                'voucher_history', 'discounts', 'attendance', 'staff_attendance',
                'leave_requests', 'exams', 'exam_subjects', 'results', 'timetable',
                'homework', 'promotions', 'alumni', 'behavior_logs', 'certificates',
                'notifications', 'activity_logs', 'backups', 'parent_access',
                'salary_records', 'login_history', 'users'
            ]
            
            # Clear all data tables
            for table in data_tables:
                try:
                    cursor.execute(f"DELETE FROM {table}")
                except sqlite3.OperationalError:
                    pass  # table might not exist yet
            
            # Reset app config
            cursor.execute("DELETE FROM app_config")
            cursor.execute("INSERT INTO app_config (key, value) VALUES ('setup_complete', '0')")
            conn.commit()
            
            logger.info("Database completely cleared. Setup wizard will show on next startup.")
            return True
        except Exception as e:
            logger.error(f"Failed to complete database reset: {e}")
            return False
