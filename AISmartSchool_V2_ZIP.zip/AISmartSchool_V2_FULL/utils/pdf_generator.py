"""
PDF Generator V2 — All 10 requirements implemented:
  1. Animations: PDF is opened with a smooth fade (handled in caller)
  2. QR on every document (fee voucher, ID card, result card)
  3. School isolation: db_path passed per call (unchanged)
  4. Fully offline — no network calls
  5. 2-sided ID card, 4 per page per side
  6. Bulk generation + direct print
  7. School logo + name on every document
  8. Printable timetable with subject+teacher, school+class info
  9. (Admission document upload handled in admission_view)
  10. Live school info from SchoolContext singleton
"""
import os, subprocess, platform
from datetime import datetime

OUTPUT_DIR = os.path.join(os.path.expanduser("~"), ".ai_eduhub_erp", "exports")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def _open(path):
    try:
        if platform.system() == "Windows":   os.startfile(path)
        elif platform.system() == "Darwin":  subprocess.call(["open", path])
        else:                                subprocess.call(["xdg-open", path])
    except Exception:
        pass


def _direct_print(path):
    """Send PDF directly to default printer."""
    try:
        if platform.system() == "Windows":
            os.startfile(path, "print")
        elif platform.system() == "Darwin":
            subprocess.call(["lpr", path])
        else:
            subprocess.call(["lpr", path])
    except Exception:
        _open(path)


def _rl():
    try:
        from reportlab.lib.pagesizes import A4, landscape, portrait
        from reportlab.lib import colors
        from reportlab.lib.units import mm
        from reportlab.pdfgen import canvas
        return A4, landscape, portrait, colors, mm, canvas
    except ImportError:
        raise ImportError("ReportLab not installed.\nRun: pip install reportlab")


def _draw_demo_watermark(c, W, H, colors):
    """Stamp a diagonal 'DEMO VERSION' watermark + contact footer on every
    generated PDF while the app is running in Demo Edition. No-op in the
    full (paid) version."""
    try:
        from core.demo_config import DEMO_MODE, WATERMARK_TEXT, FOOTER_CONTACT
    except Exception:
        return
    if not DEMO_MODE:
        return
    c.saveState()
    try:
        c.setFillColor(colors.HexColor("#94a3b8"))
        c.setFillAlpha(0.16)
    except Exception:
        c.setFillColor(colors.HexColor("#cbd5e1"))
    c.setFont("Helvetica-Bold", min(W, H) * 0.14)
    c.translate(W / 2, H / 2)
    c.rotate(38)
    c.drawCentredString(0, 0, WATERMARK_TEXT)
    c.restoreState()

    c.saveState()
    c.setFillColor(colors.HexColor("#dc2626"))
    c.setFont("Helvetica-Bold", 6.5)
    c.drawCentredString(W / 2, 4, FOOTER_CONTACT)
    c.restoreState()


def _load_logo(c, school_info, x, y, w, h, colors, mm):
    logo_path = (school_info or {}).get("logo_path", "") or ""
    if logo_path and os.path.exists(logo_path):
        try:
            c.drawImage(logo_path, x, y, width=w, height=h,
                        preserveAspectRatio=True, mask="auto")
            return
        except Exception:
            pass
    cx, cy = x + w/2, y + h/2
    r = min(w, h) / 2
    c.setFillColor(colors.HexColor("#1e3a8a"))
    c.circle(cx, cy, r, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", r * 0.9)
    school_name = (school_info or {}).get("name", "S") or "S"
    c.drawCentredString(cx, cy - r*0.3, school_name[0].upper())


def _draw_student_photo(c, student, x, y, w, h, colors):
    photo = (student or {}).get("photo_path", "") or ""
    if photo and os.path.exists(photo):
        try:
            c.drawImage(photo, x, y, width=w, height=h,
                        preserveAspectRatio=True, mask="auto")
            c.setStrokeColor(colors.HexColor("#cbd5e1"))
            c.setLineWidth(0.5)
            c.rect(x, y, w, h, stroke=1, fill=0)
            return
        except Exception:
            pass
    cx, cy = x + w/2, y + h/2
    r = min(w, h) / 2
    c.setFillColor(colors.HexColor("#dbeafe"))
    c.circle(cx, cy, r, stroke=0, fill=1)
    c.setStrokeColor(colors.HexColor("#2563eb"))
    c.setLineWidth(0.6)
    c.circle(cx, cy, r, stroke=1, fill=0)
    c.setFillColor(colors.HexColor("#1e3a8a"))
    c.setFont("Helvetica-Bold", r * 0.85)
    name = (student or {}).get("full_name", "?") or "?"
    c.drawCentredString(cx, cy - r*0.3, name[0].upper())


def _draw_qr(c, qr_path, x, y, size):
    """Draw QR code image, or placeholder box."""
    if qr_path and os.path.exists(qr_path):
        try:
            c.drawImage(qr_path, x, y, width=size, height=size,
                        preserveAspectRatio=True, mask="auto")
            return
        except Exception:
            pass
    # Placeholder
    from reportlab.lib import colors as _c
    c.setStrokeColor(_c.black)
    c.setFillColor(_c.white)
    c.rect(x, y, size, size, stroke=1, fill=1)
    c.setFillColor(_c.black)
    c.setFont("Helvetica", 5)
    c.drawCentredString(x + size/2, y + size/2, "QR")


# ═══════════════════════════════════════════════════════════════════
#  FEE VOUCHER  — Landscape A4, 3 copies, QR per copy
# ═══════════════════════════════════════════════════════════════════
def generate_fee_voucher(voucher_data, school_info=None, auto_print=False):
    from core.qr_engine import qr_for_voucher
    A4, landscape, portrait, colors, mm, cv = _rl()
    PAGE = landscape(A4)
    W, H = PAGE

    fname = f"voucher_{voucher_data.get('voucher_id','v')}.pdf"
    path  = os.path.join(OUTPUT_DIR, fname)
    c = cv.Canvas(path, pagesize=PAGE)

    school  = (school_info or {}).get("name", "AI EduHub ERP") or "AI EduHub ERP"
    address = (school_info or {}).get("address", "") or ""
    phone   = (school_info or {}).get("phone", "") or ""
    website = (school_info or {}).get("website", "") or ""
    bank    = (school_info or {}).get("bank_name", "") or ""
    bank_ac = (school_info or {}).get("bank_account", "") or ""

    COLS   = 3
    PAD    = 4 * mm
    CW     = (W - PAD * (COLS + 1)) / COLS
    LABELS = ["SCHOOL COPY", "BANK COPY", "STUDENT COPY"]

    fee_rows = [
        ("Tuition Fee",      voucher_data.get("monthly_fee",   0) or 0),
        ("Examination Fee",  voucher_data.get("exam_fee",      0) or 0),
        ("Computer Lab Fee", voucher_data.get("computer_fee",  0) or 0),
        ("Transport Fee",    voucher_data.get("transport_fee", 0) or 0),
        ("Misc. Charges",    voucher_data.get("misc_charges",  0) or 0),
        ("Fine / Penalty",   voucher_data.get("fine",          0) or 0),
    ]
    fee_rows   = [(l, v) for l, v in fee_rows if v]
    discount   = voucher_data.get("discount", 0) or 0
    scholarship= voucher_data.get("scholarship", 0) or 0
    total      = voucher_data.get("total_amount", 0) or 0

    # QR
    vid  = voucher_data.get("voucher_id", "V")
    due  = str(voucher_data.get("due_date", ""))
    qr_path = qr_for_voucher(vid, total, due)

    for col_idx, copy_label in enumerate(LABELS):
        X0 = PAD + col_idx * (CW + PAD)
        Y0 = PAD
        CH = H - PAD * 2

        # Card background
        c.setFillColor(colors.white)
        c.rect(X0, Y0, CW, CH, stroke=0, fill=1)

        # Outer border
        c.setStrokeColor(colors.HexColor("#1e3a8a"))
        c.setLineWidth(1.2)
        c.rect(X0, Y0, CW, CH, stroke=1, fill=0)

        # Copy label ribbon
        c.setFillColor(colors.HexColor("#1e3a8a"))
        c.rect(X0, Y0 + CH - 7*mm, CW, 7*mm, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 7)
        c.drawCentredString(X0 + CW/2, Y0 + CH - 5*mm, copy_label)

        # Header: logo + school name
        HEADER_H = 22*mm
        LOGO_W   = 14*mm
        _load_logo(c, school_info,
                   X0 + 2*mm, Y0 + CH - 7*mm - HEADER_H + 2*mm,
                   LOGO_W, HEADER_H - 4*mm, colors, mm)

        c.setFillColor(colors.HexColor("#0f172a"))
        c.setFont("Helvetica-Bold", 8.5)
        c.drawString(X0 + LOGO_W + 4*mm, Y0 + CH - 7*mm - 8*mm, school.upper())
        c.setFont("Helvetica", 6)
        if address:
            c.drawString(X0 + LOGO_W + 4*mm, Y0 + CH - 7*mm - 13*mm, address[:50])
        contact = "  |  ".join(filter(None, [phone, website]))
        if contact:
            c.drawString(X0 + LOGO_W + 4*mm, Y0 + CH - 7*mm - 18*mm, contact[:50])

        # Divider
        y_cur = Y0 + CH - 7*mm - HEADER_H
        c.setStrokeColor(colors.HexColor("#cbd5e1"))
        c.setLineWidth(0.5)
        c.line(X0 + 2*mm, y_cur, X0 + CW - 2*mm, y_cur)
        y_cur -= 2*mm

        # Fee Voucher title
        c.setFillColor(colors.HexColor("#1e3a8a"))
        c.setFont("Helvetica-Bold", 9)
        c.drawCentredString(X0 + CW/2, y_cur - 5*mm, "FEE VOUCHER")
        y_cur -= 8*mm

        # Student info
        def info_row(label, val, yy):
            c.setFillColor(colors.HexColor("#374151"))
            c.setFont("Helvetica-Bold", 6.5)
            c.drawString(X0 + 3*mm, yy, label + ":")
            c.setFont("Helvetica", 6.5)
            c.setFillColor(colors.black)
            c.drawString(X0 + 22*mm, yy, str(val or ""))

        info_row("Voucher No", voucher_data.get("voucher_id",""), y_cur); y_cur -= 5*mm
        info_row("Student",    voucher_data.get("student_name",""), y_cur); y_cur -= 5*mm
        info_row("Class",      voucher_data.get("class_name",""), y_cur); y_cur -= 5*mm
        info_row("Month",      f"{voucher_data.get('month','')} {voucher_data.get('year','')}", y_cur); y_cur -= 5*mm
        info_row("Due Date",   voucher_data.get("due_date",""), y_cur); y_cur -= 7*mm

        # Fee table header
        c.setFillColor(colors.HexColor("#e2e8f0"))
        c.rect(X0 + 2*mm, y_cur - 5*mm, CW - 4*mm, 5*mm, stroke=0, fill=1)
        c.setFillColor(colors.HexColor("#1e3a8a"))
        c.setFont("Helvetica-Bold", 6.5)
        c.drawString(X0 + 4*mm, y_cur - 3.5*mm, "Description")
        c.drawRightString(X0 + CW - 4*mm, y_cur - 3.5*mm, "Amount (Rs.)")
        y_cur -= 5*mm

        # Fee rows
        for desc, amt in fee_rows:
            c.setFillColor(colors.black)
            c.setFont("Helvetica", 6.5)
            c.drawString(X0 + 4*mm, y_cur - 3*mm, desc)
            c.drawRightString(X0 + CW - 4*mm, y_cur - 3*mm, f"{amt:,.0f}")
            y_cur -= 4.5*mm
            c.setStrokeColor(colors.HexColor("#f1f5f9"))
            c.line(X0 + 2*mm, y_cur, X0 + CW - 2*mm, y_cur)

        if discount:
            c.setFillColor(colors.HexColor("#16a34a"))
            c.setFont("Helvetica", 6.5)
            c.drawString(X0 + 4*mm, y_cur - 3*mm, "Discount")
            c.drawRightString(X0 + CW - 4*mm, y_cur - 3*mm, f"- {discount:,.0f}")
            y_cur -= 4.5*mm
        if scholarship:
            c.setFillColor(colors.HexColor("#16a34a"))
            c.setFont("Helvetica", 6.5)
            c.drawString(X0 + 4*mm, y_cur - 3*mm, "Scholarship")
            c.drawRightString(X0 + CW - 4*mm, y_cur - 3*mm, f"- {scholarship:,.0f}")
            y_cur -= 4.5*mm

        # Total
        c.setFillColor(colors.HexColor("#1e3a8a"))
        c.rect(X0 + 2*mm, y_cur - 6*mm, CW - 4*mm, 6*mm, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(X0 + 4*mm, y_cur - 4*mm, "TOTAL PAYABLE")
        c.drawRightString(X0 + CW - 4*mm, y_cur - 4*mm, f"Rs. {total:,.0f}")
        y_cur -= 8*mm

        # Bank info
        if bank:
            c.setFillColor(colors.HexColor("#374151"))
            c.setFont("Helvetica-Bold", 6)
            c.drawString(X0 + 3*mm, y_cur, f"Bank: {bank}")
            if bank_ac:
                c.drawString(X0 + 3*mm, y_cur - 4*mm, f"A/C: {bank_ac}")
            y_cur -= 10*mm

        # ── Signature section ────────────────────────────────────────────
        # Sits just above the bottom, left of the QR code
        QR_SIZE  = 18*mm
        SIG_Y    = Y0 + 3*mm + QR_SIZE          # top of signature area
        SIG_AREA_W = CW - QR_SIZE - 8*mm        # width available left of QR

        # Thin separator line above signatures
        c.setStrokeColor(colors.HexColor("#cbd5e1"))
        c.setLineWidth(0.4)
        c.line(X0 + 2*mm, SIG_Y + 1*mm, X0 + SIG_AREA_W + 2*mm, SIG_Y + 1*mm)

        # Three signature slots
        sig_labels = ["Cashier", "Accountant", "Parent / Guardian"]
        slot_w = SIG_AREA_W / 3

        for si, sig_lbl in enumerate(sig_labels):
            sx      = X0 + 2*mm + si * slot_w
            line_y  = SIG_Y - 5*mm          # signature line y
            lbl_y   = SIG_Y - 10*mm         # label below line

            # Signature line
            c.setStrokeColor(colors.HexColor("#334155"))
            c.setLineWidth(0.6)
            c.line(sx + 1*mm, line_y, sx + slot_w - 2*mm, line_y)

            # Label under the line
            c.setFillColor(colors.HexColor("#6b7280"))
            c.setFont("Helvetica", 5.5)
            c.drawCentredString(sx + slot_w / 2, lbl_y, sig_lbl)

        # QR code at bottom-right
        _draw_qr(c, qr_path, X0 + CW - QR_SIZE - 3*mm, Y0 + 3*mm, QR_SIZE)

        # Dashed cut line between columns (except last)
        if col_idx < COLS - 1:
            cut_x = X0 + CW + PAD/2
            c.setStrokeColor(colors.HexColor("#94a3b8"))
            c.setLineWidth(0.4)
            c.setDash(3, 3)
            c.line(cut_x, PAD, cut_x, H - PAD)
            c.setDash()

    _draw_demo_watermark(c, W, H, colors)
    c.save()
    if auto_print:
        _direct_print(path)
    else:
        _open(path)
    return path


# ═══════════════════════════════════════════════════════════════════
#  ID CARDS — Advanced stylish design, double-sided, 4 per page
# ═══════════════════════════════════════════════════════════════════
def generate_id_cards(students, school_info=None, auto_print=False):
    """
    Advanced ID card design:
    Front: dark gradient header, holographic accent strip, photo, QR
    Back:  light card, contact info, barcode strip, return notice
    4 cards per page, duplex-ready (back pages mirror cols).
    """
    from core.qr_engine import qr_for_student
    A4, landscape, portrait, colors, mm, cv = _rl()
    PAGE = portrait(A4)
    W, H = PAGE

    fname = f"id_cards_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    path  = os.path.join(OUTPUT_DIR, fname)
    c = cv.Canvas(path, pagesize=PAGE)

    school   = (school_info or {}).get("name", "AI EduHub ERP") or "AI EduHub ERP"
    motto    = (school_info or {}).get("motto", "") or ""
    address  = (school_info or {}).get("address", "") or ""
    phone    = (school_info or {}).get("phone", "") or ""
    session  = (school_info or {}).get("session", "") or ""

    # CR80 card dimensions scaled to fit 2×2 on A4 portrait with margins
    CARD_W   = 88 * mm
    CARD_H   = 56 * mm
    COLS, ROWS = 2, 2
    PER_PAGE = COLS * ROWS

    # Auto-centre cards on A4
    MARGIN_X = (W - COLS * CARD_W) / (COLS + 1)
    MARGIN_Y = (H - ROWS * CARD_H) / (ROWS + 1)

    # ── Colour palette ─────────────────────────────────────────────
    COL_NAVY      = colors.HexColor("#0a1628")
    COL_BLUE      = colors.HexColor("#1e3a8a")
    COL_ACCENT    = colors.HexColor("#2563eb")
    COL_GOLD      = colors.HexColor("#f59e0b")
    COL_CYAN      = colors.HexColor("#06b6d4")
    COL_WHITE     = colors.white
    COL_LIGHT     = colors.HexColor("#f0f4ff")
    COL_GRAY      = colors.HexColor("#64748b")
    COL_BORDER    = colors.HexColor("#1d4ed8")
    COL_RED       = colors.HexColor("#dc2626")
    COL_BACK_BG   = colors.HexColor("#f8fafc")
    COL_BACK_TOP  = colors.HexColor("#1e3a8a")

    def draw_front(student, X0, Y0):
        # ── Outer card with rounded corners ───────────────────────
        # Shadow effect (offset rect)
        c.setFillColor(colors.HexColor("#00000022", hasAlpha=True))
        c.roundRect(X0 + 0.8*mm, Y0 - 0.8*mm, CARD_W, CARD_H, 3.5*mm, stroke=0, fill=1)

        # Main card background — dark navy
        c.setFillColor(COL_NAVY)
        c.roundRect(X0, Y0, CARD_W, CARD_H, 3.5*mm, stroke=0, fill=1)

        # ── Header band (top 16mm) ─────────────────────────────────
        HEADER_H = 16 * mm
        # Gradient simulation: two overlapping rects
        c.setFillColor(COL_BLUE)
        c.roundRect(X0, Y0 + CARD_H - HEADER_H, CARD_W, HEADER_H, 3.5*mm, stroke=0, fill=1)
        # Cover bottom curve of header
        c.setFillColor(COL_BLUE)
        c.rect(X0, Y0 + CARD_H - HEADER_H, CARD_W, HEADER_H / 2, stroke=0, fill=1)
        # Accent stripe on header right edge
        c.setFillColor(COL_ACCENT)
        c.rect(X0 + CARD_W - 4*mm, Y0 + CARD_H - HEADER_H, 4*mm, HEADER_H / 2, stroke=0, fill=1)
        c.roundRect(X0 + CARD_W - 4*mm, Y0 + CARD_H - HEADER_H,
                    4*mm, HEADER_H, 3.5*mm, stroke=0, fill=1)

        # ── Decorative diagonal accent line ───────────────────────
        c.setStrokeColor(COL_CYAN)
        c.setLineWidth(0.6)
        c.setDash(1, 0)
        c.line(X0 + CARD_W * 0.55, Y0 + CARD_H - HEADER_H,
               X0 + CARD_W - 5*mm,  Y0 + CARD_H - HEADER_H + HEADER_H * 0.6)

        # ── School logo in header ──────────────────────────────────
        LOGO_SZ = 11 * mm
        logo_x  = X0 + 3*mm
        logo_y  = Y0 + CARD_H - HEADER_H + (HEADER_H - LOGO_SZ) / 2
        _load_logo(c, school_info, logo_x, logo_y, LOGO_SZ, LOGO_SZ, colors, mm)

        # ── School name & label ────────────────────────────────────
        c.setFillColor(COL_WHITE)
        c.setFont("Helvetica-Bold", 7.5)
        c.drawString(X0 + 16*mm, Y0 + CARD_H - 7*mm, school.upper()[:26])
        if motto:
            c.setFont("Helvetica", 5)
            c.setFillColor(COL_CYAN)
            c.drawString(X0 + 16*mm, Y0 + CARD_H - 11.5*mm, motto[:32])

        # "STUDENT ID CARD" label — right side of header
        c.setFillColor(COL_GOLD)
        c.setFont("Helvetica-Bold", 5.5)
        c.drawRightString(X0 + CARD_W - 5.5*mm, Y0 + CARD_H - 6*mm, "STUDENT")
        c.drawRightString(X0 + CARD_W - 5.5*mm, Y0 + CARD_H - 10.5*mm, "ID CARD")

        # ── Gold separator line ────────────────────────────────────
        c.setStrokeColor(COL_GOLD)
        c.setLineWidth(0.8)
        c.line(X0 + 3*mm, Y0 + CARD_H - HEADER_H - 0.3*mm,
               X0 + CARD_W - 3*mm, Y0 + CARD_H - HEADER_H - 0.3*mm)

        # ── Student photo ──────────────────────────────────────────
        PHOTO_W = 18 * mm
        PHOTO_H = 22 * mm
        photo_x = X0 + 3.5*mm
        photo_y = Y0 + CARD_H - HEADER_H - PHOTO_H - 3*mm
        # Photo frame
        c.setStrokeColor(COL_GOLD)
        c.setLineWidth(0.8)
        c.roundRect(photo_x - 0.5*mm, photo_y - 0.5*mm,
                    PHOTO_W + 1*mm, PHOTO_H + 1*mm, 1*mm, stroke=1, fill=0)
        _draw_student_photo(c, student, photo_x, photo_y, PHOTO_W, PHOTO_H, colors)

        # ── Student info (right of photo) ──────────────────────────
        info_x   = X0 + 3.5*mm + PHOTO_W + 3.5*mm
        info_w   = CARD_W - PHOTO_W - 9*mm
        info_y   = photo_y + PHOTO_H

        def srow(label, val, yy, val_size=6.5):
            c.setFillColor(COL_CYAN)
            c.setFont("Helvetica-Bold", 5.3)
            c.drawString(info_x, yy + 0.8*mm, label.upper())
            c.setFillColor(COL_WHITE)
            c.setFont("Helvetica-Bold", val_size)
            c.drawString(info_x, yy - 3.8*mm, str(val or "")[:22])

        # Name — larger
        c.setFillColor(COL_WHITE)
        c.setFont("Helvetica-Bold", 7.5)
        name = student.get("full_name", "") or ""
        # Wrap name if too long
        if len(name) > 18:
            c.drawString(info_x, info_y - 1*mm, name[:18])
            c.setFont("Helvetica-Bold", 6.5)
            c.drawString(info_x, info_y - 5*mm, name[18:36])
            iy = info_y - 9*mm
        else:
            c.drawString(info_x, info_y - 1*mm, name)
            iy = info_y - 6*mm

        srow("Student ID", student.get("student_id", ""),  iy);       iy -= 8.5*mm
        srow("Class",      f"{student.get('class_name','')} — {student.get('section_name','')}", iy); iy -= 8.5*mm
        srow("Father",     student.get("father_name", ""),  iy)

        # ── Holographic accent bottom strip ───────────────────────
        STRIP_H = 6 * mm
        # Layered colour blocks simulating hologram
        for xi, col_hex in enumerate(["#1e3a8a","#1d4ed8","#2563eb","#3b82f6","#60a5fa",
                                      "#93c5fd","#60a5fa","#3b82f6","#2563eb","#1d4ed8"]):
            seg_w = CARD_W / 10
            c.setFillColor(colors.HexColor(col_hex))
            c.roundRect(X0 + xi * seg_w, Y0, seg_w + 0.2*mm, STRIP_H,
                        1*mm if xi == 0 else (1*mm if xi == 9 else 0), stroke=0, fill=1)
        # Cover top of strip straight
        c.setFillColor(COL_NAVY)
        c.rect(X0, Y0 + STRIP_H / 2, CARD_W, STRIP_H / 2, stroke=0, fill=1)

        # ── Session text on strip ──────────────────────────────────
        sess = student.get("session_name", "") or session
        c.setFillColor(COL_WHITE)
        c.setFont("Helvetica-Bold", 5)
        c.drawCentredString(X0 + CARD_W / 2, Y0 + STRIP_H / 2 + 1.5*mm,
                            f"SESSION: {sess}" if sess else "")

        # ── QR code bottom-right ───────────────────────────────────
        qr_path = qr_for_student(
            student.get("student_id", ""), student.get("full_name", ""),
            student.get("class_name", ""), student.get("section_name", "")
        )
        QR_SZ = 14 * mm
        qr_x  = X0 + CARD_W - QR_SZ - 3*mm
        qr_y  = Y0 + STRIP_H + 1.5*mm
        # QR white background
        c.setFillColor(COL_WHITE)
        c.roundRect(qr_x - 1*mm, qr_y - 1*mm, QR_SZ + 2*mm, QR_SZ + 2*mm,
                    1*mm, stroke=0, fill=1)
        _draw_qr(c, qr_path, qr_x, qr_y, QR_SZ)

        # ── Outer border glow ─────────────────────────────────────
        c.setStrokeColor(COL_BORDER)
        c.setLineWidth(1.0)
        c.roundRect(X0, Y0, CARD_W, CARD_H, 3.5*mm, stroke=1, fill=0)
        # Inner subtle border
        c.setStrokeColor(colors.HexColor("#2563eb44", hasAlpha=True))
        c.setLineWidth(0.4)
        c.roundRect(X0 + 1*mm, Y0 + 1*mm, CARD_W - 2*mm, CARD_H - 2*mm,
                    3*mm, stroke=1, fill=0)

    def draw_back(student, X0, Y0):
        # ── Shadow ─────────────────────────────────────────────────
        c.setFillColor(colors.HexColor("#00000022", hasAlpha=True))
        c.roundRect(X0 + 0.8*mm, Y0 - 0.8*mm, CARD_W, CARD_H, 3.5*mm, stroke=0, fill=1)

        # ── Card background — light ────────────────────────────────
        c.setFillColor(COL_BACK_BG)
        c.roundRect(X0, Y0, CARD_W, CARD_H, 3.5*mm, stroke=0, fill=1)

        # ── Top header band ────────────────────────────────────────
        HDR_H = 11 * mm
        c.setFillColor(COL_BACK_TOP)
        c.roundRect(X0, Y0 + CARD_H - HDR_H, CARD_W, HDR_H, 3.5*mm, stroke=0, fill=1)
        c.setFillColor(COL_BACK_TOP)
        c.rect(X0, Y0 + CARD_H - HDR_H, CARD_W, HDR_H / 2, stroke=0, fill=1)

        # Clean thin accent stripe on header (replaces the old dot pattern,
        # which had a colour-parsing bug that rendered as bright yellow)
        c.setStrokeColor(COL_CYAN)
        c.setLineWidth(0.5)
        c.line(X0 + CARD_W * 0.5, Y0 + CARD_H - HDR_H,
               X0 + CARD_W - 4*mm, Y0 + CARD_H - HDR_H + HDR_H * 0.55)

        # School name on header
        c.setFillColor(COL_WHITE)
        c.setFont("Helvetica-Bold", 6.8)
        c.drawCentredString(X0 + CARD_W / 2, Y0 + CARD_H - 4.5*mm,
                            school.upper()[:34])
        c.setFillColor(COL_GOLD)
        c.setFont("Helvetica-Bold", 4.8)
        c.drawCentredString(X0 + CARD_W / 2, Y0 + CARD_H - 8.8*mm, "STUDENT ID CARD — BACK")

        # ── Gold accent line ───────────────────────────────────────
        c.setStrokeColor(COL_GOLD)
        c.setLineWidth(0.8)
        c.line(X0 + 3*mm, Y0 + CARD_H - HDR_H - 0.4*mm,
               X0 + CARD_W - 3*mm, Y0 + CARD_H - HDR_H - 0.4*mm)

        # ── Two-column body: info (left ~62%) | QR + blood (right ~38%) ─
        SECTION_X = X0 + 3.5*mm
        COL_SPLIT = X0 + CARD_W * 0.62
        ey = Y0 + CARD_H - HDR_H - 4*mm

        c.setFillColor(COL_ACCENT)
        c.setFont("Helvetica-Bold", 5.4)
        c.drawString(SECTION_X, ey, "GUARDIAN & CONTACT")
        ey -= 1.3*mm
        c.setStrokeColor(colors.HexColor("#cbd5e1"))
        c.setLineWidth(0.4)
        c.line(SECTION_X, ey, COL_SPLIT - 2*mm, ey)
        ey -= 4*mm

        def brow(label, val, yy, val_col="#1e293b"):
            c.setFillColor(COL_GRAY)
            c.setFont("Helvetica", 4.9)
            c.drawString(SECTION_X, yy, label + ":")
            c.setFillColor(colors.HexColor(val_col))
            c.setFont("Helvetica-Bold", 5.2)
            c.drawString(SECTION_X + 15*mm, yy, str(val or "—")[:22])

        row_gap = 4.4*mm
        brow("Father",  student.get("father_name", ""),  ey);  ey -= row_gap
        brow("Ph.",     student.get("father_phone", ""), ey);  ey -= row_gap
        brow("Mother",  student.get("mother_name", ""),  ey);  ey -= row_gap
        brow("Ph.",     student.get("mother_phone", ""), ey);  ey -= row_gap
        brow("Address", student.get("address", ""),      ey);  ey -= row_gap

        # ── Right column: QR code + Blood Group badge ───────────────
        QR_SZ = 17 * mm
        qr_x  = COL_SPLIT + (CARD_W - (COL_SPLIT - X0) - QR_SZ) / 2 - 1*mm
        qr_y  = Y0 + CARD_H - HDR_H - QR_SZ - 5*mm
        qr_path = qr_for_student(
            student.get("student_id", ""), student.get("full_name", ""),
            student.get("class_name", ""), student.get("section_name", "")
        )
        c.setFillColor(COL_WHITE)
        c.setStrokeColor(colors.HexColor("#cbd5e1"))
        c.setLineWidth(0.6)
        c.roundRect(qr_x - 1.2*mm, qr_y - 1.2*mm, QR_SZ + 2.4*mm, QR_SZ + 2.4*mm,
                    1.2*mm, stroke=1, fill=1)
        _draw_qr(c, qr_path, qr_x, qr_y, QR_SZ)
        c.setFillColor(COL_GRAY)
        c.setFont("Helvetica", 4.3)
        c.drawCentredString(qr_x + QR_SZ / 2, qr_y - 3*mm, "Scan to verify")

        bg_y = qr_y - 8*mm
        blood = student.get("blood_group", "") or "—"
        c.setFillColor(colors.HexColor("#dc2626"))
        c.roundRect(qr_x, bg_y - 4.5*mm, QR_SZ, 6.5*mm, 1.2*mm, stroke=0, fill=1)
        c.setFillColor(COL_WHITE)
        c.setFont("Helvetica-Bold", 5.2)
        c.drawCentredString(qr_x + QR_SZ / 2, bg_y - 2.5*mm, f"BLOOD: {blood}")

        # ── School contact — full width, tight to bottom strip ──────
        c.setStrokeColor(colors.HexColor("#e2e8f0"))
        c.setLineWidth(0.4)
        contact_y = Y0 + 11.5*mm
        c.line(SECTION_X, contact_y, X0 + CARD_W - 3.5*mm, contact_y)
        c.setFillColor(COL_GRAY)
        c.setFont("Helvetica", 4.6)
        contact_line = "  •  ".join(x for x in [address[:34], f"Tel: {phone}" if phone else ""] if x)
        if contact_line:
            c.drawCentredString(X0 + CARD_W / 2, contact_y - 3.4*mm, contact_line)

        # ── "If found" return strip ────────────────────────────────
        STRIP_H = 7.5 * mm
        c.setFillColor(colors.HexColor("#1e3a8a"))
        c.roundRect(X0, Y0, CARD_W, STRIP_H, 3.5*mm, stroke=0, fill=1)
        c.setFillColor(colors.HexColor("#1e3a8a"))
        c.rect(X0, Y0 + STRIP_H / 2, CARD_W, STRIP_H / 2, stroke=0, fill=1)
        c.setFillColor(COL_WHITE)
        c.setFont("Helvetica-BoldOblique", 5.2)
        c.drawCentredString(X0 + CARD_W / 2, Y0 + 2.6*mm,
                            f"If found, please return to {school[:30]}")

        # ── Outer border ───────────────────────────────────────────
        c.setStrokeColor(COL_BORDER)
        c.setLineWidth(1.0)
        c.roundRect(X0, Y0, CARD_W, CARD_H, 3.5*mm, stroke=1, fill=0)

    # ── Render all pages ───────────────────────────────────────────
    for page_start in range(0, len(students), PER_PAGE):
        chunk = students[page_start:page_start + PER_PAGE]

        # Front sides
        for idx, student in enumerate(chunk):
            col = idx % COLS
            row = idx // COLS
            X0  = MARGIN_X + col * (CARD_W + MARGIN_X)
            Y0  = H - MARGIN_Y - (row + 1) * CARD_H - row * MARGIN_Y
            draw_front(student, X0, Y0)
        _draw_demo_watermark(c, W, H, colors)
        c.showPage()

        # Back sides — mirror columns for duplex alignment
        for idx, student in enumerate(chunk):
            col = (COLS - 1) - (idx % COLS)
            row = idx // COLS
            X0  = MARGIN_X + col * (CARD_W + MARGIN_X)
            Y0  = H - MARGIN_Y - (row + 1) * CARD_H - row * MARGIN_Y
            draw_back(student, X0, Y0)
        _draw_demo_watermark(c, W, H, colors)
        c.showPage()

    c.save()
    if auto_print:
        _direct_print(path)
    else:
        _open(path)
    return path


# ═══════════════════════════════════════════════════════════════════
#  RESULT CARD — Advanced stylish design, Portrait A4
# ═══════════════════════════════════════════════════════════════════
def generate_result_card(student, results, exam_info, school_info=None, auto_print=False):
    from core.qr_engine import qr_for_result
    A4, landscape, portrait, colors, mm, cv = _rl()
    PAGE = portrait(A4)
    W, H = PAGE

    fname = f"result_{student.get('student_id','s')}_{exam_info.get('id','e')}.pdf"
    path  = os.path.join(OUTPUT_DIR, fname)
    c = cv.Canvas(path, pagesize=PAGE)

    school    = (school_info or {}).get("name",      "AI EduHub ERP") or "AI EduHub ERP"
    address   = (school_info or {}).get("address",   "") or ""
    phone     = (school_info or {}).get("phone",     "") or ""
    website   = (school_info or {}).get("website",   "") or ""
    principal = (school_info or {}).get("principal", "") or ""
    MARGIN    = 16 * mm

    # ── Colour palette ─────────────────────────────────────────────
    C_DARK     = colors.HexColor("#0a1628")
    C_NAVY     = colors.HexColor("#0f172a")
    C_BLUE     = colors.HexColor("#1e3a8a")
    C_ACCENT   = colors.HexColor("#2563eb")
    C_GOLD     = colors.HexColor("#f59e0b")
    C_CYAN     = colors.HexColor("#06b6d4")
    C_WHITE    = colors.white
    C_LIGHT    = colors.HexColor("#f8fafc")
    C_GRAY     = colors.HexColor("#64748b")
    C_BORDER   = colors.HexColor("#e2e8f0")
    C_GREEN    = colors.HexColor("#16a34a")
    C_RED      = colors.HexColor("#dc2626")
    C_PASSG    = colors.HexColor("#dcfce7")
    C_FAILBG   = colors.HexColor("#fee2e2")
    C_ROWEVEN  = colors.HexColor("#f0f4ff")
    C_ROWODD   = C_WHITE

    # ══════════════════════════════════════════════════════════════
    # HEADER — full-width dark band with gradient feel
    # ══════════════════════════════════════════════════════════════
    HDR_H = 52 * mm

    # Main header background
    c.setFillColor(C_DARK)
    c.rect(0, H - HDR_H, W, HDR_H, stroke=0, fill=1)

    # Left accent stripe
    c.setFillColor(C_BLUE)
    c.rect(0, H - HDR_H, 3*mm, HDR_H, stroke=0, fill=1)

    # Right decorative block
    c.setFillColor(colors.HexColor("#0d2348"))
    c.rect(W - 55*mm, H - HDR_H, 55*mm, HDR_H, stroke=0, fill=1)

    # Diagonal accent line in header right block
    c.setStrokeColor(C_ACCENT)
    c.setLineWidth(1.5)
    c.line(W - 55*mm, H - HDR_H, W - 20*mm, H)

    c.setStrokeColor(C_CYAN)
    c.setLineWidth(0.7)
    c.line(W - 45*mm, H - HDR_H, W - 10*mm, H)

    # Logo
    LOGO_SZ = 22 * mm
    logo_x  = MARGIN
    logo_y  = H - HDR_H + (HDR_H - LOGO_SZ) / 2
    _load_logo(c, school_info, logo_x, logo_y, LOGO_SZ, LOGO_SZ, colors, mm)

    # School name
    c.setFillColor(C_WHITE)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(MARGIN + LOGO_SZ + 6*mm, H - 18*mm, school.upper())

    # School address / contact
    c.setFont("Helvetica", 9)
    c.setFillColor(colors.HexColor("#93c5fd"))
    if address:
        c.drawString(MARGIN + LOGO_SZ + 6*mm, H - 26*mm, address[:60])
    contact = "  |  ".join(filter(None, [phone, website]))
    if contact:
        c.drawString(MARGIN + LOGO_SZ + 6*mm, H - 32*mm, contact[:60])

    # Gold bottom border of header
    c.setStrokeColor(C_GOLD)
    c.setLineWidth(1.5)
    c.line(0, H - HDR_H, W, H - HDR_H)

    # ── Exam title ribbon ──────────────────────────────────────────
    RIBBON_H = 10 * mm
    c.setFillColor(C_BLUE)
    c.rect(0, H - HDR_H - RIBBON_H, W, RIBBON_H, stroke=0, fill=1)
    # Ribbon accent
    c.setFillColor(C_ACCENT)
    c.rect(0, H - HDR_H - RIBBON_H, 8*mm, RIBBON_H, stroke=0, fill=1)

    c.setFillColor(C_WHITE)
    c.setFont("Helvetica-Bold", 11)
    exam_name = (exam_info.get("name") or "EXAMINATION").upper()
    c.drawCentredString(W / 2, H - HDR_H - RIBBON_H + 3*mm,
                        f"RESULT CARD  —  {exam_name}")

    # Academic year right side
    c.setFillColor(C_GOLD)
    c.setFont("Helvetica-Bold", 8)
    yr = exam_info.get("year", "") or datetime.now().strftime("%Y")
    c.drawRightString(W - MARGIN, H - HDR_H - RIBBON_H + 3*mm,
                      f"Academic Year: {yr}")

    # ══════════════════════════════════════════════════════════════
    # STUDENT INFO SECTION
    # ══════════════════════════════════════════════════════════════
    INFO_Y_TOP  = H - HDR_H - RIBBON_H - 4*mm
    INFO_BOX_H  = 32 * mm
    INFO_BOX_Y  = INFO_Y_TOP - INFO_BOX_H

    # Info box background
    c.setFillColor(C_ROWEVEN)
    c.rect(MARGIN, INFO_BOX_Y, W - 2*MARGIN, INFO_BOX_H, stroke=0, fill=1)
    # Left accent bar on info box
    c.setFillColor(C_ACCENT)
    c.rect(MARGIN, INFO_BOX_Y, 2.5*mm, INFO_BOX_H, stroke=0, fill=1)
    # Info box border
    c.setStrokeColor(C_BORDER)
    c.setLineWidth(0.5)
    c.rect(MARGIN, INFO_BOX_Y, W - 2*MARGIN, INFO_BOX_H, stroke=1, fill=0)

    # Photo on right side of info box
    PHOTO_W = 22 * mm
    PHOTO_H = INFO_BOX_H - 4*mm
    photo_x = W - MARGIN - PHOTO_W - 2*mm
    photo_y = INFO_BOX_Y + 2*mm
    c.setStrokeColor(C_ACCENT)
    c.setLineWidth(0.8)
    c.roundRect(photo_x - 1*mm, photo_y - 1*mm, PHOTO_W + 2*mm, PHOTO_H + 2*mm,
                1.5*mm, stroke=1, fill=0)
    _draw_student_photo(c, student, photo_x, photo_y, PHOTO_W, PHOTO_H, colors)

    # Student info rows — two columns
    INFO_X1 = MARGIN + 5*mm
    INFO_X2 = MARGIN + (W - 2*MARGIN) / 2 + 2*mm
    MAX_INFO_W = photo_x - INFO_X2 - 4*mm

    def irow(label, val, x, y, val_color="#0f172a"):
        c.setFillColor(C_GRAY)
        c.setFont("Helvetica", 8.5)
        c.drawString(x, y, label + ":")
        c.setFillColor(colors.HexColor(val_color))
        c.setFont("Helvetica-Bold", 8.5)
        c.drawString(x + 28*mm, y, str(val or "")[:28])

    iy  = INFO_BOX_Y + INFO_BOX_H - 7*mm
    irow("Student Name", student.get("full_name", ""),  INFO_X1, iy)
    irow("Exam",         exam_info.get("name", ""),     INFO_X2, iy); iy -= 7*mm
    irow("Student ID",   student.get("student_id", ""), INFO_X1, iy)
    irow("Class",
         f"{student.get('class_name','')} — {student.get('section_name','')}",
         INFO_X2, iy); iy -= 7*mm
    irow("Father Name",  student.get("father_name", ""), INFO_X1, iy)
    irow("Roll No.",     student.get("roll_number", ""), INFO_X2, iy); iy -= 7*mm
    irow("Contact",      student.get("father_phone", "") or phone, INFO_X1, iy)
    exam_date = exam_info.get("date", "") or datetime.now().strftime("%d %b %Y")
    irow("Date",         exam_date, INFO_X2, iy)

    # ══════════════════════════════════════════════════════════════
    # RESULTS TABLE
    # ══════════════════════════════════════════════════════════════
    TABLE_Y_TOP = INFO_BOX_Y - 5*mm
    TABLE_X     = MARGIN
    TABLE_W     = W - 2 * MARGIN

    # Column proportions
    COL_W = [int(TABLE_W * r) for r in [0.32, 0.13, 0.13, 0.10, 0.10, 0.12, 0.10]]
    HEADERS = ["Subject", "Max Marks", "Obtained", "Grade", "%", "Remarks", "Status"]

    # Table header row
    HDR_ROW_H = 8 * mm
    c.setFillColor(C_NAVY)
    c.rect(TABLE_X, TABLE_Y_TOP - HDR_ROW_H, TABLE_W, HDR_ROW_H, stroke=0, fill=1)

    # Header text
    cx = TABLE_X
    c.setFillColor(C_WHITE)
    c.setFont("Helvetica-Bold", 8)
    for i, hdr in enumerate(HEADERS):
        cell_center = cx + COL_W[i] / 2
        c.drawCentredString(cell_center, TABLE_Y_TOP - HDR_ROW_H + 2.5*mm, hdr)
        # Subtle divider between header cols
        if i < len(HEADERS) - 1:
            c.setStrokeColor(colors.HexColor("#334155"))
            c.setLineWidth(0.4)
            c.line(cx + COL_W[i], TABLE_Y_TOP - HDR_ROW_H + 1*mm,
                   cx + COL_W[i], TABLE_Y_TOP - 1*mm)
        cx += COL_W[i]

    # Gold bottom border of header
    c.setStrokeColor(C_GOLD)
    c.setLineWidth(0.8)
    c.line(TABLE_X, TABLE_Y_TOP - HDR_ROW_H, TABLE_X + TABLE_W, TABLE_Y_TOP - HDR_ROW_H)

    y = TABLE_Y_TOP - HDR_ROW_H
    ROW_H = 7 * mm
    total_obt = 0.0
    total_max = 0.0

    for ri, row in enumerate(results):
        obt    = float(row.get("obtained_marks") or 0)
        totm   = float(row.get("total_marks")    or 100)
        pct    = (obt / totm * 100) if totm else 0
        total_obt += obt
        total_max += totm
        grade      = row.get("grade") or _pct_to_grade(pct)
        passed_row = pct >= 40

        # Alternating row background
        bg = C_ROWEVEN if ri % 2 == 0 else C_ROWODD
        c.setFillColor(bg)
        c.rect(TABLE_X, y - ROW_H, TABLE_W, ROW_H, stroke=0, fill=1)

        # Left accent colour strip per row (pass=green, fail=red)
        c.setFillColor(C_GREEN if passed_row else C_RED)
        c.rect(TABLE_X, y - ROW_H, 2*mm, ROW_H, stroke=0, fill=1)

        cx = TABLE_X
        vals = [
            row.get("subject_name", ""),
            f"{totm:.0f}",
            f"{obt:.0f}",
            grade,
            f"{pct:.1f}%",
            row.get("remarks", "") or "",
            "PASS" if passed_row else "FAIL",
        ]
        for i_col, val in enumerate(vals):
            vx = cx + COL_W[i_col] / 2
            vy = y - ROW_H + 2*mm

            if i_col == 0:  # Subject — left aligned
                c.setFillColor(C_DARK)
                c.setFont("Helvetica-Bold", 8)
                c.drawString(cx + 4*mm, vy, str(val)[:20])
            elif i_col == 3:  # Grade — coloured
                grade_colors = {
                    "A+":"#16a34a","A":"#16a34a","B":"#2563eb",
                    "C":"#d97706","D":"#ea580c","F":"#dc2626",
                }
                gc = grade_colors.get(str(val), "#374151")
                c.setFillColor(colors.HexColor(gc))
                c.setFont("Helvetica-Bold", 9)
                c.drawCentredString(vx, vy, str(val))
            elif i_col == 6:  # Status badge
                badge_bg  = colors.HexColor("#dcfce7") if passed_row else colors.HexColor("#fee2e2")
                badge_col = C_GREEN if passed_row else C_RED
                bw, bh = COL_W[i_col] - 4*mm, ROW_H - 3*mm
                c.setFillColor(badge_bg)
                c.roundRect(cx + 2*mm, y - ROW_H + 1.5*mm, bw, bh, 1.5*mm, stroke=0, fill=1)
                c.setFillColor(badge_col)
                c.setFont("Helvetica-Bold", 7)
                c.drawCentredString(cx + COL_W[i_col] / 2, vy + 0.5*mm, str(val))
            else:
                c.setFillColor(C_DARK)
                c.setFont("Helvetica", 8)
                c.drawCentredString(vx, vy, str(val))
            cx += COL_W[i_col]

        # Row bottom border
        c.setStrokeColor(C_BORDER)
        c.setLineWidth(0.3)
        c.line(TABLE_X, y - ROW_H, TABLE_X + TABLE_W, y - ROW_H)
        y -= ROW_H

    # ── Grand total row ────────────────────────────────────────────
    overall_pct   = (total_obt / total_max * 100) if total_max else 0
    overall_grade = _pct_to_grade(overall_pct)
    overall_pass  = overall_pct >= 40

    c.setFillColor(C_NAVY)
    c.rect(TABLE_X, y - ROW_H, TABLE_W, ROW_H, stroke=0, fill=1)
    c.setFillColor(C_GOLD)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(TABLE_X + 4*mm, y - ROW_H + 2.5*mm, "GRAND TOTAL")

    cx = TABLE_X + COL_W[0]
    c.setFillColor(C_WHITE)
    c.setFont("Helvetica-Bold", 9)
    c.drawCentredString(cx + COL_W[1]/2, y - ROW_H + 2.5*mm, f"{total_max:.0f}"); cx += COL_W[1]
    c.drawCentredString(cx + COL_W[2]/2, y - ROW_H + 2.5*mm, f"{total_obt:.0f}"); cx += COL_W[2]

    grade_colors = {"A+":"#4ade80","A":"#4ade80","B":"#60a5fa",
                    "C":"#fbbf24","D":"#fb923c","F":"#f87171"}
    c.setFillColor(colors.HexColor(grade_colors.get(overall_grade, "#e2e8f0")))
    c.drawCentredString(cx + COL_W[3]/2, y - ROW_H + 2.5*mm, overall_grade); cx += COL_W[3]

    c.setFillColor(C_WHITE)
    c.drawCentredString(cx + COL_W[4]/2, y - ROW_H + 2.5*mm, f"{overall_pct:.1f}%"); cx += COL_W[4] + COL_W[5]

    # Overall pass/fail badge in total row
    badge_c = colors.HexColor("#4ade80") if overall_pass else colors.HexColor("#f87171")
    c.setFillColor(badge_c)
    c.setFont("Helvetica-Bold", 10)
    c.drawCentredString(cx + COL_W[6]/2, y - ROW_H + 2.5*mm,
                        "PASS" if overall_pass else "FAIL")

    y -= ROW_H + 5*mm

    # ── Result summary panel ───────────────────────────────────────
    PANEL_H = 18 * mm
    PANEL_Y = y - PANEL_H

    # Panel background
    if overall_pass:
        c.setFillColor(C_PASSG)
    else:
        c.setFillColor(C_FAILBG)
    c.roundRect(TABLE_X, PANEL_Y, TABLE_W, PANEL_H, 3*mm, stroke=0, fill=1)

    # Panel border
    border_col = C_GREEN if overall_pass else C_RED
    c.setStrokeColor(border_col)
    c.setLineWidth(1.2)
    c.roundRect(TABLE_X, PANEL_Y, TABLE_W, PANEL_H, 3*mm, stroke=1, fill=0)

    # Left: big PASS/FAIL
    pass_label = "PASS" if overall_pass else "FAIL"
    c.setFillColor(border_col)
    c.setFont("Helvetica-Bold", 20)
    c.drawString(TABLE_X + 8*mm, PANEL_Y + 5*mm, pass_label)

    # Divider
    c.setStrokeColor(border_col)
    c.setLineWidth(0.5)
    c.line(TABLE_X + 38*mm, PANEL_Y + 2*mm, TABLE_X + 38*mm, PANEL_Y + PANEL_H - 2*mm)

    # Stats in panel
    stats = [
        ("Total Marks",    f"{total_max:.0f}"),
        ("Marks Obtained", f"{total_obt:.0f}"),
        ("Percentage",     f"{overall_pct:.1f}%"),
        ("Grade",          overall_grade),
        ("Subjects",       str(len(results))),
    ]
    sx = TABLE_X + 42*mm
    step = (TABLE_W - 44*mm) / len(stats)
    for label, val in stats:
        c.setFillColor(C_GRAY)
        c.setFont("Helvetica", 7)
        c.drawCentredString(sx, PANEL_Y + PANEL_H - 5.5*mm, label)
        c.setFillColor(C_DARK)
        c.setFont("Helvetica-Bold", 11)
        c.drawCentredString(sx, PANEL_Y + 4*mm, val)
        sx += step

    y = PANEL_Y - 8*mm

    # ── QR + Signatures ───────────────────────────────────────────
    QR_SZ = 22 * mm
    qr_path = qr_for_result(student.get("student_id",""), exam_info.get("id",""), overall_grade)

    # QR box
    c.setFillColor(C_WHITE)
    c.setStrokeColor(C_BORDER)
    c.setLineWidth(0.5)
    c.roundRect(W - MARGIN - QR_SZ - 2*mm, y - QR_SZ - 2*mm,
                QR_SZ + 4*mm, QR_SZ + 6*mm, 2*mm, stroke=1, fill=1)
    _draw_qr(c, qr_path, W - MARGIN - QR_SZ, y - QR_SZ, QR_SZ)
    c.setFillColor(C_GRAY)
    c.setFont("Helvetica", 6)
    c.drawCentredString(W - MARGIN - QR_SZ/2, y - QR_SZ - 4.5*mm, "Scan to verify")

    # Signature lines
    SIG_Y    = y - 16*mm
    SIG_SLOTS = [
        ("Class Teacher",     TABLE_X),
        ("Controller of Exams", TABLE_X + (TABLE_W - QR_SZ - 10*mm) / 2),
        ("Principal",         TABLE_X + (TABLE_W - QR_SZ - 10*mm) * 0.72),
    ]
    for sig_label, sx in SIG_SLOTS:
        # Signature area box
        c.setFillColor(C_ROWEVEN)
        c.rect(sx, SIG_Y - 12*mm, 42*mm, 14*mm, stroke=0, fill=1)
        # Signature line
        c.setStrokeColor(colors.HexColor("#334155"))
        c.setLineWidth(0.7)
        c.line(sx + 2*mm, SIG_Y - 5*mm, sx + 40*mm, SIG_Y - 5*mm)
        # Label
        c.setFillColor(C_GRAY)
        c.setFont("Helvetica-Bold", 7)
        c.drawCentredString(sx + 21*mm, SIG_Y - 9.5*mm, sig_label)
        c.setFont("Helvetica", 6)
        c.setFillColor(colors.HexColor("#94a3b8"))
        c.drawCentredString(sx + 21*mm, SIG_Y - 0.5*mm, "Signature & Stamp")

    # ── Footer ────────────────────────────────────────────────────
    c.setFillColor(C_NAVY)
    c.rect(0, 0, W, 14*mm, stroke=0, fill=1)
    c.setStrokeColor(C_GOLD)
    c.setLineWidth(0.8)
    c.line(0, 14*mm, W, 14*mm)

    c.setFillColor(colors.HexColor("#94a3b8"))
    c.setFont("Helvetica", 7.5)
    gen_date = datetime.now().strftime("%d %b %Y  %I:%M %p")
    footer_parts = [school, f"Generated: {gen_date}"]
    if principal:
        footer_parts.insert(1, f"Principal: {principal}")
    c.drawCentredString(W / 2, 5.5*mm, "   |   ".join(footer_parts))

    _draw_demo_watermark(c, W, H, colors)
    c.save()
    if auto_print:
        _direct_print(path)
    else:
        _open(path)
    return path


def _pct_to_grade(pct):
    if pct >= 90: return "A+"
    if pct >= 80: return "A"
    if pct >= 70: return "B"
    if pct >= 60: return "C"
    if pct >= 50: return "D"
    return "F"


# ═══════════════════════════════════════════════════════════════════
#  TIMETABLE — Printable with school info, class info, teacher names
# ═══════════════════════════════════════════════════════════════════
def generate_timetable(class_info, timetable_data, school_info=None, auto_print=False, recess_info=None):
    """
    timetable_data: list of dicts with keys:
        day, period, subject_name, teacher_name, start_time, end_time, room
    recess_info: optional dict with keys:
        recess_after (int period#), recess_start, recess_end (str), friday_periods (int)
    """
    A4, landscape, portrait, colors, mm, cv = _rl()
    PAGE = landscape(A4)
    W, H = PAGE

    fname = f"timetable_{(class_info.get('name','class')).replace(' ','_')}.pdf"
    path  = os.path.join(OUTPUT_DIR, fname)
    c = cv.Canvas(path, pagesize=PAGE)

    school = (school_info or {}).get("name", "AI EduHub ERP") or "AI EduHub ERP"
    address= (school_info or {}).get("address", "") or ""
    principal = (school_info or {}).get("principal", "") or ""

    recess_info     = recess_info or {}
    recess_after    = int(recess_info.get("recess_after", 4) or 4)
    recess_start    = recess_info.get("recess_start", "11:00 AM") or "11:00 AM"
    recess_end      = recess_info.get("recess_end", "11:20 AM") or "11:20 AM"
    friday_periods  = int(recess_info.get("friday_periods", 4) or 4)

    MARGIN = 15*mm

    # Header
    c.setFillColor(colors.HexColor("#0f172a"))
    c.rect(0, H - 35*mm, W, 35*mm, stroke=0, fill=1)

    _load_logo(c, school_info, MARGIN, H - 31*mm, 20*mm, 20*mm, colors, mm)

    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 15)
    c.drawString(MARGIN + 24*mm, H - 16*mm, school.upper())
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.HexColor("#94a3b8"))
    if address:
        c.drawString(MARGIN + 24*mm, H - 23*mm, address)

    # Right: Class info
    c.setFillColor(colors.HexColor("#60a5fa"))
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(W - MARGIN, H - 16*mm,
        f"CLASS: {class_info.get('name','').upper()}")
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.HexColor("#94a3b8"))
    sec = class_info.get("section_name","")
    sess= class_info.get("session_name","")
    c.drawRightString(W - MARGIN, H - 23*mm,
        f"Section: {sec}  |  Session: {sess}  |  Principal: {principal}")

    # Title row
    c.setFillColor(colors.HexColor("#1e3a8a"))
    c.rect(0, H - 43*mm, W, 8*mm, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 10)
    c.drawCentredString(W/2, H - 39*mm,
        f"CLASS TIMETABLE   —   Recess after Period {recess_after} "
        f"({recess_start}-{recess_end})   |   Friday half day: ends after Period {friday_periods}, no recess")

    # Build grid — insert a virtual "Recess" row after `recess_after`
    DAYS    = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
    real_periods = sorted(set(r.get("period",1) for r in timetable_data)) or list(range(1, 9))
    max_period = max(real_periods + [recess_after, friday_periods])

    # Build a display row list: real period numbers, with "RECESS" (None) inserted
    display_rows = []
    for p in range(1, max_period + 1):
        display_rows.append(p)
        if p == recess_after:
            display_rows.append(None)  # None marks the recess row

    N_DAYS  = len(DAYS)
    N_ROWS  = len(display_rows)

    TABLE_Y  = H - 43*mm
    TABLE_H  = TABLE_Y - 20*mm
    ROW_H    = TABLE_H / (N_ROWS + 1)  # +1 for header
    PCOL_W   = 22*mm                   # period label column
    DAY_W    = (W - 2*MARGIN - PCOL_W) / N_DAYS

    # Column headers (days)
    for di, day in enumerate(DAYS):
        x = MARGIN + PCOL_W + di * DAY_W
        y = TABLE_Y - ROW_H
        c.setFillColor(colors.HexColor("#334155"))
        c.rect(x, y, DAY_W, ROW_H, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 8)
        c.drawCentredString(x + DAY_W/2, y + ROW_H/2 - 3*mm, day[:3].upper())

    # Period / Recess rows
    for pi, period in enumerate(display_rows):
        y = TABLE_Y - (pi + 2) * ROW_H
        is_recess = period is None

        # Row label column
        label = "RECESS" if is_recess else f"P-{period}"
        label_bg = colors.HexColor("#d97706") if is_recess else (
            colors.HexColor("#1e3a8a") if pi % 2 == 0 else colors.HexColor("#1e40af"))
        c.setFillColor(label_bg)
        c.rect(MARGIN, y, PCOL_W, ROW_H, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 7)
        c.drawCentredString(MARGIN + PCOL_W/2, y + ROW_H/2 + 1*mm, label)

        for di, day in enumerate(DAYS):
            x = MARGIN + PCOL_W + di * DAY_W
            is_friday_off = (not is_recess) and day == "Friday" and period > friday_periods

            if is_recess:
                if day == "Friday":
                    bg = colors.HexColor("#e5e7eb")
                    c.setFillColor(bg); c.rect(x, y, DAY_W, ROW_H, stroke=0, fill=1)
                    c.setFillColor(colors.HexColor("#6b7280"))
                    c.setFont("Helvetica-Oblique", 6)
                    c.drawCentredString(x + DAY_W/2, y + ROW_H/2 - 1*mm, "Half Day — No Recess")
                else:
                    bg = colors.HexColor("#fef3c7")
                    c.setFillColor(bg); c.rect(x, y, DAY_W, ROW_H, stroke=0, fill=1)
                    c.setFillColor(colors.HexColor("#92400e"))
                    c.setFont("Helvetica-Bold", 6.5)
                    c.drawCentredString(x + DAY_W/2, y + ROW_H/2 + 1*mm, "RECESS")
                    c.setFont("Helvetica", 5.5)
                    c.drawCentredString(x + DAY_W/2, y + ROW_H/2 - 3*mm, f"{recess_start}-{recess_end}")
            elif is_friday_off:
                bg = colors.HexColor("#f1f5f9")
                c.setFillColor(bg); c.rect(x, y, DAY_W, ROW_H, stroke=0, fill=1)
                c.setFillColor(colors.HexColor("#94a3b8"))
                c.setFont("Helvetica-Oblique", 6)
                c.drawCentredString(x + DAY_W/2, y + ROW_H/2 - 1*mm, "School Off")
            else:
                entry = next((r for r in timetable_data
                              if r.get("day") == day and r.get("period") == period), None)
                bg = colors.HexColor("#f0f9ff") if pi % 2 == 0 else colors.white
                c.setFillColor(bg)
                c.rect(x, y, DAY_W, ROW_H, stroke=0, fill=1)
                if entry:
                    subj    = (entry.get("subject_name") or "")[:14]
                    teacher = (entry.get("teacher_name") or "")[:14]
                    room    = entry.get("room") or ""
                    time_s  = entry.get("start_time",""); time_e = entry.get("end_time","")
                    time_str= f"{time_s}-{time_e}" if time_s and time_e else ""

                    c.setFillColor(colors.HexColor("#0f172a"))
                    c.setFont("Helvetica-Bold", 7)
                    c.drawString(x + 2*mm, y + ROW_H - 4*mm, subj)
                    c.setFont("Helvetica", 6)
                    c.setFillColor(colors.HexColor("#2563eb"))
                    c.drawString(x + 2*mm, y + ROW_H - 8*mm, teacher)
                    c.setFillColor(colors.HexColor("#6b7280"))
                    c.setFont("Helvetica", 5.5)
                    if time_str:
                        c.drawString(x + 2*mm, y + ROW_H - 12*mm, time_str)
                    if room:
                        c.drawRightString(x + DAY_W - 1.5*mm, y + 2*mm, f"Rm:{room}")

            # Grid line
            c.setStrokeColor(colors.HexColor("#e2e8f0"))
            c.setLineWidth(0.3)
            c.rect(x, y, DAY_W, ROW_H, stroke=1, fill=0)

    # Footer
    c.setFillColor(colors.HexColor("#f1f5f9"))
    c.rect(0, 0, W, 14*mm, stroke=0, fill=1)
    c.setFillColor(colors.HexColor("#64748b"))
    c.setFont("Helvetica", 7)
    c.drawCentredString(W/2, 8*mm,
        f"{school}  |  Class: {class_info.get('name','')}  |  Generated: {datetime.now().strftime('%d %b %Y')}")

    _draw_demo_watermark(c, W, H, colors)
    c.save()
    if auto_print:
        _direct_print(path)
    else:
        _open(path)
    return path


# ═══════════════════════════════════════════════════════════════════
#  BULK helpers
# ═══════════════════════════════════════════════════════════════════
def bulk_result_cards(students_results, school_info=None, auto_print=False):
    """
    students_results: list of (student_dict, results_list, exam_dict)
    Returns list of generated paths.
    """
    paths = []
    for student, results, exam_info in students_results:
        try:
            p = generate_result_card(student, results, exam_info, school_info, auto_print=False)
            paths.append(p)
        except Exception as e:
            logger.error(f"Error generating result card for {student.get('full_name')}: {e}")
    if auto_print and paths:
        for p in paths:
            _direct_print(p)
    return paths


def bulk_fee_vouchers(vouchers, school_info=None, auto_print=False):
    paths = []
    for v in vouchers:
        try:
            p = generate_fee_voucher(v, school_info, auto_print=False)
            paths.append(p)
        except Exception as e:
            logger.error(f"Error generating voucher {v.get('voucher_id')}: {e}")
    if auto_print and paths:
        for p in paths:
            _direct_print(p)
    return paths
