"""
Demo Edition configuration — single source of truth.

To ship the FULL (paid) version, set DEMO_MODE = False and rebuild.
Everything else in the app reads limits/contact info from here, so this
is the only file that needs to change between editions.
"""

DEMO_MODE = False

# ── Feature limits (only enforced while DEMO_MODE is True) ─────────────────
DEMO_MAX_STUDENTS = 20    # total students allowed
DEMO_MAX_STAFF    = 5     # total staff allowed

# Modules hidden/locked entirely in the demo (shown greyed-out with an
# "🔒 Full Version" badge instead of being removed, so buyers can see what
# they'd get).
DEMO_LOCKED_MODULES = {
    "backup": "Database Backup & Restore",
}

# ── Vendor contact info ─────────────────────────────────────────────────────
VENDOR_NAME       = "LT Software Solutions"
CONTACT_EMAIL     = "ltsoftwaresolutions090@gmail.com"
CONTACT_PHONE     = "+92 335 7876516"
CONTACT_WHATSAPP  = "+923357876516"
WHATSAPP_LINK     = f"https://wa.me/{CONTACT_WHATSAPP.lstrip('+')}"

WATERMARK_TEXT    = "DEMO VERSION"
FOOTER_CONTACT    = f"DEMO VERSION — For full version contact {VENDOR_NAME}: {CONTACT_EMAIL} | {CONTACT_PHONE}"
