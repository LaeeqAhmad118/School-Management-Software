"""
PySide6 compatibility shim.
Handles classes that moved between modules across PySide6 versions.
Import from here instead of directly from PySide6.Qt* when a class
is known to have moved.

  PySide6 < 6.4 :  QGraphicsOpacityEffect in QtWidgets
  PySide6 >= 6.4:  QGraphicsOpacityEffect in QtWidgets  (still)
  Some builds:     QGraphicsOpacityEffect in QtGui (non-standard)

Safe rule: try QtWidgets first, fall back to QtGui.
"""

def _import_QGraphicsOpacityEffect():
    try:
        from PySide6.QtWidgets import QGraphicsOpacityEffect
        return QGraphicsOpacityEffect
    except ImportError:
        from PySide6.QtGui import QGraphicsOpacityEffect
        return QGraphicsOpacityEffect

QGraphicsOpacityEffect = _import_QGraphicsOpacityEffect()

__all__ = ["QGraphicsOpacityEffect"]
