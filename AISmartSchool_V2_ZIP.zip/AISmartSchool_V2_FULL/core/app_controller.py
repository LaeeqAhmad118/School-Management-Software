"""
App Controller — simple, direct navigation flow:

    (first run, no setup yet)  →  Setup Wizard (school info + admin account)
              │
              ▼
      Login screen  (sign in)
              │
              ▼
      MainWindow / Dashboard  (and every other module)

One installation = one school = one local database file. There is no
school-picker screen and no separate platform-level admin account — just
the school's own Setup Wizard once, then straight into the app.
"""
from PySide6.QtWidgets import QApplication
from ui.windows.setup_wizard import SetupWizard
from ui.windows.login_window import LoginWindow
from ui.windows.main_window import MainWindow
import os
import shutil


class AppController:
    def __init__(self, db, theme_manager):
        self.db = db
        self.theme_manager = theme_manager
        self.active_window = None

"""
App Controller — login-first navigation flow:

              Login screen  (always shown first, even before setup)
                    │
      ┌─────────────┴──────────────────────┐
      │ no account yet? click the           │ have credentials already?
      │ "Create Account / Set Up School" CTA│ sign in normally
      ▼                                     ▼
   Setup Wizard                        MainWindow / Dashboard
   (school info + admin account)            ▲
      │                                     │
      └── on success, back to Login ────────┘
          screen (refreshed) so the
          new admin can sign in

Once a school is set up, its admin can create further staff/user logins
from Settings → Users; those new users sign in through this exact same
screen with the credentials the admin gave them — no separate flow needed.

One installation = one school = one local database file. There is no
school-picker screen and no separate platform-level admin account — just
this one school's own Setup Wizard, reachable right from the login screen.
"""
from PySide6.QtWidgets import QApplication
from ui.windows.setup_wizard import SetupWizard
from ui.windows.login_window import LoginWindow
from ui.windows.main_window import MainWindow
import os
import shutil


class AppController:
    def __init__(self, db, theme_manager):
        self.db = db
        self.theme_manager = theme_manager
        self.active_window = None

    # ── Entry point ──────────────────────────────────────────────────────
    def start(self):
        # Always land on the login screen first. If no school/admin has
        # been set up yet on this device, the login screen itself shows a
        # prominent "Create Account / Set Up School" call-to-action —
        # there's no separate up-front wizard popup before the user sees
        # anything.
        self._show_login()

    def _close_active(self):
        if self.active_window:
            try:
                self.active_window.close()
                self.active_window.deleteLater()
            except Exception:
                pass
            self.active_window = None

    # ── Login (always the first screen) ─────────────────────────────────
    def _show_login(self):
        self._close_active()
        win = LoginWindow(self.db, self.theme_manager)
        win.login_success.connect(self._show_main)
        win.create_account_requested.connect(self._show_setup)
        self.active_window = win
        win.show()

    # ── Setup Wizard — reachable from the login screen's CTA ────────────
    def _show_setup(self):
        wizard = SetupWizard(self.db, self.theme_manager)
        if wizard.exec():
            # Success: go back to a FRESH login screen. Building a new
            # LoginWindow (rather than patching the old one in place)
            # guarantees its "no account yet" banner correctly disappears
            # now that db.is_setup_complete() is True, and the school
            # name/logo it displays are picked up fresh too.
            self._show_login()
        # If the wizard was cancelled, we're still sitting on the login
        # screen underneath it — nothing else to do.

    def _show_main(self, user_data):
        self._close_active()
        win = MainWindow(self.db, self.theme_manager, user_data)
        self.active_window = win
        win.show()

    # ── Danger zone: full factory reset (Settings → Backup can call this) ──
    def reset_to_setup(self):
        """
        Nuclear reset — delete the entire DB file and recreate it fresh so
        zero data from before ever leaks through, then go back to the
        login screen (which will show the first-run CTA again since the
        fresh DB has no setup completed yet).
        """
        try:
            path = self.db.db_path
            if self.db._connection:
                try:
                    self.db._connection.close()
                except Exception:
                    pass
                self.db._connection = None
            if os.path.exists(path):
                os.remove(path)
            self.db.initialize()
            self._close_active()
            self._show_login()
        except Exception:
            raise
