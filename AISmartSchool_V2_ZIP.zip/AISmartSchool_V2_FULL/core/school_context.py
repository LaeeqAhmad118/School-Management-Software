"""
School Context — Global singleton that holds school info.
Emit school_updated signal whenever settings are saved.
Every widget that shows school name/logo connects to this.
"""
from PySide6.QtCore import QObject, Signal
import os

class SchoolContext(QObject):
    school_updated = Signal(dict)   # emitted after settings save

    _instance = None

    @classmethod
    def instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        super().__init__()
        self._info = {}

    def load(self, db):
        """Load from DB — call once at startup and after each settings save."""
        try:
            row = db.fetchone("SELECT * FROM school_info WHERE id=1") or {}
            self._info = dict(row)
        except Exception:
            self._info = {}

    def refresh_and_notify(self, db):
        self.load(db)
        self.school_updated.emit(self._info)

    @property
    def name(self):
        return self._info.get("name") or "AI EduHub ERP"

    @property
    def logo_path(self):
        p = self._info.get("logo_path") or ""
        return p if p and os.path.exists(p) else ""

    @property
    def info(self):
        return dict(self._info)
