"""
Theme Manager - Global QSS Styling Engine
Supports: dark_blue, dark_purple, emerald, black_gold, light, ocean_teal
"""
import re

THEMES = {
    "dark_blue": {
        "name": "Dark Blue",
        "bg_primary": "#0f172a",
        "bg_secondary": "#1e293b",
        "bg_tertiary": "#334155",
        "bg_card": "#1e293b",
        "sidebar_bg": "#0f172a",
        "sidebar_selected": "#1d4ed8",
        "accent": "#3b82f6",
        "accent_hover": "#2563eb",
        "accent_light": "#60a5fa",
        "text_primary": "#f1f5f9",
        "text_secondary": "#94a3b8",
        "text_muted": "#475569",
        "border": "#334155",
        "success": "#22c55e",
        "warning": "#f59e0b",
        "error": "#ef4444",
        "info": "#06b6d4",
        "btn_add": "#16a34a",
        "btn_edit": "#2563eb",
        "btn_delete": "#dc2626",
        "btn_cancel": "#6b7280",
        "btn_print": "#7c3aed",
        "btn_export": "#ea580c",
    },
    "dark_purple": {
        "name": "Dark Purple",
        "bg_primary": "#0f0a1e",
        "bg_secondary": "#1a1133",
        "bg_tertiary": "#2d1b69",
        "bg_card": "#1a1133",
        "sidebar_bg": "#0f0a1e",
        "sidebar_selected": "#7c3aed",
        "accent": "#8b5cf6",
        "accent_hover": "#7c3aed",
        "accent_light": "#a78bfa",
        "text_primary": "#f5f3ff",
        "text_secondary": "#c4b5fd",
        "text_muted": "#6d28d9",
        "border": "#2d1b69",
        "success": "#22c55e",
        "warning": "#f59e0b",
        "error": "#ef4444",
        "info": "#06b6d4",
        "btn_add": "#16a34a",
        "btn_edit": "#7c3aed",
        "btn_delete": "#dc2626",
        "btn_cancel": "#6b7280",
        "btn_print": "#0891b2",
        "btn_export": "#ea580c",
    },
    "emerald": {
        "name": "Emerald",
        "bg_primary": "#022c22",
        "bg_secondary": "#064e3b",
        "bg_tertiary": "#065f46",
        "bg_card": "#064e3b",
        "sidebar_bg": "#022c22",
        "sidebar_selected": "#059669",
        "accent": "#10b981",
        "accent_hover": "#059669",
        "accent_light": "#34d399",
        "text_primary": "#ecfdf5",
        "text_secondary": "#6ee7b7",
        "text_muted": "#047857",
        "border": "#065f46",
        "success": "#22c55e",
        "warning": "#f59e0b",
        "error": "#ef4444",
        "info": "#06b6d4",
        "btn_add": "#059669",
        "btn_edit": "#0891b2",
        "btn_delete": "#dc2626",
        "btn_cancel": "#6b7280",
        "btn_print": "#7c3aed",
        "btn_export": "#ea580c",
    },
    "black_gold": {
        "name": "Black Gold Premium",
        "bg_primary": "#0a0a0a",
        "bg_secondary": "#141414",
        "bg_tertiary": "#1e1e1e",
        "bg_card": "#141414",
        "sidebar_bg": "#0a0a0a",
        "sidebar_selected": "#b8860b",
        "accent": "#d4af37",
        "accent_hover": "#b8860b",
        "accent_light": "#ffd700",
        "text_primary": "#f5f5f0",
        "text_secondary": "#d4af37",
        "text_muted": "#6b5a1e",
        "border": "#2a2a2a",
        "success": "#22c55e",
        "warning": "#f59e0b",
        "error": "#ef4444",
        "info": "#06b6d4",
        "btn_add": "#16a34a",
        "btn_edit": "#b8860b",
        "btn_delete": "#dc2626",
        "btn_cancel": "#6b7280",
        "btn_print": "#7c3aed",
        "btn_export": "#ea580c",
    },
    "light": {
        "name": "Light Mode",
        "bg_primary": "#f8fafc",
        "bg_secondary": "#ffffff",
        "bg_tertiary": "#f1f5f9",
        "bg_card": "#ffffff",
        "sidebar_bg": "#1e293b",
        "sidebar_selected": "#3b82f6",
        "accent": "#3b82f6",
        "accent_hover": "#2563eb",
        "accent_light": "#60a5fa",
        "text_primary": "#0f172a",
        "text_secondary": "#475569",
        "text_muted": "#94a3b8",
        "border": "#e2e8f0",
        "success": "#16a34a",
        "warning": "#d97706",
        "error": "#dc2626",
        "info": "#0891b2",
        "btn_add": "#16a34a",
        "btn_edit": "#2563eb",
        "btn_delete": "#dc2626",
        "btn_cancel": "#6b7280",
        "btn_print": "#7c3aed",
        "btn_export": "#ea580c",
    },
    "ocean_teal": {
        "name": "Ocean Teal",
        "bg_primary": "#062b2e",
        "bg_secondary": "#0b3d40",
        "bg_tertiary": "#0f4d52",
        "bg_card": "#0b3d40",
        "sidebar_bg": "#062b2e",
        "sidebar_selected": "#0d9488",
        "accent": "#14b8a6",
        "accent_hover": "#0d9488",
        "accent_light": "#5eead4",
        "text_primary": "#ecfeff",
        "text_secondary": "#99f6e4",
        "text_muted": "#0f766e",
        "border": "#0f4d52",
        "success": "#22c55e",
        "warning": "#f59e0b",
        "error": "#ef4444",
        "info": "#06b6d4",
        "btn_add": "#0d9488",
        "btn_edit": "#0284c7",
        "btn_delete": "#dc2626",
        "btn_cancel": "#6b7280",
        "btn_print": "#7c3aed",
        "btn_export": "#ea580c",
    }
}


def build_qss(t):
    return f"""
/* ===== GLOBAL ===== */
* {{
    font-family: 'Segoe UI', 'Arial', sans-serif;
    font-size: 13px;
    color: {t['text_primary']};
    outline: none;
}}

/* Critical: all QLabel backgrounds transparent by default */
QLabel {{
    background: transparent;
    color: {t['text_primary']};
}}

QMainWindow, QDialog {{
    background-color: {t['bg_primary']};
}}

QWidget {{
    background-color: transparent;
}}

QMainWindow > QWidget,
QDialog > QWidget,
QScrollArea > QWidget > QWidget {{
    background-color: {t['bg_primary']};
}}

/* ===== SIDEBAR ===== */
#sidebar {{
    background-color: {t['sidebar_bg']};
    border-right: 1px solid {t['border']};
    min-width: 220px;
    max-width: 220px;
}}

#sidebar_btn {{
    background: transparent;
    border: none;
    border-radius: 8px;
    padding: 10px 16px;
    text-align: left;
    color: {t['text_secondary']};
    font-size: 13px;
    margin: 2px 8px;
}}
#sidebar_btn:hover {{
    background-color: {t['bg_tertiary']};
    color: {t['text_primary']};
}}
#sidebar_btn[active="true"] {{
    background-color: {t['sidebar_selected']};
    color: white;
    font-weight: 600;
}}

/* ===== CARDS ===== */
#card {{
    background-color: {t['bg_card']};
    border: 1px solid {t['border']};
    border-radius: 12px;
    padding: 14px;
}}
#stat_card {{
    background-color: {t['bg_card']};
    border: 1px solid {t['border']};
    border-radius: 12px;
    padding: 14px 16px;
}}
#stat_card:hover {{
    border-color: {t['accent']};
    background-color: {t['bg_tertiary']};
}}

/* ===== BUTTONS ===== */
QPushButton {{
    border-radius: 8px;
    padding: 7px 16px;
    font-weight: 600;
    font-size: 12px;
    border: none;
    background: {t['bg_tertiary']};
    color: {t['text_primary']};
}}
QPushButton:hover {{
    background: {t['accent']};
    color: white;
}}

#btn_add, #btn_primary {{
    background-color: {t['btn_add']};
    color: white;
}}
#btn_add:hover {{ background-color: #15803d; }}

#btn_edit {{
    background-color: {t['btn_edit']};
    color: white;
}}
#btn_edit:hover {{ background-color: {t['accent_hover']}; }}

#btn_delete {{
    background-color: {t['btn_delete']};
    color: white;
}}
#btn_delete:hover {{ background-color: #b91c1c; }}

#btn_cancel {{
    background-color: {t['btn_cancel']};
    color: white;
}}
#btn_cancel:hover {{ background-color: #4b5563; }}

#btn_print {{
    background-color: {t['btn_print']};
    color: white;
}}
#btn_print:hover {{ background-color: #6d28d9; }}

#btn_export {{
    background-color: {t['btn_export']};
    color: white;
}}
#btn_export:hover {{ background-color: #c2410c; }}

#btn_secondary {{
    background-color: {t['bg_tertiary']};
    color: {t['text_primary']};
    border: 1px solid {t['border']};
}}
#btn_secondary:hover {{ background-color: {t['accent']}; color: white; }}

/* ===== INPUTS ===== */
QLineEdit, QComboBox, QTextEdit, QSpinBox, QDoubleSpinBox, QDateEdit, QTimeEdit {{
    background-color: {t['bg_tertiary']};
    border: 1px solid {t['border']};
    border-radius: 8px;
    padding: 6px 10px;
    color: {t['text_primary']};
    selection-background-color: {t['accent']};
}}
QLineEdit:focus, QComboBox:focus, QTextEdit:focus,
QSpinBox:focus, QDoubleSpinBox:focus, QDateEdit:focus {{
    border-color: {t['accent']};
    background-color: {t['bg_secondary']};
}}

QComboBox::drop-down {{ border: none; padding-right: 6px; }}
QComboBox::down-arrow {{
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid {t['text_secondary']};
    margin-right: 8px;
}}
QComboBox QAbstractItemView {{
    background-color: {t['bg_card']};
    border: 1px solid {t['border']};
    border-radius: 8px;
    selection-background-color: {t['accent']};
    color: {t['text_primary']};
}}

/* ===== TABLES — bordered, modern, theme-aware ===== */
QTableWidget, QTableView {{
    background-color: {t['bg_secondary']};
    gridline-color: {t['border']};
    border: 1px solid {t['border']};
    border-radius: 10px;
    selection-background-color: {t['accent']};
    selection-color: white;
    alternate-background-color: {t['bg_tertiary']};
}}
QTableWidget::item, QTableView::item {{
    padding: 8px 10px;
    border-right: 1px solid {t['border']};
    border-bottom: 1px solid {t['border']};
    background: transparent;
    color: {t['text_primary']};
}}
QTableWidget::item:selected, QTableView::item:selected {{
    background-color: {t['accent']};
    color: white;
}}
QTableWidget::item:hover, QTableView::item:hover {{
    background-color: {t['bg_tertiary']};
}}
QHeaderView::section {{
    background-color: {t['bg_tertiary']};
    color: {t['text_secondary']};
    padding: 10px 8px;
    border: none;
    border-right: 1px solid {t['border']};
    border-bottom: 2px solid {t['accent']};
    font-weight: 800;
    font-size: 11px;
}}
QHeaderView::section:last {{ border-right: none; }}
QTableCornerButton::section {{
    background-color: {t['bg_tertiary']};
    border: none;
}}

/* ===== TABS ===== */
QTabWidget::pane {{
    border: 1px solid {t['border']};
    border-radius: 8px;
    background-color: {t['bg_secondary']};
    top: -1px;
}}
QTabBar::tab {{
    background-color: transparent;
    color: {t['text_secondary']};
    padding: 8px 18px;
    border-bottom: 2px solid transparent;
    margin-right: 2px;
    font-weight: 500;
    font-size: 12px;
}}
QTabBar::tab:selected {{
    color: {t['accent_light']};
    border-bottom: 2px solid {t['accent']};
    font-weight: 700;
}}
QTabBar::tab:hover:!selected {{
    color: {t['text_primary']};
    background-color: {t['bg_tertiary']};
    border-radius: 6px 6px 0 0;
}}

/* ===== SCROLLBARS ===== */
QScrollBar:vertical {{
    background: transparent;
    width: 6px;
    border-radius: 3px;
}}
QScrollBar::handle:vertical {{
    background: {t['bg_tertiary']};
    border-radius: 3px;
    min-height: 20px;
}}
QScrollBar::handle:vertical:hover {{ background: {t['accent']}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
QScrollBar:horizontal {{
    background: transparent;
    height: 6px;
    border-radius: 3px;
}}
QScrollBar::handle:horizontal {{
    background: {t['bg_tertiary']};
    border-radius: 3px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}

/* ===== MISC ===== */
QScrollArea {{ border: none; background: transparent; }}
QScrollArea > QWidget {{ background: transparent; }}

QToolTip {{
    background-color: {t['bg_card']};
    color: {t['text_primary']};
    border: 1px solid {t['accent']};
    border-radius: 6px;
    padding: 5px 9px;
    font-size: 12px;
}}
QMessageBox {{ background-color: {t['bg_secondary']}; }}
QGroupBox {{
    border: 1px solid {t['border']};
    border-radius: 10px;
    margin-top: 14px;
    padding-top: 8px;
    font-weight: 600;
    color: {t['text_secondary']};
    background: transparent;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 6px;
    color: {t['accent_light']};
    background: transparent;
}}
QCheckBox {{
    color: {t['text_primary']};
    spacing: 6px;
    background: transparent;
}}
QCheckBox::indicator {{
    width: 15px; height: 15px;
    border: 2px solid {t['border']};
    border-radius: 4px;
    background: {t['bg_tertiary']};
}}
QCheckBox::indicator:checked {{
    background: {t['accent']};
    border-color: {t['accent']};
}}
QRadioButton {{
    color: {t['text_primary']};
    spacing: 6px;
    background: transparent;
}}
QRadioButton::indicator {{
    width: 15px; height: 15px;
    border: 2px solid {t['border']};
    border-radius: 8px;
    background: {t['bg_tertiary']};
}}
QRadioButton::indicator:checked {{
    background: {t['accent']};
    border-color: {t['accent']};
}}
QProgressBar {{
    background-color: {t['bg_tertiary']};
    border-radius: 5px;
    height: 6px;
    text-align: center;
    color: transparent;
    border: none;
}}
QProgressBar::chunk {{
    background-color: {t['accent']};
    border-radius: 5px;
}}
QFrame#separator {{
    background-color: {t['border']};
    max-height: 1px;
}}
#header_bar {{
    background-color: {t['bg_secondary']};
    border-bottom: 1px solid {t['border']};
}}
"""



class ThemeManager:
    # Zoom is clamped to a sane range so text/paddings never disappear (too
    # small) or blow out the layout entirely (too large).
    ZOOM_MIN  = 0.7
    ZOOM_MAX  = 1.6
    ZOOM_STEP = 0.1

    def __init__(self, app):
        self.app = app
        self.current_theme = "dark_blue"
        self.colors = {}
        self.zoom_factor = 1.0
        self._base_font_pt = app.font().pointSizeF() if app.font().pointSizeF() > 0 else 9.0

    def apply_theme(self, theme_name):
        if theme_name not in THEMES:
            theme_name = "dark_blue"
        self.current_theme = theme_name
        self.colors = THEMES[theme_name]
        self._apply_stylesheet()

    def _apply_stylesheet(self):
        """(Re)build the QSS for the current theme and apply it, scaled by
        the current zoom_factor. Called on theme change AND on zoom change,
        so the two always stay in sync."""
        qss = build_qss(self.colors)
        if abs(self.zoom_factor - 1.0) > 0.001:
            qss = self._scale_qss_px(qss, self.zoom_factor)
        self.app.setStyleSheet(qss)

        # Scale the application's base font too, so any label/widget that
        # relies on the default font (rather than an explicit QSS
        # font-size) also grows/shrinks with the rest of the UI.
        font = self.app.font()
        font.setPointSizeF(max(6.0, self._base_font_pt * self.zoom_factor))
        self.app.setFont(font)

    @staticmethod
    def _scale_qss_px(qss: str, factor: float) -> str:
        """Multiply every pixel value in a QSS string by `factor`. This is
        what actually makes Ctrl+/Ctrl- 'zoom' the whole app: font sizes,
        padding, margins, border-radius, and fixed widths/heights written
        in the stylesheet all scale together, proportionally, in one pass —
        without needing to hand-edit every style rule in the codebase."""
        def repl(m):
            value = float(m.group(1))
            scaled = max(1, round(value * factor))
            return f"{scaled}px"
        return re.sub(r'(\d+(?:\.\d+)?)px', repl, qss)

    # ── Zoom controls (Ctrl+= / Ctrl+- / Ctrl+0) ────────────────────────
    def zoom_in(self):
        self.zoom_factor = round(min(self.ZOOM_MAX, self.zoom_factor + self.ZOOM_STEP), 2)
        self._apply_stylesheet()
        return self.zoom_factor

    def zoom_out(self):
        self.zoom_factor = round(max(self.ZOOM_MIN, self.zoom_factor - self.ZOOM_STEP), 2)
        self._apply_stylesheet()
        return self.zoom_factor

    def zoom_reset(self):
        self.zoom_factor = 1.0
        self._apply_stylesheet()
        return self.zoom_factor

    def get_color(self, key, default="#000000"):
        return self.colors.get(key, default)

    def get_all_themes(self):
        return {k: v['name'] for k, v in THEMES.items()}

    def get_current(self):
        return self.current_theme
