"""
Color utilities for Qt stylesheets.

Qt Style Sheets do NOT support the common web "#RRGGBBAA" hex-with-trailing-
alpha format (only "#AARRGGBB", alpha FIRST, or the rgba() function). Code
across this app previously built colors like f"{color}44" — intending
"colour at ~27% opacity" — which Qt's QSS parser cannot parse as a color.

Depending on the Qt build this either silently drops the declaration, or in
some cases falls through to a completely different color (this is also
exactly the bug behind the ID card's "yellow circle" — the same wrong
pattern used with reportlab, which parses #RRGGBBAA as RGB=RRGGBB, ignoring
AA as part of RGB rather than as alpha, producing a wrong bright color).

Use rgba() below anywhere a translucent color is needed in a Qt stylesheet.
"""


def rgba(hex_color: str, alpha_hex) -> str:
    """
    Convert a '#RRGGBB' (or bare 'RRGGBB') color plus a 2-digit hex alpha
    (e.g. '44') OR a float 0..1 alpha into a Qt-safe 'rgba(r,g,b,a)' string.
    """
    h = (hex_color or "#000000").lstrip("#")
    if len(h) == 3:
        h = "".join(ch * 2 for ch in h)
    if len(h) < 6:
        h = h.ljust(6, "0")
    r = int(h[0:2], 16)
    g = int(h[2:4], 16)
    b = int(h[4:6], 16)

    if isinstance(alpha_hex, str):
        a = int(alpha_hex, 16) / 255.0
    else:
        a = float(alpha_hex)

    return f"rgba({r},{g},{b},{a:.3f})"
