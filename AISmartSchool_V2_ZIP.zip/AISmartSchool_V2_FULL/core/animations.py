"""
Animations V3 — Performance-safe, NO QGraphicsOpacityEffect on child widgets.

Root cause of cursor lag: QGraphicsOpacityEffect forces Qt to re-composite
the entire widget subtree through an offscreen buffer on every repaint,
including every mouse-move. Never attach it to a widget that contains
many children (cards, tables, lists).

Safe alternatives used here:
  - QMainWindow.setWindowOpacity()  → GPU composited, zero cost
  - QTimer + setStyleSheet opacity  → CSS only, no offscreen buffer
  - Geometry animation (pos/size)   → no compositing overhead
"""
from PySide6.QtCore import (
    QPropertyAnimation, QEasingCurve, QPoint,
    QParallelAnimationGroup, QTimer, Qt
)
from PySide6.QtWidgets import QWidget, QGraphicsOpacityEffect


# ── Startup: fade the whole window via window opacity (GPU-composited) ─────────
def fade_in_window(window, duration=350):
    """
    Fade a top-level window in using setWindowOpacity().
    This is GPU-composited by the OS — zero CPU repaint cost.
    """
    window.setWindowOpacity(0.0)
    anim = QPropertyAnimation(window, b"windowOpacity")
    anim.setDuration(duration)
    anim.setStartValue(0.0)
    anim.setEndValue(1.0)
    anim.setEasingCurve(QEasingCurve.OutCubic)
    anim.start()
    return anim


# ── Page transition: slide only (no opacity effect on child widgets) ───────────
def slide_in_page(stack_widget, new_widget, duration=220):
    """
    Switch pages in a QStackedWidget with a fast horizontal slide.
    No QGraphicsOpacityEffect — geometry animation only.
    """
    stack_widget.setCurrentWidget(new_widget)
    w = stack_widget.width() or 800
    orig = new_widget.pos()

    anim = QPropertyAnimation(new_widget, b"pos")
    anim.setDuration(duration)
    anim.setStartValue(QPoint(orig.x() + 40, orig.y()))
    anim.setEndValue(orig)
    anim.setEasingCurve(QEasingCurve.OutCubic)
    anim.start()
    return anim


# ── Slide in from right (for panels) ─────────────────────────────────────────
def slide_in_from_right(widget, duration=280):
    orig = widget.pos()
    anim = QPropertyAnimation(widget, b"pos")
    anim.setDuration(duration)
    anim.setStartValue(QPoint(orig.x() + 60, orig.y()))
    anim.setEndValue(orig)
    anim.setEasingCurve(QEasingCurve.OutCubic)
    anim.start()
    return anim


# ── Stat card number counter (no graphics effect) ────────────────────────────
def count_up(label, target, duration_ms=600, prefix="", suffix=""):
    """
    Animate a QLabel's text from 0 to target using a timer.
    Pure text update — no graphics effects, no repaints of siblings.
    """
    if target <= 0:
        label.setText(f"{prefix}0{suffix}")
        return None

    steps    = min(30, target)
    interval = max(16, duration_ms // steps)
    step_val = target / steps
    current  = [0.0]

    timer = QTimer()
    timer.setInterval(interval)

    def tick():
        current[0] = min(current[0] + step_val, target)
        label.setText(f"{prefix}{int(current[0]):,}{suffix}")
        if current[0] >= target:
            timer.stop()

    timer.timeout.connect(tick)
    timer.start()
    return timer   # caller must hold reference


# ── Pulse a button briefly (stylesheet swap, no effect) ──────────────────────
def pulse_button(btn, color_on="#2563eb", cycles=2, interval_ms=250):
    orig = btn.styleSheet()
    count = [0]

    timer = QTimer()
    def toggle():
        if count[0] % 2 == 0:
            btn.setStyleSheet(orig + f"background:{color_on};color:white;")
        else:
            btn.setStyleSheet(orig)
        count[0] += 1
        if count[0] >= cycles * 2:
            timer.stop()
            btn.setStyleSheet(orig)
    timer.timeout.connect(toggle)
    timer.start(interval_ms)
    return timer


# ── Legacy stubs (kept so old callers don't crash) ────────────────────────────
def fade_in(widget, duration=300, start=0.0, end=1.0):
    """
    DEPRECATED: QGraphicsOpacityEffect causes cursor-move repaints.
    Now a no-op stub. Use fade_in_window() for top-level windows.
    """
    return None


def fade_and_slide(widget, duration=350):
    """DEPRECATED stub — use slide_in_page instead."""
    return slide_in_from_right(widget, duration)


def page_transition(stack_widget, new_widget, direction="right"):
    """DEPRECATED stub — kept for backward compat."""
    return slide_in_page(stack_widget, new_widget)
