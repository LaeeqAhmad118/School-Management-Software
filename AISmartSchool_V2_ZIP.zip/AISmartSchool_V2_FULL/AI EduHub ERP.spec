# -*- mode: python ; coding: utf-8 -*-
# ============================================================
#  AIEduHub ERP v2.0 — PyInstaller Spec
#  LT Software Solutions
#
#  Build command (run from the project folder):
#      pyinstaller "AI EduHub ERP.spec" --noconfirm --clean
#
#  Output: dist\AI EduHub ERP\AI EduHub ERP.exe
# ============================================================

import os

block_cipher = None

# Absolute path to this spec file's folder — always resolves correctly
# regardless of which directory you launch pyinstaller from.
_HERE = os.path.dirname(os.path.abspath(SPEC))

# Icon — read at BUILD TIME from the source tree
_ICO = os.path.join(_HERE, "assets", "icons", "AIeduHub.ico")
if not os.path.isfile(_ICO):
    print(f"WARNING: icon not found at {_ICO} — building without icon")
    _ICO = None

# ── Hidden imports ──────────────────────────────────────────────
# Modules PyInstaller misses because they are imported dynamically.
hidden_imports = [
    # PySide6
    "PySide6.QtCore",
    "PySide6.QtGui",
    "PySide6.QtWidgets",
    "PySide6.QtPrintSupport",
    "PySide6.QtSvg",
    "PySide6.QtNetwork",

    # ReportLab — PDF generation
    "reportlab",
    "reportlab.pdfgen",
    "reportlab.pdfgen.canvas",
    "reportlab.platypus",
    "reportlab.lib",
    "reportlab.lib.pagesizes",
    "reportlab.lib.styles",
    "reportlab.lib.colors",
    "reportlab.lib.units",
    "reportlab.lib.enums",
    "reportlab.graphics",
    "reportlab.graphics.shapes",
    "reportlab.pdfbase",
    "reportlab.pdfbase.ttfonts",
    "reportlab.pdfbase.pdfmetrics",
    "reportlab.pdfbase._fontdata",
    "reportlab.rl_config",

    # PyMuPDF — syllabus PDF reading
    "fitz",

    # QR code
    "qrcode",
    "qrcode.image.pil",
    "qrcode.constants",

    # Pillow
    "PIL",
    "PIL.Image",
    "PIL.ImageDraw",
    "PIL.ImageFont",
    "PIL.PngImagePlugin",
    "PIL.JpegImagePlugin",
    "PIL.BmpImagePlugin",

    # Standard lib
    "sqlite3",
    "hashlib",
    "base64",
    "json",
    "csv",
    "logging",
    "subprocess",
    "platform",
    "uuid",

    # App packages
    "core",
    "core.app_controller",
    "core.school_context",
    "core.theme_manager",
    "core.qr_engine",
    "database",
    "database.db_manager",
    "utils",
    "utils.pdf_generator",
    "ui",
    "ui.components.widgets",
    "ui.windows.login_window",
    "ui.windows.main_window",
    "ui.windows.setup_wizard",
    "modules.dashboard.dashboard_view",
    "modules.admission.admission_view",
    "modules.students.students_view",
    "modules.students.student_profile",
    "modules.fees.fees_view",
    "modules.attendance.attendance_view",
    "modules.exams.exams_view",
    "modules.results.results_view",
    "modules.timetable.timetable_view",
    "modules.staff.staff_view",
    "modules.reports.reports_view",
    "modules.ai.ai_view",
    "modules.settings.settings_view",
    "modules.backup.backup_view",
    "modules.parent_portal.parent_portal_view",
    "modules.promotion.promotion_view",
    "modules.paper_creation",
    "modules.paper_creation.offline_engine",
    "modules.paper_creation.paper_creation_view",
    "modules.paper_creation.paper_pdf_generator",
]

# ── Data files ──────────────────────────────────────────────────
datas = [
    # App icon bundled so runtime code can also reference it
    (
        os.path.join(_HERE, "assets", "icons", "AIeduHub.ico"),
        os.path.join("assets", "icons"),
    ),
]

# ReportLab fonts — required for PDF generation
try:
    import reportlab as _rl
    _rl_fonts = os.path.join(os.path.dirname(_rl.__file__), "fonts")
    if os.path.isdir(_rl_fonts):
        datas.append((_rl_fonts, "reportlab/fonts"))
except ImportError:
    pass

# ── Analysis ────────────────────────────────────────────────────
a = Analysis(
    ["main.py"],
    pathex=[_HERE],
    binaries=[],
    datas=datas,
    hiddenimports=hidden_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "tkinter",
        "matplotlib",
        "numpy",
        "pandas",
        "scipy",
        "sklearn",
        "tensorflow",
        "torch",
        "cv2",
        "PyQt5",
        "PyQt6",
        "wx",
        "gi",
        "IPython",
        "notebook",
        "jupyter",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
    optimize=1,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# ── EXE ─────────────────────────────────────────────────────────
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="AI EduHub ERP",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=["vcruntime140.dll", "python3*.dll", "Qt6*.dll", "PySide6*.pyd"],
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=_ICO,
)

# ── COLLECT ─────────────────────────────────────────────────────
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=["vcruntime140.dll", "python3*.dll", "Qt6*.dll", "PySide6*.pyd"],
    name="AI EduHub ERP",
)
