"""
AIEduHub ERP — Entry Point
LT Software Solutions

Login-first flow: the login screen is always the first thing shown. If no
school has been set up on this device yet, the login screen itself shows
a "Create Account / Set Up School" call-to-action that launches the Setup
Wizard; once that's done, it's a normal login screen from then on. One
installation = one school = its own local database file.
"""
import sys
import os
import logging
import importlib
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s"
)

try:
    from PySide6.QtWidgets import QApplication
    from PySide6.QtGui import QIcon
except ImportError:
    QtWidgets = importlib.import_module("PySide2.QtWidgets")
    QtGui = importlib.import_module("PySide2.QtGui")

    QApplication = QtWidgets.QApplication
    QIcon = QtGui.QIcon

from database.db_manager  import DatabaseManager
from core.theme_manager   import ThemeManager
from core.school_context  import SchoolContext
from core.app_controller  import AppController


def _app_icon():
    """
    Resolve the app icon whether running from source or PyInstaller bundle.
    PyInstaller sets sys._MEIPASS to its extraction root at runtime.
    """
    base = getattr(sys, "_MEIPASS",
                os.path.dirname(os.path.abspath(__file__)))
    ico  = os.path.join(base, "assets", "icons", "AIeduHub.ico")
    return QIcon(ico) if os.path.isfile(ico) else QIcon()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("AIEduHub ERP")
    app.setApplicationVersion("2.0")
    app.setOrganizationName("LT Software Solutions")
    app.setWindowIcon(_app_icon())

    db = DatabaseManager()
    db.initialize()
    SchoolContext.instance().load(db)

    tm = ThemeManager(app)
    tm.apply_theme("dark_blue")

    controller = AppController(db, tm)
    controller.start()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
